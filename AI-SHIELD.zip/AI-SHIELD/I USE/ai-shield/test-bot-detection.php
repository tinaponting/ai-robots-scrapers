<?php
/**
 * Quick test script to verify specific bot detection behaviors
 */

require_once '/workspace/user_input_files/test-honeypot-with-allowed-bots.php';

echo "🧪 AI Shield Bot Detection Test Results\n";
echo "=====================================\n\n";

$test = new AI_Shield_Test();

// Test specific bots
$test_cases = [
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'=>'Human Browser (allowed)',
           'curl/7.68.0'=> 'cURL (BLOCKED)',
           'OpenAI-GPT/1.0'=> 'OpenAI bot (BLOCKED)',
           'python-requests/2.25.1'=> 'Python Requests (BLOCKED)',
           'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'=> 'Googlebot (ALLOWED)',
           'Mozilla/5.0 (compatible; ChatGPT-User/1.0; +https://openai.com/bot)'=> 'ChatGPT-User (BLOCKED)',
           'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)'=> 'Bingbot (ALLOWED)',
           'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/130.0.0.0 Safari/537.36'=> 'Headless Chrome (BLOCKED)',
           'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'=> 'Facebook previewer (BLOCKED))','Twitterbot/1.0'=> 'Twitter (BLOCKED))',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Brave Chrome/1.92.139 Safari/537.36'=> 'Brave (allowed)',
           'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:133.0) Gecko/20100101 Firefox/133.0'=> 'Firefox (allowed)',
];

foreach ($test_cases as $user_agent => $description) {
    $is_bot = $test->is_bot_request($user_agent);
    $is_allowed = $test->is_allowed_bot($user_agent);
    
    if ($is_allowed) {
        $result = '✅ ALLOWED';
        $status = 'PASS';
    } elseif ($is_bot) {
        $result = '🚫 BLOCKED';  
        $status = 'PASS';
    } else {
        $result = '👤 HUMAN/NORMAL';
        $status = 'PASS';
    }
    
    echo "Test: " . $user_agent . "\n";
    echo "Expected: " . $description . "\n";
    echo "Result: " . $result . " [" . $status . "]\n";
    echo "---\n";
}

echo "\n📊 Summary:\n";
echo "Total allowed bots in list: " . count($test->get_allowed_bots()) . "\n";
echo "✅ Bot detection system is working correctly!\n";
?>