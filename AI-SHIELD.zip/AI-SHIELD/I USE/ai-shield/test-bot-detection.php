<?php
/**
 * Quick test script to verify specific bot detection behaviors
 */

require_once __DIR__ . '/test-honeypot-with-allowed-bots.php';

echo "🧪 AI Shield Bot Detection Test Results\n";
echo "=====================================\n\n";

$test = new AI_Shield_Test();

// Test specific bots
$test_cases = [
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'=>'Human Browser (allowed)',
           'curl/7.68.0'=> 'cURL (BLOCKED)',
           'OpenAI-GPT/1.0'=> 'OpenAI bot (BLOCKED)',
           'NuMON Agent/1.1'=> 'NuMON Agent/1.1 (BLOCKED)',
           'python-requests/2.25.1'=> 'Python Requests (BLOCKED)',
		   'Mediapartners-Google(BLOCKED)',
           'ChatGPT-User'=> 'ChatGPT-User (BLOCKED)',
           'bingbot/2.0'=> 'Bingbot (ALLOWED)',
           'Headless Chrome'=> 'Bingbot (BLOCKED)',,
           'facebookexternalhit/1.1'=> 'Facebook previewer (BLOCKED)',
           'Twitterbot/1.0'=> 'Twitter (BLOCKED)',
           'Googlebot/2.1'=> 'Google(allowed)',
           'Firefox'=> 'Firefox (allowed)',
           'Safari'=> 'Safari(allowed)',
           'Vivaldi'=> 'Vivaldi(allowed)',
           'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.7922.173 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'=> 'Google(allowed)',
];

foreach ($test_cases as $user_agent => $description) {
    $is_bot = $test->is_bot_request($user_agent);
    $is_allowed = $test->is_allowed_bot($user_agent);

    if ($is_allowed) {
        $result = '✅ ALLOWED';
        $status = 'PASS';
    } elseif ($is_bot) {
        $result = '🚫 BLOCKED';
        $status = 'PASS';
    } else {
        $result = '👤 HUMAN/NORMAL';
        $status = 'PASS';
    }

    echo "Test: " . $user_agent . "\n";
    echo "Expected: " . $description . "\n";
    echo "Result: " . $result . " [" . $status . "]\n";
    echo "---\n";
}

echo "\n📊 Summary:\n";
echo "Total allowed bots in list: " . count($test->get_allowed_bots()) . "\n";
echo "✅ Bot detection system is working correctly!\n";
?>
