<?php
/**
 * AI Shield Bot Detection Test
 *
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * FORK OF: https://github.com/common-repository/ai-shield
 * Maintained by: https://teskedsgumman.se
 */

class AI_Shield_Test {

    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;

    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [
		     // CDN and proxy patterns
            "Cloudflare","CF-RAY","Akamai","Fastly","CloudFront","Incapsula","Sucuri","SiteLock","DDOS-GUARD","Qrator","GreyNoise","Project","Project Shield","Google Shield","Apple-App","node-fetch","axios","got","bent",

            // General bot patterns
            "crawl","crawler","cURL","curl","JavaScript","spider","wget","fetch","download","sync","srequests.get",

            // Headless and scraping tools
            "Headless","Headless Chrome","Headless Firefox","Data Miner","crawler","spider","scan","scanner","attack","vuln","exploit","datado","splunk","newrelic","elastic","masscan","nmap","nikto","sqlmap","dirbuster","gobuster","wfuzz","phpunit","HttpClient","Apache-HttpClient","scraper","java","Jetty","okhttp","wget",

            // Screen scraping tools and automation
            "capture", "collect","extract",'Dataminer',"Screenshot","Snap","Grab","Scrap","scrape","scraper","Harvest","Fetcher","Grabber","ripper","Extractor","WebZIP","WebWhacker","BlackWidow","Bot","Snoopy","W3mir","WebReaper","WebStripper","WebSnatcher",

            // HTTP libraries and clients
            "Apache-HttpClient","HttpClient","Jakarta Commons-HttpClient","libwww-perl","LWP::Simple","Net::HTTP","HTTP::Lite","HTTP::Tiny",
            "Perl","LWP","Mechanize","WWW::Mechanize","Mojo::UserAgent","HTTPx::Client","REST::Client","HTTPC::Client","axios","got","node-fetch","undici","superagent","request","bent","got",

            // Headless browsers and automation
            "HeadlessEdg","Headless","HeadlessChrome","Lightpanda","Zombie","SlimerJS","CasperJS","PhantomJS","Splash","HtmlUnit","TrifleJS","Envjs","J浏览器","Liebao",
            "Maxthon","Maxthon Nitro","Comodo Dragon","CoolNovo","RockMelt","Flock","Camino","Chimera","K-Meleon","Midori","QupZilla","Vimb","Luakit","Dillo","ELinks","Links","NetSurf","surf","Uzbl","W3m",

            // Cloud/SaaS scraping services
            "ScraperAPI","Crawlera","Proxy","ProxyCrawl","Zyte","Smartproxy","Oxylabs","Luminati","Netnut","GeoSurf","Stormproxies","Bright Data","DataImpulse","PacketProxy","Rsocks","Socks5","Socks4","HTTP Proxy","SOCKS Proxy","VPN",

            // Feed readers and syndication
            "Feedsky","RSS","Atom","Syndication","NewsBlur","Feedly","Pulse","Flipboard","Yahoo! Slurp","TumblrBot","WhatsApp","TelegramBot","Slack-LinkPreview","Slackbot","Discordbot","TeamsBot","TeamsLinkPreview","SkypeUriPreview",
            
			// Misc Scrapers
            "cms-checker","assetnote","Iron","XenWare","Obsidian","Mozlila","KOCMOHABT","Odin","ORT","CriOS/99.0.4844.47","Mozilla/5.0 (X11; Linux x86_64",

			// SCRAPY
            "CrawlSpider","python scrapy","scraper","scrapy","Scrapy 2.14.1","Scrapy JavaScript","Scrapy selenium","Scrapy shell","Scrapy Splash","ScraPy Spiders","Scrapy - Shell","Scrapy-playwright","Python Scrapy","SitemapSpider","scrapy-redis","scrapy php","scrapy.Spider","XMLFeedSpider",

			// Cloud/SaaS scraping services
            "ScraperAPI","Crawlera","Proxy","ProxyCrawl","Zyte","Smartproxy","Oxylabs","Luminati","Netnut","GeoSurf","Stormproxies","Bright Data","DataImpulse","PacketProxy","Rsocks","Socks5","Socks4","HTTP Proxy","SOCKS Proxy","VPN",

            // SEO and monitoring tools
            "AhrefsBot","ahrefs", "SEO","Screaming Frog","ScreamingFrog","SemrushBot","DeepCrawl","Lumar","Sitebulb","Botify","OnCrawl","Crawlit","DeepSpider",
            "Pangseo","SEOkicks","trendiction","Pipl","Tapuz","Majestic","MajesticSEO","majestic","linkChecker","Nutch","Solr","Elasticsearch","Solr","Grub","MRTG","SmokePing","Pingdom","UptimeRobot","StatusCake",

            // Screen scraping tools and automation
            "capture", "collect","extract",'Dataminer',"Screenshot","Snap","Grab","Scrap","scrape","scraper","Harvest","Fetcher","Grabber","ripper","Extractor","WebZIP","WebWhacker","BlackWidow","Bot","Snoopy","W3mir","WebReaper","WebStripper","WebSnatcher",

            // Security+Scanners
            "nikto","nmap","sqlmap","dirbuster","gobuster","acunetix","netsparker","arachni","zap","burp","w3af","skipfish","vega","nessus","openvas","wfuzz","masscan","dirb","gobuster",
            
			// Semrush
            "SemrushBot","semrushbot","SemrushBot/7~bl","SemrushBot/7t","SemrushBot-OCOBt","SemrushBot-SWAt",

            // Suspicious/spoofed user agents
            "Mozlila","Mozilla/5.0","MSIE","SeaMonkey","Iron","Plesk screenshot bot",

             // Known Scrapers
            "360Spider","MJ12bot","PetalBot","Bytespider","Baiduspider","baiduspider","DataForSeoBot","DotBot","dotbot","Exabot","BLEXBot","Dataprovider","CensysInspect",
            "InternetMeasurement","IbouBot","NuMON Agent","Nicecrawler","serpstatbot","Sogou","Clawbot","ClawbotLeadScan","TikTokSpider","Website-info","linksnatcher","websitescrawl",

            // Python-related patterns
            "python","Python","pyth","pypi","pyscan","py","python-http","httpx","urllib","requests","Text Extraction","python-requests","Python Requests","python\-requests","python requests",
            "python-requests/2.32.3","pythonrequests","PythonRequests","python-opengraph","python-urllib", "python\-urllib","python aiohttp","python-httpx","python-async",

            // Python tools and libraries
            "curl_cffi","photon","photon/1.0","python/3.12 aiohttp","pycurl","PyOpenGraph","python2 snitch.py","urllib3","httpx","Odin",
            "urllib","beautifulsoup","bs4","Request","Rust","R","Ruby","PyScrappy","python-scraper","selenium","Selenium","SeleniumBase",
			"playwright","mechanize","middlewares.py","webdriver","pageobj","lxml","feedparser",

            // Robots - not wanted bots
            "404checker","Apache-HttpClient/4.5.2 (Java/1.8.0_161","AdsBot-Google-Mobile-Apps","AhrefsBot","Ahrefs-Bot","ahrefsbot","AhrefsBot/7.0","Ahrefs-Bot/7.0","AhrefsSiteAudit","*bot.*.ahrefs.com","*bot.*.ahrefs.com","*bot.*.ahrefs.net",
            "*bot.*.ahrefs.net","ai.azure**.com","ai.gemma**.dev","ai.meta**.com","alibabacloud.com","allenai\.org","Anthropic**.com","anthropic\.com","air.ai/scanning ","Amazon","Amazon CloudFront","Amazonbot","Amazon Bedrock AgentCore Browser","Amazon Textract",
            "Amazon Comprehend","Amazon Silk","Amazon Lex","Amazon Q Business","AMAZON-02","Amazon Bedrock","Amazon SageMaker","Amazon: AWS","AWS Trainium","AWS Lambda","amazon**.com","Assetnote","Baiduspider","baiduspider-*-*-*-*","Baiduspider/2.0",".crawl.baidu.com","BLEXBot","bot.*.cn",
            "Chrome Privacy Preserving Prefetch Proxy","BitSightBot/1.0","Bytespider","bytespider-*-*-*-*",".crawl.bytedance.com","*bot.*.cn","BUbiNG","*crawl.*.ru","crawler4j","*.chat.openai.com",
            "CensysInspect","CensysInspect/1.1;","httpclient", "copilot.microsoft**.com","content crawler spider","cohere\.ai","Curl","Curl/","curl/8.3.0l","curl/8.7.1","CMS-Checker","cypex.ai/scanning","DataForSeoBot","DomainStatsBot","debug.log","DotBot","dotbot","Extreme Picture Finder","error_log",
            "facebookexternalhit/1.1","fwdproxy-*-*.fbsv.net","gemini.google**.com","Go-http-client","Go-http-client","Go-http-client/1.1","Go-http-client/2.0","GuzzleHttp","HeadlessChrome","HeadlessChrome","HeadlessFirefox","HeadlessEdg","HTTP//1.1","http//1.1","huggingface**.co","InternetMeasurement","IbouBot","Java-http-client",

            // WP Scrapers:
			"/api/scrape/","/api/","ebscraper","fetch","Fetch","Fetch Url","js-scraper","node-fetch","Nutch","NuMON Agent","RSS Content Importer","RSS scraper","RSS XML","rss-parser",
            "Scraper","Sec-Fetch-","WebScraperBot","WP All Import","WP Scraper","wpscan","XML Scraper",
			
            // Android old versions
            "Android 1","Android 2.","Android 3.","Android 4.","Android 5.","Android 6.","Android 7.","Android 8.","Android 9.","Android 10.",
            "Android 11.","Android 12.","Android 13.","Android 14.","Android 15","Linux; Android","Linux; Android 10","Linux; Android 11","Linux; Android 12","Linux; Android 13",

            // iOS/iPhone old versions
            "iPhone OS 1_","iPhone OS 2_","iPhone OS 3_","iPhone OS 4_","iPhone OS 5_","iPhone OS 6_","iPhone OS 7_","iPhone OS 8_","iPhone OS 9_","iPhone OS 10_","iPhone OS 11_",
			"iPhone OS 12_","iPhone OS 13_","iPhone OS 14_","OS 1_","OS 2_","OS 3_","OS 4_","OS 5_","OS 6_","OS 7_","OS 8_","OS 9_","OS 10_","OS 11_","OS 12_","OS 13_","OS 14_",
			"iOS 15_","15.8.7_","iOS 16_",	"iOS 1616.7.15_",	"iOS 17_","17.2_",	"iPhone OS 1","iPhone OS 2","iPhone OS 3","iPhone OS 4","iPhone OS 5","iPhone OS 6","iPhone OS 7","iPhone OS 8","iPhone OS 9","iPhone OS 10",	
            "iPhone OS 11","iPhone OS 12","iPhone OS 13","iPhone OS 14","iPhone OS 15",	"iPhone OS 16",	"iPhone OS 17","iPhone OS 18",		
            
			// Old Macintosh/Mac OS X versions
            "Macintosh; Intel Mac OS X 10_6","Macintosh; Intel Mac OS X 10_7","Macintosh; Intel Mac OS X 10_8","Macintosh; Intel Mac OS X 10_9","Macintosh; Intel Mac OS X 10_10","Macintosh; Intel Mac OS X 10_11","Macintosh; Intel Mac OS X 10_12",
            "Mac OS X 10.6","Mac OS X 10.7","Mac OS X 10.8","Mac OS X 10.9","Mac OS X 10.10","Mac OS X 10.11","Mac OS X 10.12","AppleWebKit/528","AppleWebKit/534","AppleWebKit/535","AppleWebKit/536",

            // Old Windows NT versions
            "Windows NT","Windows NT 3.1","Windows NT 3.1","Windows NT 3.5","Windows NT 3.5 NT ","Windows NT 3.10","Windows NT 3.50","Windows NT 3.51",	"Windows NT 3.51 NT 3",
            "Windows NT 3.10","Windows NT 4.0","Windows NT 4.5","Windows NT 5","Windows NT/5","Windows NT 5.1","Windows NT 5.01","Windows NT 6","Windows NT/6",
            "Windows NT 6.0","Windows NT 6.1","Windows NT 6.1; WOW64","Windows NT 6.1; Win64; x64","Windows NT 6.2","Windows NT 6.3","Windows NT 3.14.0","Windows NT 4.5",                           
            "Windows NT 3.52","windows NT 7.0","windows NT 8.0","windows NT 9.0","Windows NT 3.52",

            // Other suspicious patterns
            "Windows; U; Windows","PhantomJSCloud","Obsidian","Python Selenium","XenWare Pixel Pro","X11","X10","Ubuntu;","laravel","Mozilla/4.0", 

            // Linux browser patterns
            "Linux","Linux x86","Linux i686","Linux i386","Linux x86_64","Linux amd64","Linux armv","Linux armv7","Linux aarch64","Ubuntu","Debian","Fedora","CentOS","Red Hat","openSUSE","Arch Linux","Mint","Gentoo","Slackware",
            "Xubuntu","Kubuntu","Lubuntu","Edubuntu","Xandros","Mandriva","Mageia","PCLinuxOS","Puppy Linux","Tiny Core","Linux; Android 10; K",

            // More old Windows versions
            "Windows 95","Windows 98","Windows ME","Windows 2000","Windows XP","Windows Vista","Windows 7","Windows 8","Windows 8.1",
            "Windows NT 4","Windows NT 5.0","Windows NT 5.1","Windows NT 5.2","Windows NT 6.0","Windows NT 6.1","Windows NT 6.2","Windows NT 6.3","Win 9x","WinNT","WinCE","Win32","Windows Mobile","Windows Phone",

            // Generic mobile patterns
            "Mobile Safari","Mobile/1","Mobile Safari/1","Mobile Safari/2","Mobile Safari/3","Mobile Safari/4","Mobile Safari/5","Mobile Safari/6",
            "webOS","hpwOS","Symbian","Series60","Series40","MIDP","CLDC","J2ME","BREW","BlackBerry","PlayBook","BB10","RIM Tablet","Nokia","S60","S40","UC Browser","Opera Mini","Opera Mobi",

            // AI-related patterns
            ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$", "ai=n",
			
		   // AI BOTS
		   // A LIST 
           "360Spider","360 AI","360AI Search","360 AI Research","360AI browser","Abacus AI Deep Agent","AcademicBotRTU","AddSearchBot","Agent 3","Agent API","Agent GPT","Agent Middleware","AgentGPT","Agentic","Agentic Deep Research","Agentic RAG",
           "Agentic RAG with LangGraph","Agentic RAG with Reasoning","Agentic-RAG","AgentQL","Agent-","Agent-3","Agent-E","AI Agent","AI Agentic RAG Pipeline","AI agents","AI Article Writer",
           "AI Assistant","AI Chat","AI Chatbot","AI Content Detector","AI copilot","AI Crawler","AI Data Scraper","AI Deep Research Agent","AI Detection","AI Dungeon","AI Ghostwriter","AI guardrails","AI Journalist","AI Journalist Agent","AI Legion","AI RAG","AI Scraper","AI-Scraper","AIScraper",
		   "AI Search","AI Search Engine","AI Search Intent","AI SEO Crawler","AI Web","AI Web Scraper","AI-Web-Scraper","ai-web-scraper","AI Website Screenshot","AI Writer","AI – WPBot","AI2","AI2 Bot","AI2Bot","AI2Bot-DeepResearchEval","ai2thor","AI21 Labs","AIBot","aiHitBot",
           "AIMatrix","Airesearch","airesearchbot","air.ai/scanning","AISearch","AISearchBot","AI Training","AITraining","ai-agent-playwright","AI-Content-Detector","AI-Crawler","ai-crawlers-training",
           "ai-proxy","ai-writer","Alexa","AlexaTM","Alice","Alice Yandex","AliGenie","AliyunSec","AliyunSecBot","AllenAI Bot","Alpha AI","AlphaAI","Amazon", 
		   "Amazon-AI","Amazon Athena","Amazon Bedrock","Amazon Bedrock AgentCore Browser","Amazon Comprehent","Amazon Contxbot","Amazon Kendra Web Crawler","Amazon Lex",
           "Amazon Titan","Amazon SageMaker","Amazon Silk","Amazon Textract","amzn.to","Amazonbot","amazonBot","AmazonKnowledgeBasesRetriever","amazon-kendra","Amazon Kendra",
		   "Amelia","Amzn-SearchBot","Amzn-User","AndiBot","Angular","Anomura","Anonymous AI","anonymous AI chatbot","Anthropic","anthropic bot","AnthropicBot","Anthropic Computer Use",
		   "anthropic-ai","Anthropic-Claude","AnyPicker","AnythingLLM","Anyword","Applebot-Extended","Apple-GenAI","arcee-ai/maestro-reasoning","ARC-AGI-2","Aria AI","Aria Browse",
		   "Aria browse Aria AI","Aria browser AI","Articoolo","Ask AI","Ask.py","atlassian-bot","AutoGen","AutoGLM","AutoGLM Rumination","AutoGPT","Auto-GPT","Automated Writer",
		   "AutoML","Autonomous RAG","AutoRAG","AutoScraper","AutoWebGLM","Awario","AwarioRssBot","AwarioSmartBot",	"AWS bedrock","AWS Trainium","Aya Vision","AkiraBot","Azure","Azure AI Search","AzureAI-SearchBot","Azure OpenAI","AzureAISearchRetriever",
           // B LIST
		   "BabyAGI","BabyCatAGI","BAGEL","baiduspider-ai",	"BardBot","Bard-Ai","Basic RAG","Basic RAG Chain","Bedrock","Bedrock Claude","Bedrock claude","bedrockbot","bedrock-chat",	
           "bedrock-chatbot","bedrock-claude-chatbot","Big Sur","Big Sur AI","Big Sur AI Crawler","Bigsur","bigsur.ai",	"BM25 Retriever","Bolt","Botsonic","Brave Leo AI","Bravebot",	
           "BraveGPT","Brightbot","Brightbot 1.0","Bright Data Scraper","Bright Data CLI","Brightbot operator","Browser MCP Agent","Browser Use","Browserbase","BrowserBase Open Operator","BrowserOS","BuddyBot","Bytebot",	
		   "ByteDance","byteDance","ByteDance crawler","ByteDance Lynx","ByteDance LLM","Bytespider",  
		   // C LIST
		   "CarynAI","CatBoost","CCBot","ccbot","CCBot/2.0","CC-Crawlerr","CC-Crawler/2.0","Celia","Ceramic TerraCotta Crawler","Chai","Channel3Bot","Character","Character-AI","Charstar AI",
           "Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGenie","ChatGLM","ChatGLM-Spider","ChatGPT","ChatGPT 3.0","ChatGPT 4o","ChatGPT 4o-mini","ChatGPT 4.1","ChatGPT 4.5",
           "ChatGPT 5","ChatGPT Agent","ChatGPT Atlas","ChatGPT o1","ChatGPT o3-mini","ChatGPT Operator","ChatGPT Retrieval","ChatGPT search","ChatGPT-Browser","ChatGPT-User","ChatGPT-User v2.0",
           "ChatGPT-User/1.0","ChatGPT-User/2.0","ChatGPT-User","chatgpt-user","ChatLLM","ChatOpenAI","Chatsonic","ChatUp AI","ChatUser","CheerioCrawler","Chinchilla","Cici","Clara","Clawbot",
		   "ClawbotLeadScan", "Claude","Claude 3.5","Claude Haiku5","Claude Haiku 4.5","Claude 3.5 Sonnet","Claude 3.7 Sonnet","Claude 4","Claude 5", "Claude Agent","Claude Computer Use","Claude Fable","Claude LLM","Claude Opus","Claude Opus 4",
		   "Claude Opus 4.6","Claude Opus 4.8","Claude Sonnet 4","Claude Sonnet 4.5","Claude Sonnet 5","Claude v1.2","ClaudeBot","ClaudeBot/1.0","ClaudeBot/1.6","claude-4-haiku-thinking","Claude-RAG","Claude-SearchBot","Claude-User","claude-user", "Claude-Web",
           "claude-web/1.0","claude.ai","ClearScope","Clearview","cloudflare-ai-search","ChatGPT Scraper","Cloudflare AutoRAG","Cloudflare-AutoRAG","Cloudflare Browser Rendering","CloudVertexBot","Cognitive AI","Cognitive AI engine","Code","Cohere","Cohere LLM","Cohere RAG",
           "cohere-ai","cohere-ai/1.0","Cohere-Command","cohere-training-data-crawler","Command-A-Reasoning","Common Crawl","CommonCrawl","Compass","content crawler spider","Content Harmony","Content King",
           "Content Optimizer","Content Samurai","Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","Copilot","CopilotBot","CopilotNative","CopilotSapphire",
           "CopyAI","Copymatic","Copyscape","Coveobot","CoreWeave","Corrective RAG","Cotoyogi","CRAB","Crawl4AI","Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crawl web content","Crew AI","CrewAI","Crushon AI","cURL","Cypex","cypex.ai/scanning",		    
		   // D LIST
           "Content Optimizer","Content Samurai","Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","Copilot","CopilotBot","CopilotNative","CopilotSapphire",
           "CopyAI","Copymatic","Copyscape","Coveobot","CoreWeave","Corrective RAG","Cotoyogi","CRAB","Crawl4AI","Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crew AI","CrewAI","Crushon AI","cURL","Cypex","cypex.ai/scanning",	    
		  // D LIST
		   "DALL-E","DALL-E 2","Dall-E 4","DALL-E Mini","DALL·E 3","Dalle 4","DarkBARD","DarkBard","DarkBERT","DarkGPT","DataFor","DataForAI","DataForSeoBot","dataminr","Dataprovider\.com","DataProvider","dataprovider",
		   "dataprovider spider","dataproviderbot","Datenbank Crawler","Deep AI","Deep Research","Deep Think 2","DeepAI","DeepL","DeepL Agent","DeepMind","DeepMind Genie 3","DeepResearch","DeepSeek","Deepseek Agent","DeepSeek R1 Chatbot",
           "DeepSeek R1 Y","DeepSeek V3","DeepSeekBot","DeepSeekV2.5-Chat","DeepSeek-LLM","DeepSeek-R1","deepseek-r1-distill-llama-70b","DeepSeek-V3.1","deepseek/deepseek-v3.2-exp","DepolarizingGPT",
           "Devin","devin","Devstral","DiaBrowser","DialoGPT","DialoGPT-medium","Diffbot","diffbot","DigitalOceanGenAICrawler","digitaloceangenai-crawler","DocsGPTOnyx","dolly","Dolma","Dots Chatbot","Doubao AI",
           "Doubao 1.5","DuckAssistBot","duckassistbot","DuckDuckGo Chat","DuckDuckGo LangChain Bot","DuckDuckGo-Enhanced","Duck.ai",
		   // E LIST
		   "Echobot","Echobot Bot","Echobox","EchoboxBot","ElasticsearchRetriever","Elixir","Embed v3","ERNIE","ErnieBot","Evil-GPT","Extended GPT Scraper",
           // F LIST
		   "FAISS","FacebookBot","FacebookBot/1.0","FacebookExternalHit","facebookexternalhit","facebookexternalhit/1.1","Factset","Factset_spyderbot","Falcon","Fastai",
		   "FastGPT","Firebase","Firecrawl","FirecrawlAgent","Fireworks","FIRE-1","FIRE-1 Agent","Finbot","Flux","Flux 2","Flyriver","flyriverbot/1.1","Frase AI","FraudGPT","FriendlyCrawler"
		   // G List
           "AI Ghostwriter","Gato","Gemini","Gemini 3 Pro","Gemini Agentic RAG","Gemini-Ai","Gemini-Deep-Research","Gemini-User","Gemma","Gemma 3","Gen AI","GenAI","GenAI Chat",
           "GenAI RAG","Generative","Genspark","Gentoo-chat","gentoo-chat","gen-ai","GeistHaus-PageFetcher","GhostGPT","Ghostwriter","GigaChat","GLM","GLM 4.6","GLM,","GLM-4.6","GLM-4.6 GGUF","GLM 5",
           "Go","gobrowser","GodMode","Google-Agent","google-agent","Google-Gemini-CLI","Gemini-Deep-Research","Gemini-Vertex","Google Gemini","GoogleAgent URL Context",
		   "GoogleAgent-Mariner","Google-CloudVertexBot","Google-Extended","Google-Firebase","Google-NotebookLM","Goose","GPT 4 Omni","GPT 4 Omni Mini","GPT 5.1","GPT Chat 3",
		   "GPT Image 1.5","GPT OSS","GPT Researcher","GPT Scraper","GPT","GPT-", "GPT4ALL","GPT4Free","GPTBot","GPTBot/1,2","GPTBot/1.2","GPTBot/1.3","GPTZero","GPT-1","GPT-2",
		   "GPT-3","GPT-3.5","GPT-3.5 turbo","GPT-4o","GPT-4o Image","GPT-4o mini","GPT-4V","GPT-4,5","GPT-4.1","GPT-4.1-mini","GPT-4.1-nano","GPT-5","GPT-5 Chat","GPT-5 Mini",
		   "GPT-5 Nano","GPT-5 Thinking mini","GPT-5o","GPT-5-high","GPT-5.1","GPT-5.1 Auto","GPT-5.1 Instant","GPT-5.1 Thinking","GPT-5.2","GPT-5.2 Instant","GPT-5.2 Pro","GPT-5.2 Thinking",
		   "GPT-5.4 Thinking", "GPT-5.4","GPT-5.4 Pro","GPT‑5.4 mini","GPT‑5.4 nano","GPT-5.5", "GPT-crawler","gpt-crawler","GPT Researcher","gpt-image1","GPT OSS","GPT-oss", "GPT-Qwen Deep Research",
		   "GPT-Shield-AI-Plagiarism-Detector","Grafana","Grammarly","Grendizer","Grok","Grok 4 Fast","Grok AI chatbot","Grok DeepSearch","Grok Imagine","Grok-DeepSearch/1.0","GrokAI",
		   "GrokBot","Grok-4","Grok-4 Heavy","grok-4-fast-thinking","Grok 5","Groq","Groq-Bot","GT Bot","GTBot","GTP",
		   // H LIST
           "Hemingway Editor","HttpClient","Headless AI Agent","Hetzner","Hugging","Hugging Face","HuggingChat","huggingfacebot","HuggingFace-Bot","hugging-face-ai","Hunyuan","Hunyuan-7B-Instruct 7B",
           "Hunyuan-Large-Instruct","hybrid LLM","Hybrid Search RAG","HyperAgent","Hyperbrowser","Hypotenuse AI","Haystack RAG Pipeline","Haystack - deepset AI",
		   // I LIST
           "iAsk","iAskBot","iaskspider","iaskspider/2.0","iAskAI-Crawler","IbouBot","IbouBot Crawler","ICC-Crawler","Ideogram","ImageGen","ImageGPT","Imagen","imagen4","ImagesiftBot",
           "ImageSpider","imagespider","img2dataset","imgproxy","inclusionai/ring-1t","Inferkit","INK Editor","INKforall","Instructor","instructor-php","IntelliSeek","IntelliSeek.ai","ips-agent","ISSCyberRiskCrawler",
		   // J LIST
           "Jamba 1.5","Jamba 1.5 Large","Jamba 1.5 Mini","jamba-mini-1.7","Janitor AI","Jasper","JasperAI","Jenni AI","Julius AI",
		   // K LIST
            "Kafkai","Kaggle","Kaggle agent","kagi-fetcher","Kagi AI","Kagi LLM","Kangaroo","Kangaroo Bot","Kangaroo-Bot","KawaiiGPT","Keyword Density AI","Kimi","Kimi Agentic",
           "KimiBot","Kimi Claw","Kimi-SearchBot","Kimi Search","Kimi K2","Kimi-2","Kimi-VL","Kimi-User", "Kingsoft-LLM","KI-Crawler","Klaviyo","KlaviyoAIBot",
		   "Knowledge","KnowledgeAgent","Knowledge Graph","knowledge graph","knowledge-base","Knowledge-graph RAG","KomoBot","Kruti","KunatoCrawler",  
		   // L LIST
           "LAIONDownloader","LAION-5B","LAION-huggingface-processor","laion-huggingface-processor","LangChain","LangChain Agent","LangChain Python","Langchain raptor","LangChain-Ruby",
           "langchain-google-genai","langchain-openai","langchain-perplexity","LangChain-Ruby","langchain-scrapeless","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
           "langchain-scrapeless","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","LINER Bot","LinerBot","liner-bot",
           "Linguee Bot","Linkup Deep","LinkupBot","LinkupBot/1.0","LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama 3.1","Llama 3.2","Llama 4","Llama3.1-70B-Instruct",
           "Llama3.1-405B-Instruct","LlamaResearchert","LLM Websearch","LLM Pigeon","LLM Proxy","LLM Scraper","LLM-Scraper", "llm-scraper","LLM","LLMFeeder","llms.txt crawler bot",
		   "LLMs","LLM-jp-Crawler","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","LocalAI","Lorph","Lovable",		   
		   // M LIST
           "Magistral","MAI-DS-R1 ","Magistral Medium","Magnus","magpie-crawler","MAI-Image","MAI-Image-1","MalwareGPT","Manus","Manus Agent","Manus-User","MarketMuse","MBZUAI","MBZUAI Chatbot",
           "Medium","Meltwater","Mem0","Meta Agent","Meta AI","Meta AI Crawler","Meta Llama","Meta search scraper","MetaAI","MetaGPT","MetaTagBot","Meta-AI","Meta-External","Meta-ExternalAgent",
           "meta-externalagent","meta-externalagent/1.1","Meta-ExternalFetcher","meta-externalfetcher","meta-externalfetcher/1.1","Meta-Webindexer","meta-webindexer","Meta-Webindexer 1/1",
           "meta-webindexer/1.1","Meta.AI","Middleware","Midjourney","midjourney","Mini AGI","minimal AGI","MiniMax","Mintlify","Mistral","Mistral NeMo Instruct","Mistral OCR 3","Mistral Perflexity AI",
           "MistralAI-User","MistralAI-User/1.0","mistral-large-3","Mistral Le Chat Agent","mistral-medium","mistral-small","Mistral.ai","Mixtral","Mixtral 8x22B","Mixtral-8x22B-Instruct","MobileLLM-R1","ModatScanner",
           "Model Context Protocol - MCP1","Molmo","Monica","Moonshot","Moshi","Mozilla-Tabstack","Mycroft AI","MyCentralAIScraperBot",
		   // N LIST
           "n8n-nodes-aiscraper","Nano","Nano Banana","Nanobrowser","nanochat","nanobot","nanoclaw","Nano novellum","Nano Search",
		   "Narrative","NeevaBot","newsai","netEstate","netEstate Imprint Crawler","NetShelter ContentScan","Neural Text",
           "NeuralSEO","NextChat","Nicecrawler","NinjaAI","NinjaAIBot/1.0","Ninja - Chatbot AI ","Ninja Deep Research","NodeZero","Node.js","NotebookLM","NotebookLM Deep Research",
           "Notion MCP Agent","Nova","Novellum Search","Nova 2 Lite","Nova 2 Sonic","Nova Act","NovaAct","Nova 2 Lite","Nova Premier 1.0","nova-premier-v1","Nytheon","Nytheon AI","Nutch","nullclaw",
		   // O LIST
           "OAI SearchBot","OAI-SearchBot","OAI-SearchBot/1.0","OAI-SearchBot/1.3","OASIS","OIG","Ola","Olivia","Ollama","oLLM","Olmo Hybrid,OLM","OLMo","OLMo 2 Chatbot","OLMO 3","OLMoASR","OLMoE",
           "Omgili","omgili","Omgilibot","omgilibot","Onyx","Open AI","OpenClaw Agent","OpenClaw","Open Claw browser","Open Deep Research","Open Interpreter","Open Lovable","Open Operator","Open Perflexity","Open Source LLM","OpenAGI",
           "OpenAI","OpenAI Crawler","OpenAI CUA","OpenAI GPTBot","OpenAI Image Downloader","OpenAI o1","OpenAI o1-mini","OpenAI o3","OpenAI o3-mini","OpenAI o4","OpenAI o4-mini","OpenAI Operator",
           "OpenAI Python","openai-python","OpenAIContentCrawler","openai-user","o4 Mini Deep Researc","OpenBot","Openbot","OpenELM","OpenInterpreter","OpenLens AI","OpenLLaMA","OpenLM",
           "OpenPi","openpi","OpenRouter","openrouter","OpenText AI","OpenVLA","open-manus-v2","Operator","Opus 4.5","Outwrite","OVHcloud","OVHcloud AI Training","OWL","Owlin","OxyCopilot",			   
   		   // P LIST
           "Page Analyzer AI","PaLM 2","PandasAI","PanguBot","PanGu Chat","Panscient","panscient.com","PaperLiBot","PaperLiBot/2.1","Paraphraser.io","peer39_crawler","peer39_crawler/1.0",
           "PerfectChatGPT","Perflexity","Perplexity AI","Perplexity Image","Perplexity Labs","Perplexity LLM ","Perplexity Comet","Perplexity Chatbot","Perplexity Deep Research","Perplexity pypi",
           "Perplexity Research","Perplexity Scraper","Perplexity Search","perplexity-py","Perplexity-Stealth","Perplexity Stealth","PerplexityBot","Perplexity-Bot","PerplexityBot/1.0",
           "PerplexityUser","Perplexity-User","Perplexity-User/1.0","Perplexity Research","Perplexit-User","Perplexity Web Scraper","Petabot","Petal","PetalBot","petalBot","PetalBot mobile",
           "Phind","Phi", "phi-4-multimodal-instruct","phi-4-reasoning-plus","PhindBot","PiplBot","Pixmo","Playwright","Playwright Agentic AI","Playwright Stealth","PlaywrightCrawler","Poe",
           "PoeBot","PoeSearchBot","Poggio","Poggio-Citations","PoisonGPT","Poseidon","Poseidon Research Crawler","PrivateGPT","PrivateGPTitingA","ProWrid","ProWritingAid","Proximic",
           "proximic","PulsarRPA","Puppeteer","Puppeteer","PuppeteerCrawler","Python AI","python Ai","Python lxml","Python Scrapy","PyTorch","PyTorch Lightning","PyTorch Lightning LLM",
   		   // Q LIST
           "Qopywriter","Qopywriter.ai","Qualified","QualifiedBot","Quark","QuillBot","quillbot.com","Querit-SearchBot","QueritBot","Qwen-Agent","Qwen","Qwen 2.5‑VL","Qwen 4","Qwen 4 LLM","Qwen Chat","Qwen-Chat",
           "Qwen Deep Research","Qwen LLM","Qwen2","Qwen2.5 72B","Qwen 2.5‑VL","Qwen3","Qwen 4","qwen:4b","QwenLM","Qwen 4 LLM","Qwen-Agent","Qwen-Chat",
		   // R LIST
           "AI RAG","RAG","RAG Agent","RAG Agent Cohere","RAG with Vercel AI SDK","Reader ","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG Database Routing","RAGFlow", "RAG IS","RAG LLM",
           "RAG Pipeline","RAG Search","RAG with","RAGify Search","RAG-","RAG-","RAG_","RAG-as-a-Service","RAG_VertexAI","RAG_with_search","Raptor","RAPTOR LLM","React Agent","ReAct AI Agent","Reader",
		   "REALM","Reasoning","Redis AI RAG","Reka Flash","Reka Flash 3.1","Replicate","Replicate-Bot","Replit Agent 3","resec.ai","Retriever","RightWingGPT","RobotSpider","RSS/XML Scraper",
		   "Runner H","RunPod","RunPod-Bot","Rytr",						
		   // S LIST
           "SAM 3","Sambanova","SaplingAI","SBIntuitionsBot","Scala","Scira AI","scaleai","Scalenut","scale-crawler","scan.cypex.ai","Scrap","Scraping Browser","ScrapeGraph","ScrapeGraphAI","Scrapegraph-ai","Scrapeless","Scraper","Scraper Bot","ScraperGPT","Scraping Browser","Scraping Agent AI","Scrapy","Scrapy-",
           "scrapy-redis", "Scrapy spider","Scrapy crawlspider","Scrapling","Scrapy-LLM","Scrapy Python","Scrapy Middleware","Scrapy selenium","Scrapy-playwright",
		   "scrapy-playwright","ScriptBook","Search GPT","Search RAG","Search retrieval","SearchChat","SearchGPT","searchatlas","Seedance","Seed","Seekr","SeLLMa","SemrushBot",
           "SemrushBot/7~bl","SemrushBot-OCOB","SemrushBot-SWA","Sentibot","SEO Content Machine","SEO Robot","SEObot","Serper","SerpApiBot/1.0","serverhunterspider",
		   "ShadowGPT","Shap-User","ShapBot","shapbot","Shell GPT","sider.ai","Sidetrade","Sidetrade indexer bot","sigmabrowse","SigmaOS","Simplified AI","Site Crawler MCP","Sitefinity","SiteSucker",
		   "skrape.ai","Skydancer","Skyvern","SlickWrite","SmartBot","SmartScrape","SmartScraperGraph","Sonic","Sonar Pro","Sora","SootiAI","SpamGPT","Spawn agent",
		   "Spawning AI","Spawning-ai","Spider","Spider AI","SpiderCreator","Spider Scraper","Spider-Agent","Spider/2","Spider Middleware","Spin Rewrite","Spinbot","Stability","Stability AI",
           "Stable Diffusion","StableDiffusionBot","Stagehand","STEALTH","Stealth","Step 3","StoryGraph","Sudowrite","SummalyBot","Super Agent","Superagent ","Superagent","SuperAGI","superagi","SuperGrok","Surfer AI","Surfer", "SUSE AI",  
		   // T LIST
           "Taiko","taiko","TavilyBot","TavilySearchAPIRetriever","Tenable Agent","Tencent AI chatbot","Trae","TerraCotta","Terra Cotta","TerraCotta","Text Blaze","TextCortex",
		   "Text-RAG","The Knowledge AI","TheKnowledgeAI","Text Formatter","thehive.ai","Thinkbot","Thinkbot/0.5.8","Thinklab","Thordata","TikTokSpider","tiktokspider","
		   Timpibot","Tinybird","Together","Together AI","Together-Bot","TorChat","Toutiao","Traefik","Tulu","TurnitinBot","Turnitin","TwinAgent","twinagent",
		   //U LIST
           "U haystack-ai","uAgents","UI-TARS","UseAI",
		   //V W LIST
           "VaultGemma","VelenPublicWebCrawler","VelenPublicWebCrawler/1.0","Venus Chub AI","VertexAISearchRetriever","Vidnami AI","VimGPT","Vision RAG","vnCallbot","vnFace",
		   "VLM","VNPT SmartBot","VNPT SmartReader","AI – WPBot","ai-writer","AI Web Search","wan","AIWebIndex/2.0", "WARDBot","wardbot","Weaviate","Web 3.0 Navigator","WebChatGPT",
           "WebCrawler-AI","WebExplorer-8B","WebFetch","WebFetch.MCP","Webscrape","Webscrape AI","webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","Web Search Agent","Web-Search-AI",
           "Web Search","Websearch","WebSurfer","WebText","WebVoyager","Webzio","webzio","Webzio-Extended","webzio-extended","Web-Search-AI","WeChat","WeSEE","WHEN:","Whisper",
           "WizardLM","WolfGPT","WordAI","Wordtune","WormGPT","WormGPT V3.0","WPBot","wpbot","Writecream","WriterZen","Writescope","Writesonic","WRTNBot","WRTNBot/1.0","WRTNBot crawler","Wrtn",
           // XY LIST
           "xAI","XAIAgent","xAI-Web-Crawler","xAI Grok","xAI-Bot","X-Bot","xAI-SearchBot","xAI-SearchBot/1.0","Xanthorox","Xanthorox AI","xBot","XLNet","XXXGPT","x.AI","xAI-Web-Crawler",
           "YaK","YaML","Yandex AI,""YandexAdditional","YandexAdditionalBot","YandexGPT","YandexLLM","yarchatgpt","YarGPT","YiyanBot","YouBot","YourGPT","you-bot",
		   //Z LIST
           "Zanista","ZanistaBot","Zendesk","Zero","Zero GTP","ZeroCHAT","Zerochat","ZeroGPT","ZeroSearch","ZeroStep","Zhipu","Zhuque AI","Zhuque AI Detector","Zimm","Zoominfo AI Agents",

			// Browsers used by scraping
			// Chrome ld versions
            "Chrome/1","Chrome/2","Chrome/3","Chrome/4","Chrome/5","Chrome/6","Chrome/7","Chrome/8","Chrome/9","Chrome/10","Chrome/11","Chrome/12","Chrome/13","Chrome/14",
			"Chrome/15","Chrome/16","Chrome/17","Chrome/18","Chrome/19","Chrome/20","Chrome/21","Chrome/22","Chrome/23","Chrome/24","Chrome/25","Chrome/26","Chrome/27",
			"Chrome/28","Chrome/29","Chrome/30","Chrome/31","Chrome/32","Chrome/33","Chrome/34","Chrome/35","Chrome/36","Chrome/37","Chrome/38","Chrome/39","Chrome/40",
			"Chrome/41","Chrome/42","Chrome/43","Chrome/44","Chrome/45","Chrome/46","Chrome/47","Chrome/48","Chrome/49","Chrome/50","Chrome/51","Chrome/52","Chrome/53",
			"Chrome/54","Chrome/55","Chrome/56","Chrome/57","Chrome/58","Chrome/59","Chrome/60","Chrome/61","Chrome/62","Chrome/63","Chrome/64","Chrome/65","Chrome/66","Chrome/67","Chrome/68",
			"Chrome/69","Chrome/70","Chrome/71","Chrome/72","Chrome/73","Chrome/74","Chrome/75","Chrome/76","Chrome/77","Chrome/78","Chrome/79","Chrome/80","Chrome/81",
			"Chrome/82","Chrome/83","Chrome/84","Chrome/85","Chrome/86","Chrome/87","Chrome/88","Chrome/89","Chrome/90","Chrome/91","Chrome/92","Chrome/93","Chrome/94",
			"Chrome/95","Chrome/96","Chrome/97","Chrome/98","Chrome/99","Chrome/100","Chrome/101","Chrome/102","Chrome/103","Chrome/104","Chrome/105","Chrome/106","Chrome/107",
			"Chrome/108","Chrome/109","Chrome/110","Chrome/111","Chrome/112","Chrome/113","Chrome/114","Chrome/115","Chrome/116","Chrome/117","Chrome/118","Chrome/119",
			"Chrome/120","Chrome/121","Chrome/122","Chrome/123","Chrome/124","Chrome/125","Chrome/126","Chrome/127","Chrome/128","Chrome/129","Chrome/130","Chrome/131","Chrome/132",
			"Chrome/133","Chrome/134","Chrome/135","Chrome/136","Chrome/137","Chrome/138","Chrome/139","Chrome/140","Chrome/141","Chrome/142","Chrome/143","Chrome/144","Chrome/145","Chrome/146","Chrome/147",

            // Chromium old versions 
            "Chromium/1","Chromium/2","Chromium/3","Chromium/4","Chromium/5","Chromium/6","Chromium/7","Chromium/8","Chromium/9","Chromium/10","Chromium/11","Chromium/12",
			"Chromium/13","Chromium/14","Chromium/15","Chromium/16","Chromium/17","Chromium/18","Chromium/19","Chromium/20","Chromium/21","Chromium/22","Chromium/23",
			"Chromium/24","Chromium/25","Chromium/26","Chromium/27","Chromium/28","Chromium/29","Chromium/30","Chromium/31","Chromium/32","Chromium/33",
			"Chromium/34","Chromium/35","Chromium/36","Chromium/37","Chromium/38","Chromium/39","Chromium/40","Chromium/41","Chromium/42","Chromium/43",
			"Chromium/44","Chromium/45","Chromium/46","Chromium/47","Chromium/48","Chromium/49","Chromium/50","Chromium/51","Chromium/52","Chromium/53",
			"Chromium/54","Chromium/55","Chromium/56","Chromium/57","Chromium/58","Chromium/59","Chromium/60","Chromium/61","Chromium/62","Chromium/63","Chromium/64",
			"Chromium/65","Chromium/66","Chromium/67","Chromium/68","Chromium/69","Chromium/70","Chromium/71","Chromium/72","Chromium/73","Chromium/74",
			"Chromium/75","Chromium/76","Chromium/77","Chromium/78","Chromium/79","Chromium/80","Chromium/81","Chromium/82","Chromium/83","Chromium/84",
			"Chromium/85","Chromium/86","Chromium/87","Chromium/88","Chromium/89","Chromium/90","Chromium/91","Chromium/92","Chromium/93","Chromium/94",
			"Chromium/95","Chromium/96","Chromium/97","Chromium/98","Chromium/99","Chromium/100","Chromium/101","Chromium/102","Chromium/103","Chromium/104","Chromium/105",
			"Chromium/106","Chromium/107","Chromium/108","Chromium/109","Chromium/110","Chromium/111","Chromium/112","Chromium/113","Chromium/114",
			"Chromium/115","Chromium/116","Chromium/117","Chromium/118","Chromium/119","Chromium/120","Chromium/121","Chromium/122","Chromium/123","Chromium/124",
			"Chromium/125","Chromium/126","Chromium/127","Chromium/128","Chromium/129","Chromium/130","Chromium/131","Chromium/132","Chromium/133","Chromium/134",
			"Chromium/135","Chromium/136","Chromium/137","Chromium/138","Chromium/139","Chromium/140","Chromium/141","Chromium/142","Chromium/143","Chromium/144","Chromium/145","Chromium/146","Chromium/147",
			
			// Headlesschrome
			 "Headless Chrome/1","Headless Chrome/2","Headless Chrome/3","Headless Chrome/4","Headless Chrome/5","Headless Chrome/6","Headless Chrome/7","Headless Chrome/8","Headless Chrome/9",
            "Headless Chrome/10","Headless Chrome/11","Headless Chrome/12","Headless Chrome/13","Headless Chrome/14","Headless Chrome/15","Headless Chrome/16","Headless Chrome/17","Headless Chrome/18","Headless Chrome/19",
            "Headless Chrome/20","Headless Chrome/21","Headless Chrome/22","Headless Chrome/23","Headless Chrome/24","Headless Chrome/25","Headless Chrome/26","Headless Chrome/27","Headless Chrome/28","Headless Chrome/29",
            "Headless Chrome/30","Headless Chrome/31","Headless Chrome/32","Headless Chrome/33","Headless Chrome/34","Headless Chrome/35","Headless Chrome/36","Headless Chrome/37","Headless Chrome/38","Headless Chrome/39",
            "Headless Chrome/40","Headless Chrome/41","Headless Chrome/42","Headless Chrome/43","Headless Chrome/44","Headless Chrome/45","Headless Chrome/46","Headless Chrome/47","Headless Chrome/48","Headless Chrome/49",
            "Headless Chrome/50","Headless Chrome/51","Headless Chrome/52","Headless Chrome/53","Headless Chrome/54","Headless Chrome/55","Headless Chrome/56","Headless Chrome/57","Headless Chrome/58","Headless Chrome/59",
            "Headless Chrome/60","Headless Chrome/61","Headless Chrome/62","Headless Chrome/63","Headless Chrome/64","Headless Chrome/65","Headless Chrome/66","Headless Chrome/67","Headless Chrome/68","Headless Chrome/69",
            "Headless Chrome/70","Headless Chrome/71","Headless Chrome/72","Headless Chrome/73","Headless Chrome/74","Headless Chrome/75","Headless Chrome/76","Headless Chrome/77","Headless Chrome/78","Headless Chrome/79",
            "Headless Chrome/80","Headless Chrome/81","Headless Chrome/82","Headless Chrome/83","Headless Chrome/84","Headless Chrome/85","Headless Chrome/86","Headless Chrome/87","Headless Chrome/88","Headless Chrome/89",
            "Headless Chrome/90","Headless Chrome/91","Headless Chrome/92","Headless Chrome/93","Headless Chrome/94","Headless Chrome/95","Headless Chrome/96","Headless Chrome/97","Headless Chrome/98","Headless Chrome/99",
            "Headless Chrome/100","Headless Chrome/101","Headless Chrome/102","Headless Chrome/103","Headless Chrome/104","Headless Chrome/105","Headless Chrome/106","Headless Chrome/107","Headless Chrome/108","Headless Chrome/109",
            "Headless Chrome/110","Headless Chrome/111","Headless Chrome/112","Headless Chrome/113","Headless Chrome/114","Headless Chrome/115","Headless Chrome/116","Headless Chrome/117","Headless Chrome/118","Headless Chrome/119",
            "Headless Chrome/120","Headless Chrome/121","Headless Chrome/122","Headless Chrome/123","Headless Chrome/124","Headless Chrome/125","Headless Chrome/126","Headless Chrome/127","Headless Chrome/128","Headless Chrome/129",
            "Headless Chrome/130","Headless Chrome/131","Headless Chrome/132","Headless Chrome/133","Headless Chrome/134","Headless Chrome/135","Headless Chrome/136","Headless Chrome/137","Headless Chrome/138","Headless Chrome/139",
            "Headless Chrome/140","Headless Chrome/141","Headless Chrome/142","Headless Chrome/143","Headless Chrome/144","Headless Chrome/145","Headless Chrome/146","Headless Chrome/147",
	
		    // Edge old versions 
            "Edge/12","Edge/13","Edge/14","Edge/15","Edge/16","Edge/17","Edge/18","Edge/19","Edge/20","Edge/21","Edge/22","Edge/23","Edge/24","Edge/25","Edge/26","Edge/27","Edge/28",
			"Edge/29","Edge/30","Edge/31","Edge/32","Edge/33","Edge/34","Edge/35","Edge/36","Edge/37","Edge/38","Edge/39","Edge/40","Edge/41","Edge/42","Edge/43","Edge/44",
			"Edge/45","Edge/46","Edge/47","Edge/48","Edge/49","Edge/50","Edge/51","Edge/52","Edge/53","Edge/54","Edge/55","Edge/56","Edge/57","Edge/58","Edge/59","Edge/60",
			"Edge/61","Edge/62","Edge/63","Edge/64","Edge/65","Edge/66","Edge/67","Edge/68","Edge/69","Edge/70","Edge/71","Edge/72","Edge/73","Edge/74","Edge/75","Edge/76",
			"Edge/77","Edge/78","Edge/79","Edge/80","Edge/81","Edge/82","Edge/83","Edge/84","Edge/85","Edge/86","Edge/87","Edge/88","Edge/89","Edge/90","Edge/91","Edge/92",
			"Edge/93","Edge/94","Edge/95","Edge/96","Edge/97","Edge/98","Edge/99","Edge/100","Edge/101","Edge/102","Edge/103","Edge/104","Edge/105","Edge/106","Edge/107","Edge/108",
			"Edge/109","Edge/110","Edge/111","Edge/112","Edge/113","Edge/114","Edge/115","Edge/116","Edge/117","Edge/118","Edge/119","Edge/120","Edge/121","Edge/122","Edge/123",
			"Edge/124","Edge/125","Edge/126","Edge/127","Edge/128","Edge/129","Edge/130","Edge/131","Edge/132","Edge/133","Edge/134","Edge/135","Edge/136","Edge/137","Edge/138",
			"Edge/139","Edge/140","Edge/141","Edge/142","Edge/143","Edge/144","Edge/145","Edge/146","Edge/146","Edge/147",
			
			// Firefox
			"Firefox/3.6","Firefox/3.6.1","Firefox/4.0","Firefox/7.0","Firefox/10.0","Firefox/12.0","Firefox/13.0","Firefox/15.0.1","Firefox/16.0.1","Firefox/30",
            "Firefox/41.0","Firefox/42.0.0","Firefox/46.0","Firefox/46.0.1","Firefox/46.8","Firefox/47.0","Firefox/47.2","Firefox/48.0","Firefox/48.0.1",
            "Firefox/48.0.2","Firefox/49.0","Firefox/49.5","Firefox/49.6","Firefox/50.0","Firefox/50.0.1","Firefox/50.1.0","Firefox/50.7","Firefox/50.9","Firefox/51.0",
            "Firefox/51.0.1","Firefox/51.1","Firefox/51.4","Firefox/51.7","Firefox/52.0","Firefox/52.0.1","Firefox/52.0.2","Firefox/52.3","Firefox/52.8","Firefox/53.0",
            "Firefox/53.0.3","Firefox/53.2","Firefox/54.0","Firefox/54.1","Firefox/55.0","Firefox/55.0.2","Firefox/55.0.3","Firefox/55.8","Firefox/55.9","Firefox/56.0",
            "Firefox/56.0.1","Firefox/57.0","Firefox/57.0.1","Firefox/57.0.4","Firefox/57.9","Firefox/58.0","Firefox/58.1","Firefox/59.0","Firefox/59.0.3","Firefox/59.4",
            "Firefox/59.7","Firefox/60.0.1","Firefox/60.1","Firefox/60.3","Firefox/60.9","Firefox/61.0","Firefox/61.0.2""Firefox/61.9","Firefox/62.0","Firefox/62.3","Firefox/62.6",
            "Firefox/64.0","Firefox/64.1","Firefox/64.8","Firefox/65.0","Firefox/65.2","Firefox/66.4","Firefox/66.9","Firefox/67.0","Firefox/67.0.3","Firefox/68.0",
            "Firefox/68.0.2","Firefox/68.6","Firefox/69.0","Firefox/69.0.1","Firefox/69.1","Firefox/69.2","Firefox/69.3","Firefox/69.8","Firefox/70.0","Firefox/70.0.1",
            "Firefox/71.0","Firefox/71.8","Firefox/71.9","Firefox/72.0","Firefox/72.0.1","Firefox/72.4","Firefox/73.0","Firefox/73.1","Firefox/73.8","Firefox/74.0","Firefox/74.5",
			"Firefox/75.0","Firefox/76.0","Firefox/76.0.1","Firefox/77.0","Firefox/77.0.1","Firefox/78.0","Firefox/78.0.1","Firefox/78.0.2","Firefox/78.1.0","Firefox/78.2.0",
            "Firefox/78.3.0","Firefox/78.3.1","Firefox/78.4.0","Firefox/78.4.1","Firefox/78.5.0","Firefox/78.6.0","Firefox/78.6.1","Firefox/78.7.0","Firefox/78.7.1",
            "Firefox/78.8.0","Firefox/78.9.0","Firefox/78.10.0","Firefox/78.10.1","Firefox/78.11.0","Firefox/78.12.0","Firefox/78.13.0","Firefox/78.14.0","Firefox/78.15.0",
            "Firefox/79.0","Firefox/80","Firefox/81.0","Firefox/81.0.1","Firefox/82.0","Firefox/82.0.1","Firefox/83.0","Firefox/84.0","Firefox/84.0.1","Firefox/84.0.2",
            "Firefox/85.0","Firefox/85.0.2","Firefox/86.0","Firefox/86.0.1","Firefox/87.0","Firefox/88.0","Firefox/88.0.1","Firefox/89.0","Firefox/89.0.1","Firefox/89.0.2",
            "Firefox/90.0","Firefox/90.0.1","Firefox/90.0.2","Firefox/91.0","Firefox/91.0.1","Firefox/91.0.2","Firefox/92.0","Firefox/92.0.1","Firefox/93.0","Firefox/94.0",
            "Firefox/94.0.1","Firefox/94.0.2","Firefox/95.0","Firefox/95.0.1","Firefox/95.0.2","Firefox/96.0","Firefox/96.0.1","Firefox/96.0.2","Firefox/96.0.3","Firefox/97.0",
            "Firefox/97.0.1","Firefox/97.0.2","Firefox/98.0.1","Firefox/98.0.2","Firefox/99.0.1","Firefox/100","Firefox/100.0","Firefox/100.0.1","Firefox/100.0.2",
            "Firefox/101.0","Firefox/101.0.1","Firefox/102.0","Firefox/103.0","Firefox/103.0.2","Firefox/104.0","Firefox/104.0.1","Firefox/105.0","Firefox/105.0.1","Firefox/105.0.2",
            "Firefox/105.0.3","Firefox/106.0","Firefox/106.0.1","Firefox/106.0.2","Firefox/106.0.4","Firefox/107.0","Firefox/108.0","Firefox/108.0.2","Firefox/109.0",
            "Firefox/109.0.1","Firefox/110.0","Firefox/111.0","Firefox/111.0.1","Firefox/112.0","Firefox/112.0.1","Firefox/112.0.2","Firefox/113.0","Firefox/113.0.1",
            "Firefox/113.0.2","Firefox/114.0","Firefox/114.0.1","Firefox/114.0.2","Firefox/115.0","Firefox/115.0.1","Firefox/115.0.2","Firefox/116.0","Firefox/116.0.2",
            "Firefox/116.0.3","Firefox/117.0","Firefox/117.0.1","Firefox/118.0","Firefox/118.0.1","Firefox/118.0.2","Firefox/119.0","Firefox/119.0.1","Firefox/120.0","Firefox/120.0.1",
            "Firefox/121.0","Firefox/121.0.1","Firefox/122.0","Firefox/122.0.1","Firefox/123.0","Firefox/123.0.1","Firefox/124.0","Firefox/124.0.2","Firefox/125.0.1",
            "Firefox/125.0.2","Firefox/125.0.3","Firefox/126.0","Firefox/126.0.1","Firefox/127.0","Firefox/127.0.2","Firefox/128.0","Firefox/129.0","Firefox/129.0.1","Firefox/129.0.2",
            "Firefox/130.0","Firefox/130.0.1","Firefox/131.0","Firefox/131.0.2","Firefox/131.0.3","Firefox/132.0","Firefox/132.0.1","Firefox/132.0.2""Firefox/132.0.11",
            "Firefox/133.0","Firefox/133.0.3","Firefox/134.0","Firefox/134.0.1","Firefox/134.0.2","Firefox/135.0","Firefox/135.0.1","Firefox/136.0","Firefox/136.0.1","Firefox/136.0.2",
            "Firefox/136.0.3","Firefox/136.0.4","Firefox/137.0","Firefox/137.0.1","Firefox/137.0.2","Firefox/138.0","Firefox/138.0.1","Firefox/138.0.3","Firefox/138.0.4",
            "Firefox/139.0","Firefox/139.0.1","Firefox/139.0.4","Firefox/140.0","Firefox/140.0.1","Firefox/140.0.2","Firefox/140.0.4","Firefox/140.1.0","Firefox/140.2.0","Firefox/140.3.0",
            "Firefox/140.3.1","Firefox/140.4.0","Firefox/140.5.0","Firefox/141.0","Firefox/141.0.2","Firefox/141.0.3","Firefox/142.0","Firefox/142.0.1","Firefox/143.0",
            "Firefox/143.0.3","Firefox/143.0.4","Firefox/144.0","Firefox/144.0.2","Firefox/145.0.2","Firefox/147.0","Firefox/147.0.3","Firefox/148.0","Firefox/148.0.1","Firefox/148.0.2","Firefox/150.0",

		   // Linux Android
            "Linux; Android","Linux; Android 7.0","Linux; Android 1.0","Linux; Android 1.1","Linux; Android 1.5","Linux; Android 1.6","Linux; Android 2.0","Linux; Android 2.1",	
            "Linux; Android 2.2","Linux; Android 2.3","Linux; Android 3.0 ", "Linux; Android 3.2","Linux; Android 4.0","Linux; Android 4.1","Linux; Android 4.3","Linux; Android 4.4",
            "Linux; Android 5.0","Linux; Android 6.0","Linux; Android 7.0","Linux; Android 7.1","Linux; Android 7.1.1","Linux; Android 8.0 ","Linux; Android 8.1","Linux; Android 9",
            "Linux; Android 10","Linux; Android 10; K","Linux; Android 11","Linux; Android 12","Linux; Android 13","Linux; Android 14","Linux; Android 15","Linux; Android 16",
         
			// MacOS
			"Macintosh; Intel Mac OS X 10_13","Macintosh; Intel Mac OS X 10_13_1","Macintosh; Intel Mac OS X 10_13_2","Macintosh; Intel Mac OS X 10_13_3","Macintosh; Intel Mac OS X 10_13_4",
            "Macintosh; Intel Mac OS X 10_13_5","Macintosh; Intel Mac OS X 10_13_6","Macintosh; Intel Mac OS X 10_14","Macintosh; Intel Mac OS X 10_14_1","Macintosh; Intel Mac OS X 10_14_2",
            "Macintosh; Intel Mac OS X 10_14_3","Macintosh; Intel Mac OS X 10_14_4","Macintosh; Intel Mac OS X 10_14_5","Macintosh; Intel Mac OS X 10_14_6","Macintosh; Intel Mac OS X 10_15",
            "Macintosh; Intel Mac OS X 10_15_1","Macintosh; Intel Mac OS X 10_15_2","Macintosh; Intel Mac OS X 10_15_3","Macintosh; Intel Mac OS X 10_15_4","Macintosh; Intel Mac OS X 10_15_5",
            "Macintosh; Intel Mac OS X 10_15_6","Macintosh; Intel Mac OS X 10_15_7","Macintosh; Intel Mac OS X 11_0","Macintosh; Intel Mac OS X 11_0_1","Macintosh; Intel Mac OS X 11_1",
            "Macintosh; Intel Mac OS X 11_2","Macintosh; Intel Mac OS X 11_2_1","Macintosh; Intel Mac OS X 11_2_2","Macintosh; Intel Mac OS X 11_2_3","Macintosh; Intel Mac OS X 11_3",
            "Macintosh; Intel Mac OS X 11_3_1","Macintosh; Intel Mac OS X 11_4","Macintosh; Intel Mac OS X 11_5","Macintosh; Intel Mac OS X 11_5_1","Macintosh; Intel Mac OS X 11_5_2","Macintosh; Intel Mac OS X 11_6",
            "Macintosh; Intel Mac OS X 11_6_1","Macintosh; Intel Mac OS X 11_6_2","Macintosh; Intel Mac OS X 11_6_3","Macintosh; Intel Mac OS X 11_6_4","Macintosh; Intel Mac OS X 11_6_5",
            "Macintosh; Intel Mac OS X 11_6_6","Macintosh; Intel Mac OS X 11_6_7","Macintosh; Intel Mac OS X 11_6_8","Macintosh; Intel Mac OS X 11_7","Macintosh; Intel Mac OS X 11_7_1",
            "Macintosh; Intel Mac OS X 11_7_2","Macintosh; Intel Mac OS X 11_7_3","Macintosh; Intel Mac OS X 11_7_4","Macintosh; Intel Mac OS X 11_7_5","Macintosh; Intel Mac OS X 11_7_6",
            "Macintosh; Intel Mac OS X 11.7.7","Macintosh; Intel Mac OS X 11.7.8","Macintosh; Intel Mac OS X 11.7.9","Macintosh; Intel Mac OS X 11.7.10","Macintosh; Intel Mac OS X 11_6; rv:106.0",
            "Macintosh; Intel Mac OS X 12_0","Macintosh; Intel Mac OS X 12_0_1","Macintosh; Intel Mac OS X 12_1","Macintosh; Intel Mac OS X 12_2","Macintosh; Intel Mac OS X 12_2_1","Macintosh; Intel Mac OS X 12_3",
            "Macintosh; Intel Mac OS X 12_3_1","Macintosh; Intel Mac OS X 12_4","Macintosh; Intel Mac OS X 12_5","Macintosh; Intel Mac OS X 12_5_1","Macintosh; Intel Mac OS X 12_6",
            "Macintosh; Intel Mac OS X 12_6_1","Macintosh; Intel Mac OS X 12_6_2","Macintosh; Intel Mac OS X 12_6_3","Macintosh; Intel Mac OS X 12_6_4","Macintosh; Intel Mac OS X 12_6_5",
            "Macintosh; Intel Mac OS X 12.6.6","Macintosh; Intel Mac OS X 12.6.7","Macintosh; Intel Mac OS X 12.6.8","Macintosh; Intel Mac OS X 12.6.9","Macintosh; Intel Mac OS X 12.7","Macintosh; Intel Mac OS X 12.7.1",
            "Macintosh; Intel Mac OS X 12.7.2","Macintosh; Intel Mac OS X 12.7.3","Macintosh; Intel Mac OS X 12.7.4","Macintosh; Intel Mac OS X 12.7.5","Macintosh; Intel Mac OS X 12.7.6",
            "Macintosh; Intel Mac OS X 13_0","Macintosh; Intel Mac OS X 13_0_1","Macintosh; Intel Mac OS X 13_1","Macintosh; Intel Mac OS X 13_2","Macintosh; Intel Mac OS X 13_2_1","Macintosh; Intel Mac OS X 13_3",
            "Macintosh; Intel Mac OS X 13_3_1","Macintosh; Intel Mac OS X 13.4","Macintosh; Intel Mac OS X 13.4.1","Macintosh; Intel Mac OS X 13.5","Macintosh; Intel Mac OS X 13.5.1","Macintosh; Intel Mac OS X 13.5.2",
            "Macintosh; Intel Mac OS X 3.6","Macintosh; Intel Mac OS X 13.6.1","Macintosh; Intel Mac OS X 13.6.2","Macintosh; Intel Mac OS X 13.6.3","Macintosh; Intel Mac OS X 13.6.4",
            "Macintosh; Intel Mac OS X 13.6.5","Macintosh; Intel Mac OS X 13.6.6","Macintosh; Intel Mac OS X 13.6.7","Macintosh; Intel Mac OS X 13.6.8","Macintosh; Intel Mac OS X 14_1",
            "Macintosh; Intel Mac OS X 14.0","Macintosh; Intel Mac OS X 14.1","Macintosh; Intel Mac OS X 14.1.1","Macintosh; Intel Mac OS X 14.1.2","Macintosh; Intel Mac OS X 14.2",
            "Macintosh; Intel Mac OS X 14.2.1","Macintosh; Intel Mac OS X 14.3","Macintosh; Intel Mac OS X 14.3.1","Macintosh; Intel Mac OS X 14.4","Macintosh; Intel Mac OS X 14.4.1",
            "Macintosh; Intel Mac OS X 14.5","Macintosh; Intel Mac OS X 14.6","Macintosh; Intel Mac OS X 14.6.1","Macintosh; Intel Mac OS X 14.7","Macintosh; Intel Mac OS X 14.7.1",
            "Macintosh; Intel Mac OS X 14.7.2","Macintosh; Intel Mac OS X 14.7.3","Macintosh; Intel Mac OS X 14.7.4","Macintosh; Intel Mac OS X 14.7.5","Macintosh; Intel Mac OS X 14.7.6",
            "Macintosh; Intel Mac OS X 15","Macintosh; Intel Mac OS X 15.0","Macintosh; Intel Mac OS X 15.0.1","Macintosh; Intel Mac OS X 15.1","Macintosh; Intel Mac OS X 15.1.1",
            "Macintosh; Intel Mac OS X 15.2","Macintosh; Intel Mac OS X 15.3","Macintosh; Intel Mac OS X 15.3.1","Macintosh; Intel Mac OS X 15.3.2","Macintosh; Intel Mac OS X 15.4",
            "Macintosh; Intel Mac OS X 15.4.1","Macintosh; Intel Mac OS X 15.5","Macintosh; Intel Mac OS X 16","Macintosh; Intel Mac OS X 26.0","Macintosh; Intel Mac OS X 12_6_4; rv:108.0",
            "Macintosh; Intel Mac OS X 13_0; rv:105.0","Macintosh; Intel Mac OS X 10_15; rv:102.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 11_6_4; rv:104.0)","Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3_1; rv:105.0)",
            "Macintosh; Intel Mac OS X 11_6_1; rv:103.01","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7; rv:113.0)","Macintosh; Intel Mac OS X 11_2_1; rv:105.0","Macintosh; Intel Mac OS X 12_4; rv:107.0","Macintosh; Intel Mac OS X 12_0; rv:111.0","Macintosh; Intel Mac OS X 11_7_3; rv:112.0",

            // Opera old versions
            "OPR/1","OPR/2","OPR/3","OPR/4","OPR/5","OPR/6","OPR/7","OPR/8","OPR/9","OPR/10","OPR/11","OPR/12","OPR/13","OPR/14","OPR/15","OPR/16","OPR/17","OPR/18","OPR/19",
			"OPR/20","OPR/21","OPR/22","OPR/23","OPR/24","OPR/25","OPR/26","OPR/27","OPR/28","OPR/29","OPR/30","OPR/31","OPR/32","OPR/33","OPR/34","OPR/35","OPR/36","OPR/37",
			"OPR/38","OPR/39","OPR/40","OPR/41","OPR/42","OPR/43","OPR/44","OPR/45","OPR/46","OPR/47","OPR/48","OPR/49","OPR/50","OPR/51","OPR/52","OPR/53","OPR/54","OPR/55",
			"OPR/56","OPR/57","OPR/58","OPR/59","OPR/60","OPR/61","OPR/62","OPR/63","OPR/64","OPR/65","OPR/66","OPR/67","OPR/68","OPR/69","OPR/70","OPR/71","OPR/72","OPR/73",
			"OPR/74","OPR/75","OPR/76","OPR/77","OPR/78","OPR/79","OPR/80","OPR/81","OPR/82","OPR/83","OPR/84","OPR/85","OPR/86","OPR/87","OPR/88","OPR/89","OPR/90","Opera/9","Opera/10","Opera/11","Opera/12","Opera/15","Opera/16","Opera/17",
			"Opera/18","Opera/19","Opera/20","Opera/21","Opera/22","Opera/23","Opera/24","Opera/25","Opera/26","Opera/27","Opera/28","Opera/29","Opera/30","Opera/31","Opera/32",
			"Opera/33","Opera/34","Opera/35","Opera/36","Opera/37","Opera/38","Opera/39","Opera/40","Opera/41","Opera/42","Opera/43","Opera/44","Opera/45","Opera/46","Opera/47",
			"Opera/48","Opera/49","Opera/50","Opera/51","Opera/52","Opera/53","Opera/54","Opera/55","Opera/56","Opera/57","Opera/58","Opera/59","Opera/60","Opera/61","Opera/62","Opera/63","Opera/64",
			"Opera/65","Opera/66","Opera/67","Opera/68","Opera/69","Opera/70","Opera/71","Opera/72","Opera/73","Opera/74","Opera/75","Opera/76","Opera/77","Opera/78","Opera/79",
			"Opera/80","Opera/81","Opera/82","Opera/83","Opera/84","Opera/85","Opera/86","Opera/87","Opera/88","Opera/89","Opera/90","Opera/91","Opera/92","Opera/93","Opera/94","Opera/95","Opera/96","Opera/97","Opera/98","Opera/99","Opera/100",

            // Safari old versions
            "Version/1","Version/2","Version/3","Version/4","Version/5","Version/6","Version/7","Version/8","Version/9","Version/10","Version/11","Version/12",
			"Version/13","Version/14","Version/15","Version/16","Version/17","Version/18","Version/19","Safari/1","Safari/2","Safari/3","Safari/4","Safari/5",
			"Safari/6","Safari/7","Safari/8","Safari/9","Safari/10","Safari/11","Safari/12","Safari/13","Safari/14","Safari/15","Safari/16","Safari/17","Safari/18",
			"Safari/19","Safari/20",
			
            // Vivaldi old versions
            "Vivaldi/1","Vivaldi/2","Vivaldi/3","Vivaldi/4","Vivaldi/5","Vivaldi/6","Vivaldi/7","Vivaldi/8","Vivaldi/9","Vivaldi/10","Vivaldi/11","Vivaldi/12","Vivaldi/13","Vivaldi/14","Vivaldi/15",
            "Vivaldi/16","Vivaldi/17","Vivaldi/18","Vivaldi/19","Vivaldi/20","Vivaldi/21","Vivaldi/22","Vivaldi/23","Vivaldi/24","Vivaldi/25","Vivaldi/26","Vivaldi/27","Vivaldi/28","Vivaldi/29","Vivaldi/30",
            "Vivaldi/31","Vivaldi/32","Vivaldi/33","Vivaldi/34","Vivaldi/35","Vivaldi/36","Vivaldi/37","Vivaldi/38","Vivaldi/39","Vivaldi/40","Vivaldi/41","Vivaldi/42","Vivaldi/43","Vivaldi/44","Vivaldi/45",
            "Vivaldi/46","Vivaldi/47","Vivaldi/48","Vivaldi/49","Vivaldi/50","Vivaldi/51","Vivaldi/52","Vivaldi/53","Vivaldi/54","Vivaldi/55","Vivaldi/56","Vivaldi/57","Vivaldi/58","Vivaldi/59","Vivaldi/60",
            "Vivaldi/61","Vivaldi/62","Vivaldi/63","Vivaldi/64","Vivaldi/65","Vivaldi/66","Vivaldi/67","Vivaldi/68","Vivaldi/69","Vivaldi/70","Vivaldi/71","Vivaldi/72","Vivaldi/73","Vivaldi/74","Vivaldi/75",
            "Vivaldi/76","Vivaldi/77","Vivaldi/78","Vivaldi/79","Vivaldi/80","Vivaldi/81","Vivaldi/82","Vivaldi/83","Vivaldi/84","Vivaldi/85","Vivaldi/86","Vivaldi/87","Vivaldi/88","Vivaldi/89","Vivaldi/90",
            "Vivaldi/91","Vivaldi/92","Vivaldi/93","Vivaldi/94","Vivaldi/95","Vivaldi/96","Vivaldi/97","Vivaldi/98","Vivaldi/99","Vivaldi/100","Vivaldi/101","Vivaldi/102","Vivaldi/103","Vivaldi/104","Vivaldi/105",
        ];

        // Initialize allowed bots list (legitimate search engines and crawlers)
        $this->allowed_bots = [
            'AdsBot-Google','Android OS','AOL Search','AOL','APIs-Google','Applebot','AppleNewsBot','apple-app-site-association','archive.org_bot','Avant',
			'BingPreview','Bing Preview bot','Bingbot','bingbot','bingbot/2.0','bing','BraveBot','Brave',
            'Chrome','coccocbot-image','coccocbot-web','coccocbot-web/1.0','CocCocBot','CocCoc','CriOS',
            'Dogpile','Dolphin Browser','Dolphin Browse','DuckDuckBot','DuckDuckGo-Favicons-Bot','DuckDuckGo','DuplexWeb-Google',
            'EcosiaBot','Ecosia','Edge','Edg','Exabot',
            'Feedfetcher-Google','Firefox','FxiOS',
            'GibiruBot','Google Favicon','Google Mobile Adsense','google page speed','Google Read Aloud','Google-Read-Aloud','Google Site Verifier','Googlebot Smartphone',
            'Googlebot-Image', 'Googlebot-Image/1.0','Googlebot-Mobile','googlebot-news','Googlebot-Video','Googlebot-Video/1.0','Googlebot','Googlebot/2.1','GoogleProducer','Google-InspectionTool','Google-InspectionTool/1.0','Google-Mobile-Apps','Google-Safetys','Google-Site-Verification/1.0',
            'ia_archiver','IceCat','Iceweasel','Info.com','Instagram',
            'Konqueror','KrakeBot',
            'Lighthouse','LinkedInApp','LinkedInBot','linkedinbot','LookseekBot','Lycos',
            'Mastodon','Maxthon','Mediapartners-Google','Mediapartners-Google/2.1','MeiliBot','MetaBot','MetaCrawler','MetaGer','Mi Browser','Midori','MojeekBot''Mozilla','MS Search','msnbot-media','MSNBot-NewsBlogs','msnbot','Nimbostratus',
            'OPERA','Opera','OPR','OscoboBot',
            'PageSpeed','PeekBot','Pinterest','PresearbotBot',
            'QQBrowser','QwantBot','Qwantify','Qwant','redditbot',
            'Safari','SamsungBrowser','Seamonkey','Search Encrypt','SearchEncrypt','SeznamBot','SeznamBot/4.0','Slackbot','Slurp','SphinxBot','StartpageBot','StartPage','SwiftBot','Swisscows',
            'TumblrBot','UCBrowser','Vivaldi','WebCrawler','WebwikiBot',
            'WolfBot','YaBrowser','YacyBot','YaDirectFetchery','YaDirectFetcher','Yahoo! Slurp','yahoo-blogs','yahoo-blogs/v3.9','Yandexbot','Yandex','Yeti-Mobile','Yeti','Yeti/1.1',
			// Social link previewers (these appear in the headless_allowlist too)
            'LinkedInBot','Slackbot','Discordbot','TelegramBot','WhatsApp','Slack-LinkPreview','TeamsBot','SkypeUriPreview','iMessageBot','Pinterest','TumblrBot','Mastodon','Instagram','Line','Viber','WeChat',
			// Pinger 
            'UptimeRobot','Pingdom','StatusCake','GTmetrix','Site24x7','Catchpoint','DatadogSynthetics','NewRelicPinger',
        ];

        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }

    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";

        $test_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
            'curl/7.68.0' => 'cURL Bot (BLOCKED)',
            'OpenAI-GPT/1.0' => 'OpenAI Bot (BLOCKED)',
            'python-requests/2.25.1' => 'Python Requests (BLOCKED)',
            'Googlebot/2.1' => 'Google Bot (ALLOWED)',
            'ChatGPT-User' => 'ChatGPT User (BLOCKED)',
            'Mozilla/5.0 (compatible; bingbot/2.0)' => 'Bing Bot (ALLOWED)',
            'Headless Chrome' => 'Headless Browser (BLOCKED)',
            'facebookexternalhit/1.1' => 'Facebook Bot (BLOCKED - not in allowed list)',
            'Twitterbot/1.0' => 'Twitter Bot (BLOCKED - not in allowed list)'
        ];

        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";

        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);

            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }

            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }

        echo "</table>\n";
    }

    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";

        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";

        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";

        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }

    /**
     * Detects if the request is from a bot
     */
    private function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);

        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }

        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if the bot is in the allowed bots list
     */
    private function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');

        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }

    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;

        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));

        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];

            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];

            $dummy_sentences[] = $variations[array_rand($variations)];
        }

        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);

        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }

        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }

        return $dummy_content;
    }
}

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false ||
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
