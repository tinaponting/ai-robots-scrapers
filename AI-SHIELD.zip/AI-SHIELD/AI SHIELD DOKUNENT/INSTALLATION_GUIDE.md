# AI Shield Enhanced - Installation & Setup Guide

## 🚀 Quick Setup

### 1. Installation
1. Upload the entire `ai-shield` folder to `/wp-content/plugins/`
2. Activate via WordPress Admin → Plugins
3. Go to Settings → AI Shield

### 2. Recommended Configuration

**Basic Setup:**
```
✅ Enabled: ON
✅ Cache enabled: ON  
✅ Cache duration: 5 minutes
✅ Honeypot Mode: ON
✅ Honeypot Strategy: Replace with dummy content
✅ Log Bot Attempts: ON
```

**Advanced Setup (for high-traffic sites):**
```
✅ Enabled: ON
✅ Cache enabled: ON
✅ Cache duration: 60 minutes
✅ Honeypot Mode: ON  
✅ Honeypot Strategy: Combine dummy + obscured real content
✅ Log Bot Attempts: ON
```

## 🧪 Testing Your Setup

### Method 1: Use the Test File
1. Access `your-site.com/wp-content/plugins/ai-shield/test-honeypot.php`
2. Review bot detection results
3. Check dummy content generation

### Method 2: Manual Testing
1. Test with a normal browser → Should see real content
2. Test with curl: `curl -A "OpenAI-Bot/1.0" your-site.com/your-post/`
3. Should receive dummy content instead of real content

### Method 3: Debug Mode
1. Add `?ai_shield_debug=true` to any page URL
2. Invisible characters will show as ❄ symbols
3. Verify content transformation is working

## 📊 Monitoring Bot Activity

### Check WordPress Error Logs
Bot detection events are logged like:
```
AI Shield Honeypot: Bot detected - IP: 123.456.789.0, UA: OpenAI-GPT/1.0, Mode: replace
```

### Log File Locations
- **cPanel hosting**: `public_html/wp-content/debug.log`
- **Managed WordPress**: Check your host's error log section
- **Local development**: Often in `wp-content/debug.log`

## 🔧 Advanced Configuration

### Custom Bot Detection
You can modify the bot detection patterns in `includes/class-ai-shield.php`:

```php
$this->bot_user_agents = [
    'bot', 'crawl', 'spider', 'scraper',
    'your-custom-pattern', // Add custom patterns here
    // ... existing patterns
];
```

### Custom Dummy Content
Modify dummy content templates in the same file:

```php
$this->dummy_content_templates = [
    'Your custom dummy sentence here.',
    'Another fake sentence for bots.',
    // ... add more variations
];
```

## 🎯 What Each Mode Does

### Traditional Mode Only
- Inserts invisible characters into content
- Bots get scrambled but partially readable content
- Humans see normal content

### Honeypot Mode - Replace
- Bots get 100% fake Lorem Ipsum content
- Humans get normal content
- **Most effective protection**

### Honeypot Mode - Combine
- Bots get mix of fake + scrambled real content
- Harder for bots to detect they're being tricked
- Still significantly reduces content quality for training

## 🚨 Troubleshooting

### "Settings not saving"
1. Check file permissions on plugin directory
2. Verify WordPress user has admin privileges
3. Clear browser cache and try again

### "Legitimate users getting dummy content"
1. Check error logs for false positives
2. Consider reducing bot detection sensitivity
3. Test with different browsers/devices

### "Plugin not working"
1. Deactivate and reactivate the plugin
2. Clear all caching (WordPress cache, CDN, etc.)
3. Test with debug mode enabled

### "Performance issues"
1. Increase cache duration to 60+ minutes
2. Enable WordPress object caching
3. Consider upgrading server resources

## 📈 Performance Tips

1. **Enable Caching**: Always keep this ON
2. **Longer Cache Duration**: For static content, use 60+ minutes
3. **Monitor Server Resources**: Bot processing uses slightly more CPU
4. **Use a CDN**: Reduces server load for legitimate traffic

## 🔒 Security Considerations

1. **Log Rotation**: Bot logs can grow large, set up log rotation
2. **IP Monitoring**: Consider blocking repeat offender IPs
3. **Rate Limiting**: Combine with rate limiting plugins for extra protection
4. **Regular Updates**: Keep plugin updated as bot patterns evolve

## 🎉 Success Indicators

You'll know it's working when:

✅ Error logs show bot detection events  
✅ Curl tests return dummy content  
✅ Normal browsers show real content  
✅ Page load times remain normal  
✅ No user complaints about broken content  

## 📞 Support

If you encounter issues:

1. **Check logs first** - Most issues show up in WordPress error logs
2. **Test with debug mode** - Helps identify configuration problems  
3. **Clear all caches** - Plugin changes require cache clearing
4. **Document the issue** - Include user agent, IP, and exact symptoms

---

**Your content is now protected!** 🛡️ The enhanced AI Shield provides sophisticated protection against content harvesting while maintaining a seamless experience for legitimate human visitors.
