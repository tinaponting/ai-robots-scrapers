<?php
/**
 * AI Shield Bot Detection Test
 * 
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * 
 * NEW FEATURE: Allowed Bots List
 * - Legitimate search engine bots (Google, Bing, Yandex, etc.) are now whitelisted
 * - These allowed bots will NOT be blocked by the honeypot system
 * - Only AI scrapers and malicious bots will be blocked
 * - This ensures your site remains SEO-friendly while protecting against AI content theft
 * 
 * CHECKED BY: Minimax
 */

class AI_Shield_Test {
    
    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;
    
    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [
            // AI-related patterns
            ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$", "ai=n",
            
            // Python-related patterns
            "python", "pyth", "pyscan", "py", "pyq", "python-http", 
            "python-requests", "python\-requests", "python requests", 
            "python-requests/2.32.3", "pythonrequests", "python-urllib", 
            "python\-urllib", "python aiohttp", "python-httpx", "python-async",
            
            // Python tools and libraries
            "photon", "photon/1.0", "python scrapy", "python/3.12 aiohttp",
            "pycurl", "python2 snitch.py", "urllib3", "requests", "httpx", "scrapy",
            "aiohttp", "urllib", "beautifulsoup", "bs4", "selenium", "playwright",
            "mechanize", "selenium", "webdriver", "pageobj", "lxml", "feedparser",
            
            // Development/testing tools
            "postman", "prometheus",
            
            // PHP patterns
            "php", "php://input", "phpcrawler", "php meterpreter", "profacefinder",
            
            // General bot patterns
            "bot", "crawl",  "GET /wp-json/wp/v2/posts HTTP/1.1", "spider", "scrape", "fetch", "curl", "wget", "fetch", "scrap", "harvest", "collect", "extract", "download", "sync"
			
			// AI BOTS
		    "AcademicBotRTU","AddSearchBot","Agent 3","Agent API","Agent GPT","Agent Middleware","AgentGPT","Agentic Deep Research","Agentic RAG with LangGraph",
		    "Agentic RAG","Agentic","Agentic-RAG","AgentQL","Agent-E","AI agents /","AI Agent","AI Article Writer","AI Chatbot","AI Chat","AI Content Detector",
	        "AI copilot","AI Data Scraper","AI Detection","AI Dungeon","AI Journalist Agent","AI Journalist","AI Legion","AI RAG","AI Scraper","AI Search Engine",
		    "AI Search Intent","AI Search","AI SEO Crawler","AI Web Scraper","AI Website Screenshot","AI Web","AI Writer","AI2 Bot","AI2Bot",
		    "Ai2Bot-DeepResearchEval","AI2","AI21 Labs","AIBot","aiHitBot","AIMatrix","airesearchbot","AISearchBot","AISearch","AITraining /","AITraining",
		    "ai-agent-playwright","ai-crawlers-training","AI-Crawler","ai-proxy","AlexaTM","Alexa","Alice Yandex","AliGenie","AliyunSecBot","AliyunSec","Alpha AI",
		    "AlphaAI","Amazon Athena","Amazon Bedrock AgentCore Browser","Amazon Bedrock","Amazon Comprehend","Amazon Lex","Amazon SageMaker","Amazon Silk",

        ];
        
        // Initialize allowed bots list (legitimate search engines and crawlers)
        $this->allowed_bots = [
            // Major search engines
            'AOL Search',
            'AdsBot-Google',
            'APIs-Google',
            'Applebot',
            'AppleNewsBot',
            'apple-app-site-association',
            'archive.org_bot',
            'Android OS',
            'Bingbot',
            'bingbot',
            'BingPreview',
            'bing',
            'bingbot/2.0',
            'Brave',
            'BraveBot',
            'Chrome',
            'CocCoc',
            'CocCocBot',
            'coccocbot-image',
            'coccocbot-web',
            'coccocbot-web/1.0',
            'CriOS',
            'Dolphin Browse',
            'DuckDuckBot',
            'DuckDuckGo-Favicons-Bot',
            'DuplexWeb-Google',
            'Dolphin Browser',
            'Dogpile',
            'Ecosia',
            'EcosiaBot',
            'Edg',
            'Edge',
            'Exabot',
            'Feedfetcher-Google',
            'Firefox',
            'FxiOS',
            'Gigablast',
            'Gigabot',
            'Google Favicon',
            'Google Mobile Adsense',
            'google page speed',
            'Google Read Aloud',
            'Google Site Verifier',
            'Googlebot',
            'Googlebot Smartphone',
            'Googlebot-Image',
            'Lighthouse',
            'Googlebot-Mobile',
            'googlebot-news',
            'Googlebot-Video',
            'Googlebot/2.1',
            'GoogleProducer',
            'Google-InspectionTool',
            'Google-Mobile-Apps',
            'Google-Safetys',
            'Googlebot-Image/1.0',
            'DuplexWeb-Google',
            'Mediapartners-Google',
            'Mediapartners-Google/2.1',
            'Google-InspectionTool/1.0',
            'Googlebot-Video/1.0',
            'Google-Site-Verification/1.0',
            'Info.com',
            'ia_archiver',
            'IceCat',
            'Instagram',
            'Konqueror',
            'LinkedInApp',
            'LinkedInBot',
            'linkedinbot',
            'LookseekBot',
            'Lycos',
            'Mastodon',
            'Maxthon',
            'Mediapartners-Google',
            'Mediapartners-Google/2.1',
            'Midori',
            'Mi Browser',
            'MojeekBot',
            'Mozilla',
            'MS Search',
            'Msie',
            'msnbot',
            'msnbot-media',
            'MSNBot-NewsBlogs',
            'MetaGer',
            'MojeekBot',
            'Opera',
            'OPR',
            'PeekBot',
            'Pinterest',
            'QwantBot',
            'Qwantify',
            'Safari',
            'SamsungBrowser',
            'Seamonkey',
            'SeznamBot',
            'SeznamBot/4.0',
            'Slurp',
            'StartpageBot',
            'SwiftBot',
            'StartPage',
            'Search Encrypt',
            'Swisscows',
            'TumblrBot',
            'Vivaldi',
            'YaBrowser',
            'YacyBot',
            'YaDirectFetcher',
            'YaDirectFetchery',
            'Yahoo! Slurp',
            'yahoo-blogs',
            'yahoo-blogs/v3.9',
            'Yandex',
            'Yandex favicon',
            'YandexAccessibilityBot',
            'YandexBlogs',
            'YandexBot',
            'YandexFavicons',
            'YandexImages',
            'YandexMedia',
            'YandexMobileBot',
            'YandexNews',
            'YandexPagechecker',
            'YandexScreenshotBot',
            'YandexVideo',
            'YandexBot/3.0y',
            'YandexBlogs/0.99y',
            'YandexAccessibilityBot/3.0y',
            'YaDirectFetchery',
            'YandexPagechecker/1.0y',
            'YaDirectFetcher/1.0y',
            'YandexMobileBot',
            'YandexMobileBot/3.0y',
            'Yandex Robot',
            'YandexImages/3.0y',
            'YandexImageResizer/2.0y',
            'YandexVideoParser/1.0y',
            'YandexWebmaster/2.0y',
            'Yeti',
            'Yeti/1.1',
            'Yeti-Mobile',
            'Qwant',
            'Qwantify',
            'WebwikiBot',
            'WebCrawler'
        ];
        
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
            'curl/7.68.0' => 'cURL Bot (BLOCKED)',
            'OpenAI-GPT/1.0' => 'OpenAI Bot (BLOCKED)',
            'python-requests/2.25.1' => 'Python Requests (BLOCKED)',
            'Googlebot/2.1' => 'Google Bot (ALLOWED)',
            'ChatGPT-User' => 'ChatGPT User (BLOCKED)',
            'Mozilla/5.0 (compatible; bingbot/2.0)' => 'Bing Bot (ALLOWED)',
            'Headless Chrome' => 'Headless Browser (BLOCKED)',
            'facebookexternalhit/1.1' => 'Facebook Bot (BLOCKED - not in allowed list)',
            'Twitterbot/1.0' => 'Twitter Bot (BLOCKED - not in allowed list)'
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);
            
            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }
            
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    private function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }
        
        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if the bot is in the allowed bots list
     */
    private function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
