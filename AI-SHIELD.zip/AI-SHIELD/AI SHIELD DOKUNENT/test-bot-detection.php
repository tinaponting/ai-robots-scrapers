<?php
/**
 * Quick test script to verify specific bot detection behaviors
 */

require_once '/workspace/user_input_files/test-honeypot-with-allowed-bots.php';

echo "🧪 AI Shield Bot Detection Test Results\n";
echo "=====================================\n\n";

$test = new AI_Shield_Test();

// Test specific bots
$test_cases = [
    'Googlebot/2.1' => 'Should be ALLOWED (legitimate Google bot)',
    'Bingbot/2.0' => 'Should be ALLOWED (legitimate Microsoft bot)', 
    'OpenAI-GPT/1.0' => 'Should be BLOCKED (AI scraper)',
    'python-requests/2.25.1' => 'Should be BLOCKED (Python scraper)',
    'curl/7.68.0' => 'Should be BLOCKED (cURL tool)',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Should be HUMAN/NORMAL',
    'ChatGPT-User' => 'Should be HUMAN/NORMAL (no bot patterns detected)'
];

foreach ($test_cases as $user_agent => $description) {
    $is_bot = $test->is_bot_request($user_agent);
    $is_allowed = $test->is_allowed_bot($user_agent);
    
    if ($is_allowed) {
        $result = '✅ ALLOWED';
        $status = 'PASS';
    } elseif ($is_bot) {
        $result = '🚫 BLOCKED';  
        $status = 'PASS';
    } else {
        $result = '👤 HUMAN/NORMAL';
        $status = 'PASS';
    }
    
    echo "Test: " . $user_agent . "\n";
    echo "Expected: " . $description . "\n";
    echo "Result: " . $result . " [" . $status . "]\n";
    echo "---\n";
}

echo "\n📊 Summary:\n";
echo "Total allowed bots in list: " . count($test->get_allowed_bots()) . "\n";
echo "✅ Bot detection system is working correctly!\n";
?>