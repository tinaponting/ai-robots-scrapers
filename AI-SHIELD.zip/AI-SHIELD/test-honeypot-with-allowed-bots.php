<?php
/**
 * AI Shield Bot Detection Test
 * 
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * 
 * NEW FEATURE: Allowed Bots List
 * - Legitimate search engine bots (Google, Bing, Yandex, etc.) are now whitelisted
 * - These allowed bots will NOT be blocked by the honeypot system
 * - Only AI scrapers and malicious bots will be blocked
 * - This ensures your site remains SEO-friendly while protecting against AI content theft
 * 
 * CHECKED BY: Minimax
 */

class AI_Shield_Test {
    
    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;
    
    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [
            // AI-related patterns
            ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$", "ai=n",
            
            // Python-related patterns
            "python", "pyth", "pyscan", "py", "pyq", "python-http", 
            "python-requests", "python\-requests", "python requests", 
            "python-requests/2.32.3", "pythonrequests", "python-urllib", 
            "python\-urllib", "python aiohttp", "python-httpx", "python-async",
            
            // Python tools and libraries
            "photon", "photon/1.0", "python scrapy", "python/3.12 aiohttp",
            "pycurl", "python2 snitch.py", "urllib3", "requests", "httpx", "scrapy",
            "aiohttp", "urllib", "beautifulsoup", "bs4", "selenium", "playwright",
            "mechanize", "selenium", "webdriver", "pageobj", "lxml", "feedparser",
            
            // Development/testing tools
            "postman", "prometheus",
            
            // PHP patterns
            "php", "php://input", "phpcrawler", "php meterpreter", "profacefinder",
            
            // General bot patterns
            "bot", "crawl",  "GET /wp-json/wp/v2/posts HTTP/1.1", "spider", "scrape", "fetch", "curl", "wget", "fetch", "scrap", "harvest", "collect", "extract", "download", "sync"
			
			// AI BOTS
           ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$","ai=n","Abacus AI Deep Agent","AcademicBotRTU","AddSearchBot","Agent 3","Agent API","Agent GPT","Agent Middleware","AgentGPT","Agentic Deep Research",
		   "Agentic RAG with LangGraph","Agentic RAG with Reasoning","Agentic RAG","Agentic","Agentic-RAG","AgentQL","Agent-E","AI Agentic RAG Pipeline","AI agents /","AI Agent","AI Article Writer","AI Chatbot",
		   "AI Chat","AI Content Detector","AI copilot","AI Crawler","AI Data Scraper","AI Deep Research Agent","AI Detection","AI Dungeon","AI guardrails","AI Journalist Agent","AI Journalist","AI Legion","AI RAG",
		   "AI Scraper","AI Search Engine","AI Search Intent","AI Search","AI SEO Crawler","AI Web Scraper","AI Website Screenshot","AI Web","AI Writer","AI2 Bot","AI2Bot","Ai2Bot-DeepResearchEval","AI2","AI21 Labs",
		   "AIBot","aiHitBot","AIMatrix","airesearchbot","AISearchBot","AISearch","AITraining /","AITraining","ai-agent-playwright","ai-crawlers-training","AI-Crawler","ai-proxy","AlexaTM","Alexa","Alice Yandex",
		   "AliGenie","AliyunSecBot","AliyunSec","Alpha AI","AlphaAI","Amazon Athena","Amazon Bedrock AgentCore Browser","Amazon Bedrock","Amazon Comprehend","Amazon Kendra Web Crawler","Amazon Lex",
		   "Amazon Q Business","Amazon SageMaker","Amazon Silk","Amazon Textract","Amazonbot","amazonBot","AmazonBuyForMe","Amazon","amazon-kendra","Amelia","AndiBot","Anomura","anonymous AI chatbot","Anonymous AI",
		   "anthropic bot","Anthropic Computer Use","Anthropic","anthropic-ai","Anthropic-Claude","AnyPicker","AnythingLLM","Anyword","Applebot-Extended","Apple-GenAI","Aria AI","Aria browse Aria AI","Aria browser AI",
		   "Aria Browse","Articoolo","Ask AI","atlassian-bot","AutoGen","AutoGLM","AutoGPT","Automated Writer","AutoML","Autonomous RAG","AutoRAG","AutoScraper","AutoWebGLM","AwarioRssBot","AwarioSmartBot","AWS bedrock",
		   "AWS Trainium","Azure AI Search","Azure OpenAI","Azure","BabyAGI","baiduspider-ai","BabyCatAGI","BardBot","Basic RAG Chain","Basic RAG","Bedrock Claude","Bedrock","bedrock-chatbot","bedrock-chat",
		   "bedrock-claude-chatbot","Big Sur AI Crawler","Big Sur AI","Big Sur","Bigsur","bigsur.ai","Botsonic","Brave Leo AI","BraveGPT","Brightbot 1.0","Brightbot operator","Brightbot","Browser MCP Agent",
		   "BrowserBase Open Operator","Browser Use","Bytebot","ByteDance crawler","ByteDance","bytedance","Bytespider","BuddyBot","CarynAI","Claude Opus 4.5 ","CatBoost","CCBot","ccbot","CCBot/2.0","CC-Crawler",
		   "CC-Crawler/2.0","Celia","Ceramic TerraCotta Crawler","Chai","Character","Character-AI","Charstar AI","Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGLM","ChatGLM-Spider","ChatGPT 3.0","ChatGPT 4o",
		   "ChatGPT 4o-mini","ChatGPT 4.1","ChatGPT 4.5","ChatGPT 5","ChatGPT Agent","ChatGPT o1","ChatGPT o3-mini","ChatGPT Operator","ChatGPT Retrieval","ChatGPT search","ChatGPT","ChatGPT-User v2.0","ChatGPT-User",
		   "ChatGPT-User/1.0","ChatGPT-User/2.0","ChatLLM","ChatOpenAI","Chatsonic","chatUser /","ChatUser","Chinchilla","Claude 3.5 Haiku","Claude 3.5 Sonnet","Claude 3.5","Claude 3.7 Sonnet","Claude 4","Claude Agent",
		   "Claude Haiku 4.5","Claude LLM","Claude Opus 4","Claude Opus 4.1","Claude Opus","Claude Sonnet 4","Claude Sonnet 4.5","ClaudeBot","ClaudeBot/1.0","ClaudeBot/1.6","Claude","Claude-RAG","Claude-SearchBot",
		   "Claude-User","Claude-Web","claude-web/1.0","claude.ai","ClearScope","Clearview","Cloudflare AutoRAG","Cloudflare-AutoRAG","CloudVertexBot","Cognitive AI engine","Cognitive AI","Cohere LLM","Cohere RAG","Cohere",
		   "cohere-ai","cohere-ai/1.0","Cohere-Command","cohere-training-data-crawler","Command-A-Reasoning","Common Crawl","CommonCrawl","Compass","Content Harmony","Content King","Content Optimizer","Content Samurai",
		   "Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","CopilotBot","Copilot","CopyAI","Copymatic","Copyscape","CoreWeave","Corrective RAG","Cotoyogi","CRAB","Crawl4AI",
		   "Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crew AI","CrewAI","Crushon AI","cURL /","cURL","cypex.ai/scanning","DALL-E 2","Dall-E 4","DALL-E Mini","DALL-E","DALL·E 3","DarkBARD","DarkBard","DarkBERT","DarkGPT",
		   "DataForAI","DataForSeoBot","DataFor","DataProvider","dataprovider","Datenbank Crawler","Deep","Deep AI","Deep Research","DeepAI","DeepL Agent","DeepL","DeepMind","DeepResearch","Deepseek Agent","Deepseek Local RAG Agent",
		   "DeepSeek R1 Chatbot","DeepSeek R1 Y","DeepSeek V3","DeepSeekBot ","DeepSeekV2.5-Chat","DeepSeek","DeepSeek-LLM","DeepSeek-R1","DeepSeek-V3.1","DepolarizingGPT","Devin","DialoGPT","Diffbot","DigitalOceanGenAICrawler",
		   "DocsGPTOnyx","Dolma","Dots Chatbot","Doubao AI","DuckAssistBot","DuckDuckGo Chat","DuckDuckGo-Enhanced","Duck.ai","Echobot","Echobox","ERNIE X1.1","Embed v3","Elixir","Evil-GPT","Extended GPT Scraper",
		   "FacebookBot","FacebookBot/1.0","FacebookExternalHit","facebookexternalhit/1.1","Factset_spyderbot","Falcon","FAISS","Fastai","FastGPT","Firebase","FirecrawlAgent","Firecrawl","Fireworks","FIRE-1 Agent","FIRE-1",
		   "Flux","flyriverbot/1.1","Flyriver","Frase AI","FraudGPT","FriendlyCrawler","AI Ghostwriter","Gato","Gemini Agentic RAG","Gemini User","Gemini","Gemini-Ai","Gemini-Deep-Research","Gemma 3","Gemma","Gen AI","GenAI Chat",
		   "GenAI RAG","GenAI","Generative","Genspark","gentoo-chat","gen-ai","Ghostwriter","GhostGPT","GigaChat","GLM","GLM 4.6","GodMode","Google Gemini","GoogleAgent-Mariner","Google-NotebookLM","Google-CloudVertexBot",
		   "Google-Extended","Goose","Go","GPT 4 Omni Mini","GPT 4 Omni","GPT Chat 3","GPT OSS","GPT Researcher","GPT Scraper","GPT /","GPT4ALL","GPT4Free","GPTBot /","GPTBot/1.3","GPTZero","GPT","GPT-1","GPT-2","GPT-3",
		   "GPT-3.5 turbo","GPT-3.5","GPT-4o Image","GPT-4o mini","GPT-4o","GPT-4V","GPT-4","GPT-4,5","gpt-4-turbo","GPT-4.1","GPT-4.1-mini","GPT-4.1-nano","GPT-5 Chat","GPT-5 Mini","GPT-5 Nano","GPT-5 Thinking mini","GPT-5-high",
		   "GPT-5o","GPT-5","GPT-5.1","GPT-5.1 Instant","GPT-5.1 Thinking","GPT-5.1 Auto","gpt-crawler","GPT-oss /","GPT-Qwen Deep Research","GPT-Shield-AI-Plagiarism-Detector","GPT/","Grammarly","Grendizer","gobrowser","Grok 4 Fast",
		   "Grok AI chatbot","GrokAI","Grok","Groq-Bot","GrokBot","Grok-4","Grok-4 Heavy","GT Bot","GTBot","GTPBOT","GTP","Haystack RAG Pipeline","Haystack - deepset AI","Hemingway Editor","Hetzner","Hugging Face","HuggingChat",
		   "huggingfacebot","HuggingFace-Bot","hugging-face-ai","Hugging","Hunyuan","Hunyuan-7B-Instruct 7B","Hunyuan-Large-Instruct ","hybrid LLM","Hybrid Search RAG","Hypotenuse AI","iAskBot","Ideogram","imgproxy","iaskspider",
		   "iaskspider/2.0","iAskBot","ICC-Crawler","ImagesiftBot","img2dataset","ImageGen","ImageGen /","Imagen 4","MAI-Image-1","ImageGPT","Inferkit","INK Editor","INKforall","IntelliSeek","IntelliSeek.ai","Instructor",
		   "instructor-php","ISSCyberRiskCrawler","Jamba 1.5 Large","Jamba 1.5 Mini","Janitor AI","JasperAI","Jenni AI","Julius AI","Kafkai","Kaggle agent","Kaggle","Kangaroo Bot","Kangaroo","Kangaroo-Bot","KawaiiGPT",
		   "Keyword Density AI","Kimi K2","Kimi","Kimi-2","Kimi-k1.5","Kimi-VL","Kingsoft-LLM","KI-Crawler","KlaviyoAIBot","Knowledge Graph","knowledge graph","knowledge /","Knowledge","knowledge-base","Knowledge-graph RAG",
		   "KomoBot","Kruti","LAIONDownloader","LAION-5B","LAION-huggingface-processor","Langchain raptor","LangChain","langchain-google-genai","langchain-openai","langchain-perplexity","LangExtract","Langfuse","Language AI",
		   "LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Lightpanda","LinerBot","LinkupBot/1.0","LiteLLM Proxy","LiteLLM Python","LiteLLM","Llama 3.1 Local RAG","Llama 3.2","Llama 4","Llama3.1-70B-Instruct","Llama3.1-405B-Instruct",
		   "LLaMA","LLM Proxy","LLM Scraper","LLM","LLM-jp-Crawler","Local Hybrid Search RAG","Local RAG Agent","Local RAG","LocalAI","Lovable","Magistral","Magistral Medium","MalwareGPT","Magnus","magpie-crawler","Manus","MarketMuse",
		   "Meltwater","Meta Agent","Meta AI Crawler","Meta AI","Meta Llama","MetaAI","MetaGPT","MetaTagBot","MetaTagBot","Meta-AI","Meta-ExternalAgent","meta-externalagent","Meta-ExternalFetcher","meta-externalfetcher/1.1",
		   "Meta-External","Meta-Webindexer 1.1","Meta-Webindexer","meta-webindexer/1.1","Meta.AI","Middleware","midjourney","Mini AGI","MiniMax","Mintlify","MistralAI-User","MistralAI-User/1.0","Mistral","Mistral.ai","Mixtral 8x22B",
		   "Mixtral-8x22B-Instruct","MBZUAI Chatbot","MobileLLM-R1","model-training","Monica","Moonshot ","Mycroft AI","Molmo","n8n-nodes-aiscraper","Nano Banana","Nanobrowser","nanochat","Narrative Device","Narrative","Narrative",
		   "NeevaBot","netEstate Imprint Crawler","netEstate","NetShelter ContentScan","Neural Text","NeuralSEO","NextChat","Nicecrawler","Nicecrawler","NinjaAIBot/1.0","NinjaAIBot/1.0","NinjaAI","NodeZero","Node.js","NotebookLM Deep Research",
		   "NotebookLM","Nova Act","NovaAct","Nytheon AI","OAI SearchBot","OAI-SearchBot","OAI-SearchBot/1.0","OAI-SearchBot/1.3","OASIS","Ola","Olivia","Ollama","oLLM","OLMo 2 Chatbot","OLMO 3","OLMoASR","OLMoE","OLMo","Omgilibot",
		   "Omgili","Onyx","Open AI","Open Deep Research","Open Interpreter","Open Lovable","Open Operator","Open Perflexity","Open Source LLM","OpenAGI","OpenAI Crawler","OpenAI CUA","OpenAI GPTBot","OpenAI Image Downloader",
		   "OpenAI o1","OpenAI o1-mini","OpenAI o3","OpenAI o3","OpenAI o3-mini","OpenAI o4","OpenAI o4-mini","OpenAI Operator","OpenAIContentCrawler","OpenAI","openai-python","openai-user","OpenBot","OpenInterpreter","OpenLens AI",
		   "openpi","OpenRouter","openrouter","OpenText AI","open-manus-v2","Operator","Outwrite","OVHcloud AI Training","Owlin","OWL","Open Perflexity","PandasAI","Page Analyzer AI","PaLM 2","PanguBot","Panscient","panscient.com",
		   "PaperLiBot","Paraphraser.io","peer39_crawler","peer39_crawler/1.0","PerfectChatGPT","Perflexity","Perplexity AI","Perplexity Deep Research","Perplexity Search","Perplexity Stealth","PerplexityBot","PerplexityBot/1.0",
		   "PerplexityUser","Perplexity","perplexity**.ai","Perplexity-User","Perplexity-User/1.0","Perplexit-User","PetalBot","petalBot","Petabot","Petal","PhindBot","Phind","PiplBot","Pixmo","Playwright Agentic AI","PoeBot",
		   "Poggio-Citations","PoeSearchBot","Poe","PoisonGPT","PrivateGPT","ProWritingAid","proximic","PulsarRPA","Puppeteer","python Ai","Python lxml","PyTorch Lightning LLM","PyTorch Lightning","PyTorch","Qwen","qwen /","Qwen",
		   "Qwen-Agent","Qwen Deep Research","Qwen Chat","Qwen-Chat","Qwen2","Qwen3","Qwen 4","qwen:4b","Qwen 4 LLM","QwenLM","Qwen2.5 72B","Qwen 2.5‑VL","Qualified","QualifiedBot","quillbot.com","QuillBot","Quark","Qopywriter.ai",
		   "AI RAG","Llama 3.1 Local RAG","Local Hybrid Search RAG","Local RAG Agent","RAG Agent Cohere","RAG Agent with Cohere","RAG Agent","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG IS ","RAG LLM","RAG pipeline",
		   "RAG Search","RAG with Database Routing","RAG with ","RAG","RAG-as-a-Service","RAG-","RAG_VertexAI","RAG_with_search","RAG_","RAPTOR LLM","Raptor","React Agent","ReAct AI Agent","ReaderLM-v2","ReadyAI","REALM","Redis AI RAG ",
		   "Reka Flash 3.1","Replicate-Bot","Replicate-Bot","resec.ai","RightWingGPT","RobotSpider","RunPod-Bot","Rytr","SAM 3","Sambanova","SaplingAI","SBIntuitionsBot","Scala","scaleai","Scalenut","scale-crawler","scan.cypex.ai",
		   "ScrapeGraphAI","ScrapeGraph","Scrapegraph-ai","Scrapegraph-ai","Scraper Bot","ScraperGPT","Scraper","Scraping Agent AI","Scrapy 2.12.0","Scrapy 2.13.1","Scrapy","Scrapy-LLM","Scrapy/2.0","ScriptBook","Search GPT",
		   "Search RAG","SearchGPT","Seekr","SeLLMa","SemrushBot","SemrushBot-FT","SemrushBot-OCOB","SemrushBot-SWA","Sentibot","SEO Content Machine","SEO Robot","SEObot","ShadowGPT","ShapBot","ShapBot","Shell GPT","sider.ai","Sidetrade /",
		   "Sidetrade","Simplified AI","Sitefinity","skrape.ai","Skydancer","Skyvern","SlickWrite","SmartBot","SmartScraperGraph","SmartScrape","Sonic","Sora","SpamGPT","spawning-ai","Spider","Spider-Agent","Spider/2.0; +https://spider.cloud",
		   "Spin Rewrite","Spinbot","Stability AI","Stable Diffusion","StableDiffusionBot","Stagehand","STEALTH","Step 3","Sudowrite","SummalyBot","Super Agent","Superagent","superagi","Surfer AI","SUSE AI ","taiko","TerraCotta",
		   "Text Blaze","TextCortex","Text-RAG","The Knowledge AI","TheKnowledgeAI","thehive.ai","Thinkbot","Thinkbot/0.5.8","Thordata","TikTokSpider","Timpibot","together AI","Together-Bot","TorChat","Traefik","TurnitinBot","Tülu",
		   "uAgents","UI-TARS","U haystack-ai","AI – WPBot","ai-writer","VelenPublicWebCrawler","Venus AI","Venus Chub AI","Vidnami AI","Vision RAG","vnCallbot","vnFace","VNPT SmartBot","VNPT SmartReader","VimGPT","Weaviate",
		   "Web 3.0 Navigator","WebVoyager","WebChatGPT","WebCrawler-AI","WebCrawler-AI","WebExplorer-","Webscrape AI","Webscrape AI","Webscrape","webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","WebSurfer",
		   "WebText /","WebText","Webzio","Webzio-Extended","WeChat","Whisper","WizardLM","WordAI","Wordtune","WormGPT V3.0","WormGTP","wormsGTP","WolfGPT","WPBot","wpbot","WPBot/1.1","WPBot/1.2","WPBot/1.2","Writecream","WriterZen",
		   "Writescope","Writesonic","WRTNBot","WRTNBot","WRTNBot/1.0","WRTNBot/1.0","xAI","xAI-Bot","X.AI","xBot","XLNet","yarchatgpt","YandexGPT","YandexLLM","YandexAdditional","YandexAdditionalBot","YaLM","YarGPT","YarGPTZero /","YouBot",
		   "you-bot","YourGPT","ZanistaBot","Zero","Zero /","Zero GTP","ZeroCHAT","Zerochat","ZeroGPT","ZeroStep","ZeroSearch","Zhipu","Zhuque AI","Zhuque AI Detector","XXXGPT","Xanthorox AI","Zhuque AI","Zimm",
        ];
        
        // Initialize allowed bots list (legitimate search engines and crawlers)
        $this->allowed_bots = [
            // Major search engines
            'AOL Search',
            'AdsBot-Google',
            'APIs-Google',
            'Applebot',
            'AppleNewsBot',
            'apple-app-site-association',
            'archive.org_bot',
            'Android OS',
            'Bingbot',
            'bingbot',
            'BingPreview',
            'bing',
            'bingbot/2.0',
            'Brave',
            'BraveBot',
            'Chrome',
            'CocCoc',
            'CocCocBot',
            'coccocbot-image',
            'coccocbot-web',
            'coccocbot-web/1.0',
            'CriOS',
            'Dolphin Browse',
            'DuckDuckBot',
            'DuckDuckGo-Favicons-Bot',
            'DuplexWeb-Google',
            'Dolphin Browser',
            'Dogpile',
            'Ecosia',
            'EcosiaBot',
            'Edg',
            'Edge',
            'Exabot',
            'Feedfetcher-Google',
            'Firefox',
            'FxiOS',
            'Gigablast',
            'Gigabot',
            'Google Favicon',
            'Google Mobile Adsense',
            'google page speed',
            'Google Read Aloud',
            'Google Site Verifier',
            'Googlebot',
            'Googlebot Smartphone',
            'Googlebot-Image',
            'Lighthouse',
            'Googlebot-Mobile',
            'googlebot-news',
            'Googlebot-Video',
            'Googlebot/2.1',
            'GoogleProducer',
            'Google-InspectionTool',
            'Google-Mobile-Apps',
            'Google-Safetys',
            'Googlebot-Image/1.0',
            'DuplexWeb-Google',
            'Mediapartners-Google',
            'Mediapartners-Google/2.1',
            'Google-InspectionTool/1.0',
            'Googlebot-Video/1.0',
            'Google-Site-Verification/1.0',
            'Info.com',
            'ia_archiver',
            'IceCat',
            'Instagram',
            'Konqueror',
            'LinkedInApp',
            'LinkedInBot',
            'linkedinbot',
            'LookseekBot',
            'Lycos',
            'Mastodon',
            'Maxthon',
            'Mediapartners-Google',
            'Mediapartners-Google/2.1',
            'Midori',
            'Mi Browser',
            'MojeekBot',
            'Mozilla',
            'MS Search',
            'Msie',
            'msnbot',
            'msnbot-media',
            'MSNBot-NewsBlogs',
            'MetaGer',
            'MojeekBot',
            'Opera',
            'OPR',
            'PeekBot',
            'Pinterest',
            'QwantBot',
            'Qwantify',
            'Safari',
            'SamsungBrowser',
            'Seamonkey',
            'SeznamBot',
            'SeznamBot/4.0',
            'Slurp',
            'StartpageBot',
            'SwiftBot',
            'StartPage',
            'Search Encrypt',
            'Swisscows',
            'TumblrBot',
            'Vivaldi',
            'YaBrowser',
            'YacyBot',
            'YaDirectFetcher',
            'YaDirectFetchery',
            'Yahoo! Slurp',
            'yahoo-blogs',
            'yahoo-blogs/v3.9',
            'Yandex',
            'Yandex favicon',
            'YandexAccessibilityBot',
            'YandexBlogs',
            'YandexBot',
            'YandexFavicons',
            'YandexImages',
            'YandexMedia',
            'YandexMobileBot',
            'YandexNews',
            'YandexPagechecker',
            'YandexScreenshotBot',
            'YandexVideo',
            'YandexBot/3.0y',
            'YandexBlogs/0.99y',
            'YandexAccessibilityBot/3.0y',
            'YaDirectFetchery',
            'YandexPagechecker/1.0y',
            'YaDirectFetcher/1.0y',
            'YandexMobileBot',
            'YandexMobileBot/3.0y',
            'Yandex Robot',
            'YandexImages/3.0y',
            'YandexImageResizer/2.0y',
            'YandexVideoParser/1.0y',
            'YandexWebmaster/2.0y',
            'Yeti',
            'Yeti/1.1',
            'Yeti-Mobile',
            'Qwant',
            'Qwantify',
            'WebwikiBot',
            'WebCrawler'
        ];
        
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
            'curl/7.68.0' => 'cURL Bot (BLOCKED)',
            'OpenAI-GPT/1.0' => 'OpenAI Bot (BLOCKED)',
            'python-requests/2.25.1' => 'Python Requests (BLOCKED)',
            'Googlebot/2.1' => 'Google Bot (ALLOWED)',
            'ChatGPT-User' => 'ChatGPT User (BLOCKED)',
            'Mozilla/5.0 (compatible; bingbot/2.0)' => 'Bing Bot (ALLOWED)',
            'Headless Chrome' => 'Headless Browser (BLOCKED)',
            'facebookexternalhit/1.1' => 'Facebook Bot (BLOCKED - not in allowed list)',
            'Twitterbot/1.0' => 'Twitter Bot (BLOCKED - not in allowed list)'
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);
            
            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }
            
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    private function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }
        
        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if the bot is in the allowed bots list
     */
    private function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
