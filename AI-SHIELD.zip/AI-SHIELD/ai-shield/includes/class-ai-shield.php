<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 * @package    Ai_Shield
 * @subpackage Ai_Shield/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 * @package    Ai_Shield
 * @subpackage Ai_Shield/includes
 * @author     Matthew Davidson <matthew@modulolotus.net>
 */
class Ai_Shield {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 * @access   protected
	 * @var      Ai_Shield_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 * @access   protected
	 * @var      string    $ai_shield    The string used to uniquely identify this plugin.
	 */
	protected $ai_shield;

	/**
	 * The current version of the plugin.
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

    protected $zero_width_chars;
    protected $space_substitute_chars;
    protected $bot_user_agents;
    protected $dummy_content_templates;

    /**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 */
	public function __construct() {
		if ( defined( 'AI_SHIELD_VERSION' ) ) {
			$this->version = AI_SHIELD_VERSION;
		} else {
			$this->version = '1.1.0';
		}
		$this->ai_shield = 'ai-shield';

//        $this->zero_width_chars = array_map('mb_chr', [0x180e, 0x034f, 0x17b4, 0x17b5, 0x200b, 0x2060, 0x2062, 0x2061]);
        $this->zero_width_chars = array_map('mb_chr', [0x034f, 0x2060, 0x2062, 0x2061]);
        $this->space_substitute_chars = array_map('mb_chr', [0x0009, 0x000d, 0x000A]);
        
        // Initialize bot detection patterns
        $this->bot_user_agents = [
            'bot', 'crawl', 'spider', 'scraper', 'scrape', 'scan',
            'openai', 'gpt', 'claude', 'anthropic', 'chatgpt',
            'curl', 'wget', 'python', 'requests', 'urllib',
            'headless', 'phantom', 'selenium', 'playwright',
            'facebookexternalhit', 'twitterbot', 'linkedinbot',
            'slurp', 'bingbot', 'googlebot', 'yandexbot',
            'baiduspider', 'duckduckbot', 'archive.org'
        ];
        
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Ai_Shield_Loader. Orchestrates the hooks of the plugin.
	 * - Ai_Shield_i18n. Defines internationalization functionality.
	 * - Ai_Shield_Admin. Defines all hooks for the admin area.
	 * - Ai_Shield_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ai-shield-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-ai-shield-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-ai-shield-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-ai-shield-public.php';

		$this->loader = new Ai_Shield_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Ai_Shield_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Ai_Shield_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 * @access   private
	 */
	private function define_admin_hooks() {

		$admin = new Ai_Shield_Admin( $this->get_ai_shield(), $this->get_version() );

		$this->loader->add_action( 'admin_init', $admin, 'register_settings' );
		$this->loader->add_action( 'admin_menu', $admin, 'register_options_page' );

		$this->loader->add_filter( 'plugin_action_links_' . plugin_basename( AI_SHIELD_PLUGIN_FILE ), $admin, 'plugin_action_links' );

		$this->loader->add_action( 'admin_enqueue_scripts', $admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $admin, 'enqueue_scripts' );

	}

	private function transform_content( $content, $debug_mode = false ) {
		// $len = mb_strlen($content);
		// return chunk_split($content, mt_rand(2, 20), mb_chr(0x180E));
		// $content = chunk_split($content, mt_rand(2, 20), '❄');
		// $content = chunk_split($content, mt_rand(2, 20), '❄');
		// $content = chunk_split($content, mt_rand(2, 20), '❄');

		// $num_iters = 3;
		// $rand_keys = array_rand($this->zero_width_chars, $num_iters);
		// for ($i = 0; $i < $num_iters; $i++) {
		//     $content = implode($this->zero_width_chars[$rand_keys[$i]], mb_str_split($content, mt_rand(2,20)));
		// }

		// $content = implode(mb_chr(0x180E), mb_str_split($content, mt_rand(2,20)));
		// $content = implode(mb_chr(0x180E), mb_str_split($content, mt_rand(2,20)));
		// $content = implode('❄', mb_str_split($content, mt_rand(2,20)));
		// $content = implode('❄', mb_str_split($content, mt_rand(2,20)));

		// $pattern = '>[^<]+<';
		// $content = mb_ereg_replace_callback($pattern, function ($matches) {
		//     return '>' . implode('❄', mb_str_split(mb_substr($matches[0], 1, mb_strlen($matches[0]) - 2), mt_rand(2,20))) . '<';
		// }, $content, 'm');


		// $pattern = '(\>|\&\w+;)([^<]*)(\<|\&\w+;)';
		// (>|&\w+;)([^<&]+)(<|&\w+;)
		// $pattern = '(>|;)\s*([^<&]+)\s*(<|&)';

		$pattern = '((?:>|;)\s*)([^<&]+)(\s*(?:<|&))';
		$content = mb_ereg_replace_callback($pattern, function ($matches) use ($debug_mode) {
			if( $debug_mode ) {
				return $matches[1] . implode('❄', mb_str_split($matches[2], mt_rand(2,20))) . $matches[3];
			}

			return $matches[1]
				. implode($this->zero_width_chars[array_rand($this->zero_width_chars)],
					mb_str_split($matches[2], mt_rand(2,10)))
				. $matches[3];
		}, $content, 'm');


		$content = mb_ereg_replace_callback(' ', function ($matches) use ($debug_mode) {
			if( $debug_mode ) {
				return '❄';
			}

			return $this->space_substitute_chars[array_rand($this->space_substitute_chars)];
		}, $content, 'm');

		return $content;
	}

	/**
	 * Detects if the current request is from a bot/scraper
	 * 
	 * @return bool True if bot detected, false otherwise
	 */
	private function is_bot_request() {
		$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
		$user_agent_lower = strtolower($user_agent);
		
		// Check for bot patterns in user agent
		foreach ($this->bot_user_agents as $pattern) {
			if (strpos($user_agent_lower, $pattern) !== false) {
				return true;
			}
		}
		
		// Additional bot detection methods
		$bot_indicators = [
			// No common browser headers
			empty($_SERVER['HTTP_ACCEPT_LANGUAGE']),
			// Suspicious accept headers
			($_SERVER['HTTP_ACCEPT'] ?? '') === '*/*',
			// No referer on first visit (suspicious for scrapers)
			empty($_SERVER['HTTP_REFERER']) && empty($_SERVER['HTTP_CACHE_CONTROL']),
			// Headless browser indicators
			!empty($_SERVER['HTTP_X_REQUESTED_WITH']),
		];
		
		// If multiple indicators are present, likely a bot
		$bot_score = array_sum(array_map('intval', $bot_indicators));
		
		return $bot_score >= 2;
	}
	
	/**
	 * Generates dummy/fake content for bots
	 * 
	 * @param string $original_content The original content
	 * @param string $mode Either 'replace' or 'combine'
	 * @return string Generated dummy content
	 */
	private function generate_dummy_content($original_content, $mode = 'replace') {
		// Get original content stats
		$word_count = str_word_count(strip_tags($original_content));
		$paragraph_count = substr_count($original_content, '</p>') + 1;
		
		// Generate similar length dummy content
		$dummy_sentences = [];
		$sentences_needed = max(3, intval($word_count / 15)); // Roughly 15 words per sentence
		
		for ($i = 0; $i < $sentences_needed; $i++) {
			$template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
			
			// Add some variation
			$variations = [
				str_replace('Lorem', 'Ipsum', $template),
				str_replace('dolor', 'amet', $template),
				str_replace('consectetur', 'adipiscing', $template),
				$template . ' Vestibulum ante ipsum primis in faucibus.',
				'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
			];
			
			$dummy_sentences[] = $variations[array_rand($variations)];
		}
		
		// Group into paragraphs
		$sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
		$paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
		
		$dummy_content = '';
		foreach ($paragraphs as $paragraph) {
			$dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
		}
		
		// If original had title structure, mimic it
		if (strpos($original_content, '</h') !== false) {
			$dummy_title = 'Sample Article Title for Educational Purposes';
			$dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
		}
		
		// Handle combine mode
		if ($mode === 'combine') {
			// Mix dummy content with obscured real content
			$obscured_real = $this->transform_content($original_content, false);
			
			// Interleave dummy and obscured content
			$dummy_paragraphs = explode('</p>', $dummy_content);
			$real_paragraphs = explode('</p>', $obscured_real);
			
			$combined = [];
			$max_paragraphs = max(count($dummy_paragraphs), count($real_paragraphs));
			
			for ($i = 0; $i < $max_paragraphs; $i++) {
				// Randomly choose order
				if (rand(0, 1)) {
					if (isset($dummy_paragraphs[$i])) $combined[] = $dummy_paragraphs[$i] . '</p>';
					if (isset($real_paragraphs[$i])) $combined[] = $real_paragraphs[$i] . '</p>';
				} else {
					if (isset($real_paragraphs[$i])) $combined[] = $real_paragraphs[$i] . '</p>';
					if (isset($dummy_paragraphs[$i])) $combined[] = $dummy_paragraphs[$i] . '</p>';
				}
			}
			
			return implode('', $combined);
		}
		
		return $dummy_content;
	}

	/**
	 * Alters $content to insert zero-width characters inside words, 
	 * and replace spaces with other invisible characters.
	 * 
	 * @param string $content 
	 * @return string|false|null 
	 */
    public function obscure_content( $content ) {
		$options = get_option(Ai_Shield_Admin::OPTION_NAME, Ai_Shield_Admin::DEFAULT_SETTINGS);

		// error_log(var_export($options, true));
		// error_log("is home:".is_home());
		// error_log("is front_page:".is_front_page());
		// error_log("is singular:".is_singular());
		// error_log("in loop:".in_the_loop());
		// error_log("is main query:".is_main_query());

		$debug_mode = array_key_exists('ai_shield_debug', $_GET) ? rest_sanitize_boolean($_GET['ai_shield_debug']) : false;

		if ( $options['ai_shield_enabled'] ) {
			if (( is_front_page() || is_singular() ) && in_the_loop() && is_main_query() ) {
				
				// Check for honeypot mode first
				if ( isset($options['ai_shield_honeypot_enabled']) && $options['ai_shield_honeypot_enabled'] && $this->is_bot_request() ) {
					
					$honeypot_mode = $options['ai_shield_honeypot_mode'] ?? 'replace';
					$log_attempts = $options['ai_shield_log_bot_attempts'] ?? false;
					
					// Log bot attempt if enabled
					if ( $log_attempts ) {
						$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
						$ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
						error_log("AI Shield Honeypot: Bot detected - IP: {$ip_address}, UA: {$user_agent}, Mode: {$honeypot_mode}");
					}
					
					// Serve dummy content to bots
					if ( $options['ai_shield_use_cache'] ) {
						$cache_key = 'ai_shield_dummy_' . $honeypot_mode . '_' . sha1($content);
						$cached_dummy = get_transient($cache_key);
						
						if ( $cached_dummy !== false ) {
							return $cached_dummy;
						} else {
							$dummy_content = $this->generate_dummy_content( $content, $honeypot_mode );
							
							$cache_duration = intval($options['ai_shield_cache_duration']) * MINUTE_IN_SECONDS;
							set_transient($cache_key, $dummy_content, $cache_duration);
							
							return $dummy_content;
						}
					} else {
						return $this->generate_dummy_content( $content, $honeypot_mode );
					}
				}
				
				// Regular obscuration mode for humans or when honeypot is disabled
				if ( $options['ai_shield_use_cache'] ) {
				
					$cache_key = 'ai_shield_' . sha1($content);
					$cached_content = get_transient($cache_key);

					if ( $cached_content !== false ) {
						error_log("Returning cached content for: " . $cache_key);
						return $cached_content;
					} else {
						$content = $this->transform_content( $content, $debug_mode );

						$cache_duration = intval($options['ai_shield_cache_duration']) * MINUTE_IN_SECONDS;
						error_log("Caching for " . $options['ai_shield_cache_duration'] . " minutes");
						set_transient($cache_key, $content, $cache_duration);
					}
				} else {
					$content = $this->transform_content( $content, $debug_mode );
				}
			}
		}

        return $content;
    }

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 * @access   private
	 */
	private function define_public_hooks() {

		// Not currently used
		// $plugin_public = new Ai_Shield_Public( $this->get_ai_shield(), $this->get_version() );
		// $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		// $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

        $this->loader->add_filter( 'the_title', $this, 'obscure_content', PHP_INT_MAX );
        $this->loader->add_filter( 'the_preview', $this, 'obscure_content', PHP_INT_MAX );
        $this->loader->add_filter( 'the_content', $this, 'obscure_content', PHP_INT_MAX );
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 * @return    string    The name of the plugin.
	 */
	public function get_ai_shield() {
		return $this->ai_shield;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 * @return    Ai_Shield_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
