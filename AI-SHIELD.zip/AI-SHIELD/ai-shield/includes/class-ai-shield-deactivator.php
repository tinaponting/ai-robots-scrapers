<?php

/**
 * Fired during plugin deactivation
 * @package    Ai_Shield
 * @subpackage Ai_Shield/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 * @package    Ai_Shield
 * @subpackage Ai_Shield/includes
 * @author     Matthew Davidson <matthew@modulolotus.net>
 */
class Ai_Shield_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 */
	public static function deactivate() {
		
	}

}
