<?php
/*
 * Plugin Name:       AI Shield Enhanced
 * Description:       Advanced AI Shield that protects content from AI scrapers using honeypot technology - serves fake content to detected bots while showing real content to humans. Includes traditional zero-width character obscuration plus intelligent bot detection and dummy content generation.
 * Version:           2.0.0
 * Author URI:        https://github.com/KingMob
 * FORK URI:          https://teskedsgumman.se
 * License:           GPL-2.0
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ai-shield
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'AI_SHIELD_PLUGIN_FILE' ) ) {
	define( 'AI_SHIELD_PLUGIN_FILE', __FILE__ );
}

define( 'AI_SHIELD_VERSION', '2.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-ai-shield-activator.php
 */
function ai_shield_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ai-shield-activator.php';
	Ai_Shield_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-ai-shield-deactivator.php
 */
function ai_shield_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ai-shield-deactivator.php';
	Ai_Shield_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'ai_shield_activate' );
register_deactivation_hook( __FILE__, 'ai_shield_deactivate' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-ai-shield.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 */
function ai_shield_run() {

	$plugin = new Ai_Shield();
	$plugin->run();

}
ai_shield_run();
