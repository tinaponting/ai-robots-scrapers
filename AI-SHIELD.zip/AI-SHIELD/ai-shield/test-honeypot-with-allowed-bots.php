<?php
/**
 * AI Shield Bot Detection Test
 *
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * FORK OF: https://github.com/common-repository/ai-shield
 * Maintained by: https://teskedsgumman.se
 */

class AI_Shield_Test {
    
    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;
		     //CDN and proxy patterns
            "Cloudflare","CF-RAY","Akamai","Fastly","CloudFront","Incapsula","Sucuri","SiteLock","DDOS-GUARD","Qrator","GreyNoise","Project","Project Shield","Google Shield","Apple-App","node-fetch","axios","got","bent",

            //General bot patterns
            "crawl","crawler","cURL","curl","JavaScript","spider","wget","download","sync","srequests.get",

            //Headless and scraping tools
            "Data Miner","crawler","spider","scan","scanner","attack","vuln","exploit","datado","splunk","newrelic","elastic","masscan","nmap","nikto","sqlmap","dirbuster","gobuster","wfuzz","phpunit","HttpClient","Apache-HttpClient","scraper","java","Jetty","okhttp","wget",

            //Screen scraping tools and automation
            "capture","collect","extract",'Dataminer',"Screenshot","Snap","Grab","Scrap","scrape","scraper","Harvest","Fetcher","Grabber","ripper","Extractor","WebZIP","WebWhacker","BlackWidow","Bot","Snoopy","W3mir","WebReaper","WebStripper","WebSnatcher",

            //HTTP libraries and clients
            "Apache-HttpClient","HttpClient","Jakarta Commons-HttpClient","libwww-perl","LWP::Simple","Net::HTTP","HTTP::Lite","HTTP::Tiny",
            "Perl","LWP","Mechanize","WWW::Mechanize","Mojo::UserAgent","HTTPx::Client","REST::Client","HTTPC::Client","axios","got","node-fetch","undici","superagent","request","bent","got",

            //Headless browsers and automation
            "HeadlessEdg","Headless","HeadlessChrome","Lightpanda","Zombie","SlimerJS","CasperJS","PhantomJS","Splash","HtmlUnit","TrifleJS","Envjs","浏览器","Liebao",
            "Maxthon","Maxthon Nitro","Comodo Dragon","CoolNovo","RockMelt","Flock","Camino","Chimera","K-Meleon","Midori","QupZilla","Vimb","Luakit","Dillo","ELinks","Links","NetSurf","surf","Uzbl","W3m",

            //Cloud/SaaS scraping services
            "ScraperAPI","Crawlera","Proxy","ProxyCrawl","Zyte","Smartproxy","Oxylabs","Luminati","Netnut","GeoSurf","Stormproxies","Bright Data","DataImpulse","PacketProxy","Rsocks","Socks5","Socks4","HTTP Proxy","SOCKS Proxy","VPN",

            //Feed readers and syndication
            "Feedsky","RSS","Atom","Syndication","NewsBlur","Feedly","Pulse","Flipboard","Yahoo! Slurp","TumblrBot","WhatsApp","TelegramBot","Slack-LinkPreview","Slackbot","Discordbot","TeamsBot","TeamsLinkPreview","SkypeUriPreview",
            
			//Misc Scrapers
            "cms-checker","assetnote","Iron","XenWare","Obsidian","Mozlila","KOCMOHABT","Odin","ORT","CriOS/99.0.4844.47","Mozilla/5.0 (X11; Linux x86_64",

			//SCRAPY
            "CrawlSpider","python scrapy","scraper","scrapy","Scrapy 2.14.1","Scrapy JavaScript","Scrapy selenium","Scrapy shell","Scrapy Splash","ScraPy Spiders","Scrapy - Shell","Scrapy-playwright","Python Scrapy","SitemapSpider","scrapy-redis","scrapy php","scrapy.Spider","XMLFeedSpider",

			//Cloud/SaaS scraping services
            "ScraperAPI","Crawlera","Proxy","ProxyCrawl","Zyte","Smartproxy","Oxylabs","Luminati","Netnut","GeoSurf","Stormproxies","Bright Data","DataImpulse","PacketProxy","Rsocks","Socks5","Socks4","HTTP Proxy","SOCKS Proxy","VPN",

            //SEO and monitoring tools
            "AhrefsBot","ahrefs", "SEO","Screaming Frog","ScreamingFrog","SemrushBot","DeepCrawl","Lumar","Sitebulb","Botify","OnCrawl","Crawlit","DeepSpider",
            "Pangseo","SEOkicks","trendiction","Pipl","Tapuz","Majestic","MajesticSEO","majestic","linkChecker","Nutch","Solr","Elasticsearch","Solr","Grub","MRTG","SmokePing","Pingdom","UptimeRobot","StatusCake",

            //Screen scraping tools and automation
            "capture", "collect","extract",'Dataminer',"Screenshot","Snap","Grab","Scrap","scrape","scraper","Harvest","Fetcher","Grabber","ripper","Extractor","WebZIP","WebWhacker","BlackWidow","Bot","Snoopy","W3mir","WebReaper","WebStripper","WebSnatcher",

            //Security+Scanners
            "nikto","nmap","sqlmap","dirbuster","gobuster","acunetix","netsparker","arachni","zap","burp","w3af","skipfish","vega","nessus","openvas","wfuzz","masscan","dirb","gobuster",
            
			//Semrush
            "SemrushBot","semrushbot","SemrushBot/7~bl","SemrushBot/7t","SemrushBot-OCOB","SemrushBot-SWA",

            //Suspicious/spoofed user agents
            "Mozlila","Mozilla/5.0","MSIE","Linux; Android 6.0.1;","SeaMonkey","Iron","Plesk screenshot bot","SEOJuice-SearchBot/1.0","KHTML, like Gecko, Mediapartners-Google",

            //Known Scrapers
            "360Spider","MJ12bot","PetalBot","Bytespider","Baiduspider","baiduspider","DataForSeoBot","DotBot","dotbot","Exabot","BLEXBot","Dataprovider","CensysInspect",
            "InternetMeasurement","IbouBot","NuMON Agent","Nicecrawler","serpstatbot","Sogou","Clawbot","ClawbotLeadScan","TikTokSpider","Website-info","linksnatcher","websitescrawl",
            "Twitterbot/1.0","twitterbot",

            //Python-related patterns
            "python","Python","pyth","pypi","pyscan","py","python-http","httpx","urllib","requests","Text Extraction","python-requests","Python Requests","python\-requests","python requests",
            "python-requests/2.32.3","pythonrequests","PythonRequests","python-opengraph","python-urllib", "python\-urllib","python aiohttp","python-httpx","python-async",

            //Python tools and libraries
            "curl_cffi","photon","photon/1.0","python/3.12 aiohttp","pycurl","PyOpenGraph","python2 snitch.py","urllib3","httpx","Odin",
            "urllib","beautifulsoup","bs4","Request","Rust","R","Ruby","PyScrappy","python-scraper","selenium","Selenium","SeleniumBase",
			"playwright","mechanize","middlewares.py","webdriver","pageobj","lxml","feedparser",

            //Robots - not wanted bots
            "404checker","Apache-HttpClient/4.5.2 (Java/1.8.0_161","AdsBot-Google-Mobile-Apps","AhrefsBot","Ahrefs-Bot","ahrefsbot","AhrefsBot/7.0","Ahrefs-Bot/7.0","AhrefsSiteAudit","*bot.*.ahrefs.com","*bot.*.ahrefs.com","*bot.*.ahrefs.net",
            "*bot.*.ahrefs.net","ai.azure**.com","ai.gemma**.dev","ai.meta**.com","alibabacloud.com","allenai\.org","Anthropic**.com","anthropic\.com","air.ai/scanning ","Amazon","Amazon CloudFront","Amazonbot","Amazon Bedrock AgentCore Browser","Amazon Textract",
            "Amazon Comprehend","Amazon Silk","Amazon Lex","Amazon Q Business","AMAZON-02","Amazon Bedrock","Amazon SageMaker","Amazon: AWS","AWS Trainium","AWS Lambda","amazon**.com","Assetnote","Baiduspider","baiduspider-*-*-*-*","Baiduspider/2.0",".crawl.baidu.com","BLEXBot","bot.*.cn",
            "Chrome Privacy Preserving Prefetch Proxy","BitSightBot/1.0","Bytespider","bytespider-*-*-*-*",".crawl.bytedance.com","*bot.*.cn","BUbiNG","*crawl.*.ru","crawler4j","*.chat.openai.com",
            "CensysInspect","CensysInspect/1.1;","httpclient","copilot.microsoft**.com","content crawler spider","cohere\.ai","Curl","Curl/","curl/8.3.0l","curl/8.7.1","CMS-Checker","cypex.ai/scanning","DataForSeoBot","DomainStatsBot","debug.log","DotBot","dotbot","Extreme Picture Finder","error_log",
            "facebookexternalhit/1.1","fwdproxy-*-*.fbsv.net","gemini.google**.com","Go-http-client","Go-http-client","Go-http-client/1.1","Go-http-client/2.0","GuzzleHttp","HeadlessChrome","HeadlessChrome","HeadlessFirefox","HeadlessEdg","HTTP//1.1","http//1.1","huggingface**.co","InternetMeasurement","IbouBot","Java-http-client",

            //WP Scrapers
			"/api/scrape/","/api/","webscraper","fetch","Fetch","Fetch Url","js-scraper","node-fetch","Nutch","NuMON Agent","RSS Content Importer","RSS scraper","RSS XML","rss-parser",
            "Scraper","Sec-Fetch-","WebScraperBot","WP All Import","WP Scraper","wpscan","XML Scraper",
			
            //Android old versions
            "Android 1","Android 2.","Android 3.","Android 4.","Android 5.","Android 6.","Android 6.0.1","Android 7.","Android 8.","Android 9.","Android 10.","Android 11.",
			"Android 12.","Android 13.","Android 14.","Android 15","Linux; Android","Linux; Android 10","Linux; Android 11","Linux; Android 12","Linux; Android 13",

            //iOS/iPhone old versions
            "iPhone OS 1_","iPhone OS 2_","iPhone OS 3_","iPhone OS 4_","iPhone OS 5_","iPhone OS 6","iPhone OS 7_","iPhone OS 8_","iPhone OS 9_","iPhone OS 10_","iPhone OS 11_",
			"iPhone OS 12_","iPhone OS 13_","iPhone OS 14_","OS 1_","OS 2_","OS 3_","OS 4_","OS 5_","OS 6_","OS 7_","OS 8_","OS 9_","OS 10_","OS 11_","OS 12_","OS 13_","OS 14_",
			"iOS 15_","15.8.7_","iOS 16_",	"iOS 1616.7.15_",	"iOS 17_","17.2_",	"iPhone OS 1","iPhone OS 2","iPhone OS 3","iPhone OS 4","iPhone OS 5","iPhone OS 6","iPhone OS 7","iPhone OS 8","iPhone OS 9","iPhone OS 10",	
            "iPhone OS 11","iPhone OS 12","iPhone OS 13","iPhone OS 14","iPhone OS 15",	"iPhone OS 16",	"iPhone OS 17","iPhone OS 18",		
            
			//Old Macintosh/Mac OS X versions
            "Macintosh; Intel Mac OS X 10_6","Macintosh; Intel Mac OS X 10_7","Macintosh; Intel Mac OS X 10_8","Macintosh; Intel Mac OS X 10_9","Macintosh; Intel Mac OS X 10_10","Macintosh; Intel Mac OS X 10_11","Macintosh; Intel Mac OS X 10_12",
            "Mac OS X 10.6","Mac OS X 10.7","Mac OS X 10.8","Mac OS X 10.9","Mac OS X 10.10","Mac OS X 10.11","Mac OS X 10.12","AppleWebKit/528","AppleWebKit/534","AppleWebKit/535","AppleWebKit/536",

            //Old Windows NT versions
            "Windows NT","Windows NT 3.1","Windows NT 3.1","Windows NT 3.5","Windows NT 3.5 NT ","Windows NT 3.10","Windows NT 3.50","Windows NT 3.51",	"Windows NT 3.51 NT 3",
            "Windows NT 3.10","Windows NT 4.0","Windows NT 4.5","Windows NT 5","Windows NT/5","Windows NT 5.1","Windows NT 5.01","Windows NT 6","Windows NT/6",
            "Windows NT 6.0","Windows NT 6.1","Windows NT 6.1; WOW64","Windows NT 6.1; Win64; x64","Windows NT 6.2","Windows NT 6.3","Windows NT 3.14.0","Windows NT 4.5",                           
            "Windows NT 3.52","windows NT 7.0","windows NT 8.0","windows NT 9.0","Windows NT 3.52",

            //Other suspicious patterns
            "Windows; U; Windows","PhantomJSCloud","Obsidian","Python Selenium","XenWare Pixel Pro","X11","X10","Ubuntu;","laravel","Mozilla/4.0", 

            //Linux browser patterns
            "Linux","Linux x86","Linux i686","Linux i386","Linux x86_64","Linux amd64","Linux arm","Linux armv7","Linux aarch64","Ubuntu","Debian","Fedora","CentOS","Red Hat","openSUSE","Arch Linux","Mint","Gentoo","Slackware",
            "Xubuntu","Kubuntu","Lubuntu","Edubuntu","Xandros","Mandriva","Mageia","PCLinuxOS","Puppy Linux","Tiny Core","Linux; Android 6.0.1","Linux; Android 10; K",

            // More old Windows versions
            "Windows 95","Windows 98","Windows ME","Windows 2000","Windows XP","Windows Vista","Windows 7","Windows 8","Windows 8.1",
            "Windows NT 4","Windows NT 5.0","Windows NT 5.1","Windows NT 5.2","Windows NT 6.0","Windows NT 6.1","Windows NT 6.2","Windows NT 6.3","Win 9x","WinNT","WinCE","Win32","Windows Mobile","Windows Phone",

            //Generic mobile patterns
            "Mobile Safari","Mobile/1","Mobile Safari/1","Mobile Safari/2","Mobile Safari/3","Mobile Safari/4","Mobile Safari/5","Mobile Safari/6",
            "webOS","hpwOS","Symbian","Series60","Series40","MIDP","CLDC","J2ME","BREW","BlackBerry","PlayBook","BB10","RIM Tablet","Nokia","S60","S40","UC Browser","Opera Mini","Opera Mobi",

            //AI-related patterns
            ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$","ai=n",
			
		   // AI BOTS
		   // A LIST 
           "360Spider","360 AI","360AI Search","360 AI Research","360AI browser","Abacus AI Deep Agent","AcademicBotRTU","AddSearchBot","Agent 3","Agent API","Agent GPT","Agent Middleware","AgentGPT","Agentic","Agentic Deep Research","Agentic RAG",
           "Agentic RAG with LangGraph","Agentic RAG with Reasoning","Agentic-RAG","AgentQL","Agent-","Agent-3","Agent-E","AI Agent","AI Agentic RAG Pipeline","AI agents","AI Article Writer",
           "AI Assistant","AI Chat","AI Chatbot","AI Content Detector","AI copilot","AI Crawler","AI Data Scraper","AI Deep Research Agent","AI Detection","AI Dungeon","AI Ghostwriter","AI guardrails","AI Journalist","AI Journalist Agent","AI Legion","AI RAG","AI Scraper","AI-Scraper","AIScraper",
		   "AI Search","AI Search Engine","AI Search Intent","AI SEO Crawler","AI Web","AI Web Scraper","AI-Web-Scraper","ai-web-scraper","AI Website Screenshot","AI Writer","AI – WPBot","AI2","AI2 Bot","AI2Bot","AI2Bot-DeepResearchEval","ai2thor","AI21 Labs","AIBot","aiHitBot",
           "AIMatrix","Airesearch","airesearchbot","air.ai/scanning","AISearch","AISearchBot","AI Training","AITraining","ai-agent-playwright","AI-Content-Detector","AI-Crawler","ai-crawlers-training",
           "ai-proxy","ai-writer","Alexa","AlexaTM","Alice","Alice Yandex","AliGenie","AliyunSec","AliyunSecBot","AllenAI Bot","Alpha AI","AlphaAI","Amazon", 
		   "Amazon-AI","Amazon Athena","Amazon Bedrock","Amazon Bedrock AgentCore Browser","Amazon Comprehent","Amazon Contxbot","Amazon Kendra Web Crawler","Amazon Lex",
           "Amazon Titan","Amazon SageMaker","Amazon Silk","Amazon Textract","amzn.to","Amazonbot","amazonBot","AmazonKnowledgeBasesRetriever","amazon-kendra","Amazon Kendra",
		   "Amelia","Amzn-SearchBot","Amzn-User","AndiBot","Angular","Anomura","Anonymous AI","anonymous AI chatbot","Anthropic","anthropic bot","AnthropicBot","Anthropic Computer Use",
		   "anthropic-ai","Anthropic-Claude","AnyPicker","AnythingLLM","Anyword","Applebot-Extended","Apple-GenAI","arcee-ai/maestro-reasoning","ARC-AGI-2","Aria AI","Aria Browse",
		   "Aria browse Aria AI","Aria browser AI","Articoolo","Ask AI","Ask.py","atlassian-bot","AutoGen","AutoGLM","AutoGLM Rumination","AutoGPT","Auto-GPT","Automated Writer",
		   "AutoML","Autonomous RAG","AutoRAG","AutoScraper","AutoWebGLM","Awario","AwarioRssBot","AwarioSmartBot",	"AWS bedrock","AWS Trainium","Aya Vision","AkiraBot","Azure","Azure AI Search","AzureAI-SearchBot","Azure OpenAI","AzureAISearchRetriever",
           // B LIST
		   "BabyAGI","BabyCatAGI","BAGEL","baiduspider-ai",	"BardBot","Bard-Ai","Basic RAG","Basic RAG Chain","Bedrock","Bedrock Claude","Bedrock claude","bedrockbot","bedrock-chat",	
           "bedrock-chatbot","bedrock-claude-chatbot","Big Sur","Big Sur AI","Big Sur AI Crawler","Bigsur","bigsur.ai",	"BM25 Retriever","Bolt","Botsonic","Brave Leo AI","Bravebot",	
           "BraveGPT","Brightbot","Brightbot 1.0","Bright Data Scraper","Bright Data CLI","Brightbot operator","Browser MCP Agent","Browser Use","Browserbase","BrowserBase Open Operator","BrowserOS","BuddyBot","Bytebot",	
		   "ByteDance","byteDance","ByteDance crawler","ByteDance Lynx","ByteDance LLM","Bytespider",  
		   // C LIST
		   "CarynAI","CatBoost","CCBot","ccbot","CCBot/2.0","CC-Crawlerr","CC-Crawler/2.0","Celia","Ceramic TerraCotta Crawler","Chai","Channel3Bot","Character","Character-AI","Charstar AI",
           "Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGenie","ChatGLM","ChatGLM-Spider","ChatGPT","ChatGPT 3.0","ChatGPT 4o","ChatGPT 4o-mini","ChatGPT 4.1","ChatGPT 4.5",
           "ChatGPT 5","ChatGPT Agent","ChatGPT Atlas","ChatGPT o1","ChatGPT o3-mini","ChatGPT Operator","ChatGPT Retrieval","ChatGPT search","ChatGPT-Browser","ChatGPT-User","ChatGPT-User v2.0",
           "ChatGPT-User/1.0","ChatGPT-User/2.0","ChatGPT-User","chatgpt-user","ChatLLM","ChatOpenAI","Chatsonic","ChatUp AI","ChatUser","CheerioCrawler","Chinchilla","Cici","Clara","Clawbot",
		   "ClawbotLeadScan", "Claude","Claude 3.5","Claude Haiku5","Claude Haiku 4.5","Claude 3.5 Sonnet","Claude 3.7 Sonnet","Claude 4","Claude 5", "Claude Agent","Claude Computer Use","Claude Fable","Claude LLM","Claude Opus","Claude Opus 4",
		   "Claude Opus 4.6","Claude Opus 4.8","Claude Sonnet 4","Claude Sonnet 4.5","Claude Sonnet 5","Claude v1.2","ClaudeBot","ClaudeBot/1.0","ClaudeBot/1.6","claude-4-haiku-thinking","Claude-RAG","Claude-SearchBot","Claude-User","claude-user", "Claude-Web",
           "claude-web/1.0","claude.ai","ClearScope","Clearview","cloudflare-ai-search","ChatGPT Scraper","Cloudflare AutoRAG","Cloudflare-AutoRAG","Cloudflare Browser Rendering","CloudVertexBot","Cognitive AI","Cognitive AI engine","Code","Cohere","Cohere LLM","Cohere RAG",
           "cohere-ai","cohere-ai/1.0","Cohere-Command","cohere-training-data-crawler","Command-A-Reasoning","Common Crawl","CommonCrawl","Compass","content crawler spider","Content Harmony","Content King",
           "Content Optimizer","Content Samurai","Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","Copilot","CopilotBot","CopilotNative","CopilotSapphire",
           "CopyAI","Copymatic","Copyscape","Coveobot","CoreWeave","Corrective RAG","Cotoyogi","CRAB","Crawl4AI","Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crawl web content","Crew AI","CrewAI","Crushon AI","cURL","Cypex","cypex.ai/scanning",	
		   //D LIST
		   "DALL-E","DALL-E 2","Dall-E 4","DALL-E Mini","DALL·E 3","Dalle 4","DarkBARD","DarkBard","DarkBERT","DarkGPT","DataFor","DataForAI","DataForSeoBot","dataminr","Dataprovider\.com","DataProvider","dataprovider",
		   "dataprovider spider","dataproviderbot","Datenbank Crawler","Deep AI","Deep Research","Deep Think 2","DeepAI","DeepL","DeepL Agent","DeepMind","DeepMind Genie 3","DeepResearch","DeepSeek","Deepseek Agent","DeepSeek R1 Chatbot",
           "DeepSeek R1 Y","DeepSeek V3","DeepSeekBot","DeepSeekV2.5-Chat","DeepSeek-LLM","DeepSeek-R1","deepseek-r1-distill-llama-70b","DeepSeek-V3.1","deepseek/deepseek-v3.2-exp","DepolarizingGPT",
           "Devin","devin","Devstral","DiaBrowser","DialoGPT","DialoGPT-medium","Diffbot","diffbot","DigitalOceanGenAICrawler","digitaloceangenai-crawler","DocsGPTOnyx","dolly","Dolma","Dots Chatbot","Doubao AI",
           "Doubao 1.5","DuckAssistBot","duckassistbot","DuckDuckGo Chat","DuckDuckGo LangChain Bot","DuckDuckGo-Enhanced","Duck.ai",
		   //E LIST
		   "Echobot","Echobot Bot","Echobox","EchoboxBot","ElasticsearchRetriever","Elixir","Embed v3","ERNIE","ErnieBot","Evil-GPT","Extended GPT Scraper",
           //F LIST
		   "FAISS","FacebookBot","FacebookBot/1.0","FacebookExternalHit","facebookexternalhit","facebookexternalhit/1.1","Factset","Factset_spyderbot","Falcon","Fastai",
		   "FastGPT","Firebase","Firecrawl","FirecrawlAgent","Fireworks","FIRE-1","FIRE-1 Agent","Finbot","Flux","Flux 2","Flyriver","flyriverbot/1.1","Frase AI","FraudGPT","FriendlyCrawler",
		   //G List
           "AI Ghostwriter","Gato","Gemini","Gemini 3 Pro","Gemini Agentic RAG","Gemini-Ai","Gemini-Deep-Research","Gemini-User","Gemma","Gemma 3","Gen AI","GenAI","GenAI Chat",
           "GenAI RAG","Generative","Genspark","Gentoo-chat","gentoo-chat","gen-ai","GeistHaus-PageFetcher","GhostGPT","Ghostwriter","GigaChat","GLM","GLM 4.6","GLM,","GLM-4.6","GLM-4.6 GGUF","GLM 5",
           "Go","gobrowser","GodMode","Google-Agent","google-agent","Google-Gemini-CLI","Gemini-Deep-Research","Gemini-Vertex","Google Gemini","GoogleAgent URL Context",
		   "GoogleAgent-Mariner","Google-CloudVertexBot","Google-Extended","Google-Firebase","Google-NotebookLM","Goose","GPT 4 Omni","GPT 4 Omni Mini","GPT 5.1","GPT Chat 3",
		   "GPT Image 1.5","GPT OSS","GPT Researcher","GPT Scraper","GPT","GPT-", "GPT4ALL","GPT4Free","GPTBot","GPTBot/1,2","GPTBot/1.2","GPTBot/1.3","GPTZero","GPT-1","GPT-2",
		   "GPT-3","GPT-3.5","GPT-3.5 turbo","GPT-4o","GPT-4o Image","GPT-4o mini","GPT-4V","GPT-4,5","GPT-4.1","GPT-4.1-mini","GPT-4.1-nano","GPT-5","GPT-5 Chat","GPT-5 Mini",
		   "GPT-5 Nano","GPT-5 Thinking mini","GPT-5o","GPT-5-high","GPT-5.1","GPT-5.1 Auto","GPT-5.1 Instant","GPT-5.1 Thinking","GPT-5.2","GPT-5.2 Instant","GPT-5.2 Pro","GPT-5.2 Thinking",
		   "GPT-5.4 Thinking", "GPT-5.4","GPT-5.4 Pro","GPT‑5.4 mini","GPT‑5.4 nano","GPT-5.5", "GPT-crawler","gpt-crawler","GPT Researcher","gpt-image1","GPT OSS","GPT-oss", "GPT-Qwen Deep Research",
		   "GPT-Shield-AI-Plagiarism-Detector","Grafana","Grammarly","Grendizer","Grok","Grok 4 Fast","Grok AI chatbot","Grok DeepSearch","Grok Imagine","Grok-DeepSearch/1.0","GrokAI",
		   "GrokBot","Grok-4","Grok-4 Heavy","grok-4-fast-thinking","Grok 5","Groq","Groq-Bot","GT Bot","GTBot","GTP",
		   // H LIST
           "Hemingway Editor","HttpClient","Headless AI Agent","Hetzner","Hugging","Hugging Face","HuggingChat","huggingfacebot","HuggingFace-Bot","hugging-face-ai","Hunyuan","Hunyuan-7B-Instruct 7B",
           "Hunyuan-Large-Instruct","hybrid LLM","Hybrid Search RAG","HyperAgent","Hyperbrowser","Hypotenuse AI","Haystack RAG Pipeline","Haystack - deepset AI",
		   //I LIST
           "iAsk","iAskBot","iaskspider","iaskspider/2.0","iAskAI-Crawler","IbouBot","IbouBot Crawler","ICC-Crawler","Ideogram","ImageGen","ImageGPT","Imagen","imagen4","ImagesiftBot",
           "ImageSpider","imagespider","img2dataset","imgproxy","inclusionai/ring-1t","Inferkit","INK Editor","INKforall","Instructor","instructor-php","IntelliSeek","IntelliSeek.ai","ips-agent","ISSCyberRiskCrawler",
		   //J LIST
           "Jamba 1.5","Jamba 1.5 Large","Jamba 1.5 Mini","jamba-mini-1.7","Janitor AI","Jasper","JasperAI","Jenni AI","Julius AI",
		   // K LIST
           "Kafkai","Kaggle","Kaggle agent","kagi-fetcher","Kagi AI","Kagi LLM","Kangaroo","Kangaroo Bot","Kangaroo-Bot","KawaiiGPT","Keyword Density AI","Kimi","Kimi Agentic",
           "KimiBot","Kimi Claw","Kimi-SearchBot","Kimi Search","Kimi K2","Kimi-2","Kimi-VL","Kimi-User", "Kingsoft-LLM","KI-Crawler","Klaviyo","KlaviyoAIBot",
		   "Knowledge","KnowledgeAgent","Knowledge Graph","knowledge graph","knowledge-base","Knowledge-graph RAG","KomoBot","Kruti","KunatoCrawler",	   
		   //L LIST
           "LAIONDownloader","LAION-5B","LAION-huggingface-processor","laion-huggingface-processor","LangChain","LangChain Agent","LangChain Python","Langchain raptor","LangChain-Ruby",
           "langchain-google-genai","langchain-openai","langchain-perplexity","LangChain-Ruby","langchain-scrapeless","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
           "langchain-scrapeless","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","LINER Bot","LinerBot","liner-bot",
           "Linguee Bot","Linkup Deep","LinkupBot","LinkupBot/1.0","LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama 3.1","Llama 3.2","Llama 4","Llama3.1-70B-Instruct",
           "Llama3.1-405B-Instruct","LlamaResearchert","LLM Websearch","LLM Pigeon","LLM Proxy","LLM Scraper","LLM-Scraper", "llm-scraper","LLM","LLMFeeder","llms.txt crawler bot",
		   "LLMs","LLM-jp-Crawler","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","LocalAI","Lorph","Lovable",
		   //M LIST
           "Magistral","MAI-DS-R1 ","Magistral Medium","Magnus","magpie-crawler","MAI-Image","MAI-Image-1","MalwareGPT","Manus","Manus Agent","Manus-User","MarketMuse","MBZUAI","MBZUAI Chatbot",
           "Medium","Meltwater","Mem0","Meta Agent","Meta AI","Meta AI Crawler","Meta Llama","Meta search scraper","MetaAI","MetaGPT","MetaTagBot","Meta-AI","Meta-External","Meta-ExternalAgent",
           "meta-externalagent","meta-externalagent/1.1","Meta-ExternalFetcher","meta-externalfetcher","meta-externalfetcher/1.1","Meta-Webindexer","meta-webindexer","Meta-Webindexer 1/1",
           "meta-webindexer/1.1","Meta.AI","Middleware","Midjourney","midjourney","Mini AGI","minimal AGI","MiniMax","Mintlify","Mistral","Mistral NeMo Instruct","Mistral OCR 3","Mistral Perflexity AI",
           "MistralAI-User","MistralAI-User/1.0","mistral-large-3","Mistral Le Chat Agent","mistral-medium","mistral-small","Mistral.ai","Mixtral","Mixtral 8x22B","Mixtral-8x22B-Instruct","MobileLLM-R1","ModatScanner",
           "Model Context Protocol - MCP1","Molmo","Monica","Moonshot","Moshi","Mozilla-Tabstack","Mycroft AI","MyCentralAIScraperBot",
		   //N LIST
           "n8n-nodes-aiscraper","Nano","Nano Banana","Nanobrowser","nanochat","nanobot","nanoclaw","Nano novellum","Nano Search",
		   "Narrative","NeevaBot","newsai","netEstate","netEstate Imprint Crawler","NetShelter ContentScan","Neural Text",
           "NeuralSEO","NextChat","Nicecrawler","NinjaAI","NinjaAIBot/1.0","Ninja - Chatbot AI ","Ninja Deep Research","NodeZero","Node.js","NotebookLM","NotebookLM Deep Research",
           "Notion MCP Agent","Nova","Novellum Search","Nova 2 Lite","Nova 2 Sonic","Nova Act","NovaAct","Nova 2 Lite","Nova Premier 1.0","nova-premier-v1","Nytheon","Nytheon AI","Nutch","nullclaw",
		   //O LIST
           "OAI SearchBot","OAI-SearchBot","OAI-SearchBot/1.0","OAI-SearchBot/1.3","OASIS","OIG","Ola","Olivia","Ollama","oLLM","Olmo Hybrid,OLM","OLMo","OLMo 2 Chatbot","OLMO 3","OLMoASR","OLMoE",
           "Omgili","omgili","Omgilibot","omgilibot","Onyx","Open AI","OpenClaw Agent","OpenClaw","Open Claw browser","Open Deep Research","Open Interpreter","Open Lovable","Open Operator","Open Perflexity","Open Source LLM","OpenAGI",
           "OpenAI","OpenAI Crawler","OpenAI CUA","OpenAI GPTBot","OpenAI Image Downloader","OpenAI o1","OpenAI o1-mini","OpenAI o3","OpenAI o3-mini","OpenAI o4","OpenAI o4-mini","OpenAI Operator",
           "OpenAI Python","openai-python","OpenAIContentCrawler","openai-user","o4 Mini Deep Researc","OpenBot","Openbot","OpenELM","OpenInterpreter","OpenLens AI","OpenLLaMA","OpenLM",
           "OpenPi","openpi","OpenRouter","openrouter","OpenText AI","OpenVLA","open-manus-v2","Operator","Opus 4.5","Outwrite","OVHcloud","OVHcloud AI Training","OWL","Owlin","OxyCopilot",			   
   		   //P LIST
           "Page Analyzer AI","PaLM 2","PandasAI","PanguBot","PanGu Chat","Panscient","panscient.com","PaperLiBot","PaperLiBot/2.1","Paraphraser.io","PentestGPT","PentestGPT Research","peer39_crawler","peer39_crawler/1.0",
           "PerfectChatGPT","Perflexity","Perplexity AI","Perplexity Image","Perplexity Labs","Perplexity LLM ","Perplexity Comet","Perplexity Chatbot","Perplexity Deep Research","Perplexity pypi",
           "Perplexity Research","Perplexity Scraper","Perplexity Search","perplexity-py","Perplexity-Stealth","Perplexity Stealth","PerplexityBot","Perplexity-Bot","PerplexityBot/1.0",
           "PerplexityUser","Perplexity-User","Perplexity-User/1.0","Perplexity Research","Perplexit-User","Perplexity Web Scraper","Petabot","Petal","PetalBot","petalBot","PetalBot mobile",
           "Phind","Phi", "phi-4-multimodal-instruct","phi-4-reasoning-plus","PhindBot","PiplBot","Pixmo","Playwright","Playwright Agentic AI","Playwright Stealth","PlaywrightCrawler","Playwright MCP","Poe",
           "PoeBot","PoeSearchBot","Poggio","Poggio-Citations","PoisonGPT","Poseidon","Poseidon Research Crawler","PrivateGPT","PrivateGPTitingA","ProRataInc","ProWrid","ProWritingAid","Proximic",
           "proximic","PulsarRPA","Puppeteer","Puppeteer","PuppeteerCrawler","Python AI","python Ai","Python lxml","Python Scrapy","PyTorch","PyTorch Lightning","PyTorch Lightning LLM",
   		   //Q LIST
           "Qopywriter","Qopywriter.ai","Qualified","QualifiedBot","Quark","QuillBot","quillbot.com","Querit-SearchBot","QueritBot","Qwen-Agent","Qwen","Qwen 2.5‑VL","Qwen 4","Qwen 4 LLM","Qwen Chat","Qwen-Chat",
           "Qwen Deep Research","Qwen LLM","Qwen2","Qwen2.5 72B","Qwen 2.5‑VL","Qwen3","Qwen 4","qwen:4b","QwenLM","Qwen 4 LLM","Qwen-Agent","Qwen-Chat",
		   //R LIST
           "AI RAG","RAG","RAG Agent","RAG Agent Cohere","RAG with Vercel AI SDK","Reader ","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG Database Routing","RAGFlow", "RAG IS","RAG LLM",
           "RAG Pipeline","RAG Search","RAG with","RAGify Search","RAG-","RAG-","RAG_","RAG-as-a-Service","RAG_VertexAI","RAG_with_search","Raptor","RAPTOR LLM","React Agent","ReAct AI Agent","Reader",
		   "REALM","Reasoning","Redis AI RAG","Reka Flash","Reka Flash 3.1","Replicate","Replicate-Bot","Replit Agent 3","resec.ai","Retriever","RightWingGPT","RobotSpider","RSS/XML Scraper",
		   "Runner H","RunPod","RunPod-Bot","Rytr",			
		   //S LIST
           "SAM 3","Sambanova","SaplingAI","SBIntuitionsBot","Scala","Scira AI","scaleai","Scalenut","scale-crawler","scan.cypex.ai","Scrap","Scraping Browser","ScrapeGraph","ScrapeGraphAI","Scrapegraph-ai","Scrapeless","Scraper","Scraper Bot","ScraperGPT","Scraping Browser","Scraping Agent AI","Scrapy","Scrapy-",
           "scrapy-redis", "Scrapy spider","Scrapy crawlspider","Scrapling","Scrapy-LLM","Scrapy Python","Scrapy Middleware","Scrapy selenium","Scrapy-playwright",
		   "scrapy-playwright","ScriptBook","Search GPT","Search RAG","Search retrieval","SearchChat","SearchGPT","searchatlas","Seedance","Seed","Seekr","SeLLMa","SemrushBot",
           "SemrushBot/7~bl","SemrushBot-OCOB","SemrushBot-SWA","Sentibot","SEO Content Machine","SEO Robot","SEObot","Serper","SerpApiBot/1.0","serverhunterspider",
		   "ShadowGPT","Shap-User","ShapBot","shapbot","Shell GPT","sider.ai","Sidetrade","Sidetrade indexer bot","sigmabrowse","SigmaOS","Simplified AI","Site Crawler MCP","Sitefinity","SiteSucker",
		   "skrape.ai","Skydancer","Skyvern","SlickWrite","SmartBot","SmartScrape","SmartScraperGraph","Sonic","Sonar Pro","Sora","SootiAI","SpamGPT","Spawn agent",
		   "Spawning AI","Spawning-ai","Spider","Spider AI","SpiderCreator","Spider Scraper","Spider-Agent","Spider/2","Spider Middleware","Spin Rewrite","Spinbot","Stability","Stability AI",
           "Stable Diffusion","StableDiffusionBot","Stagehand","STEALTH","Stealth","Step 3","StoryGraph","Sudowrite","SummalyBot","Super Agent","Superagent ","Superagent","SuperAGI","superagi","SuperGrok","Surfer AI","Surfer", "SUSE AI",  
		   //T LIST
           "Taiko","taiko","TavilyBot","TavilySearchAPIRetriever","Tenable Agent","Tencent AI chatbot","Trae","TerraCotta","Terra Cotta","TerraCotta","Text Blaze","TextCortex",
		   "Text-RAG","The Knowledge AI","TheKnowledgeAI","Text Formatter","thehive.ai","Thinkbot","Thinkbot/0.5.8","Thinklab","Thordata","TikTokSpider","tiktokspider","
		   Timpibot","Tinybird","Together","Together AI","Together-Bot","TorChat","Toutiao","Traefik","Tulu","TurnitinBot","TTurnitin","TwinAgent","twinagent",
		   //U LIST
           "U haystack-ai","uAgents","UI-TARS","UseAI", 
		   //V W LIST
           "VaultGemma","VelenPublicWebCrawler","VelenPublicWebCrawler/1.0","Venus Chub AI","VertexAISearchRetriever","Vidnami AI","VimGPT","Vision RAG","vnCallbot","vnFace",
		   "VLM","VNPT SmartBot","VNPT SmartReader","AI – WPBot","ai-writer","AI Web Search","wan","AIWebIndex/2.0", "WARDBot","wardbot","Weaviate","Web 3.0 Navigator","WebChatGPT",
           "WebCrawler-AI","WebExplorer-8B","WebFetch","WebFetch.MCP","Webscrape","Webscrape AI","webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","Web Search Agent","Web-Search-AI",
           "Web Search","Websearch","WebSurfer","WebText","WebVoyager","Webzio","webzio","Webzio-Extended","webzio-extended","Web-Search-AI","WeChat","WeSEE","WHEN:","Whisper",
           "WizardLM","WolfGPT","WordAI","Wordtune","WormGPT","WormGPT V3.0","WPBot","wpbot","Writecream","WriterZen","Writescope","Writesonic","WRTNBot","WRTNBot/1.0","WRTNBot crawler","Wrtn",
           //X Y X LIST
           "xAI","XAIAgent","xAI-Web-Crawler","xAI Grok","xAI-Bot","X-Bot","xAI-SearchBot","xAI-SearchBot/1.0","Xanthorox","Xanthorox AI","xBot","XLNet","XXXGPT","x.AI","xAI-Web-Crawler",
		   "YaK","YaML","Yandex AI","YandexAdditional","YandexAdditionalBot","YandexGPT","YandexLLM","yarchatgpt","YarGPT","YiyanBot","YouBot","YourGPT","you-bot",
		   //Z LIST
           "Zanista","ZanistaBot","Zendesk","Zero","Zero GTP","ZeroCHAT","Zerochat","ZeroGPT","ZeroSearch","ZeroStep","Zhipu","Zhuque AI","Zhuque AI Detector","Zimm","Zoominfo AI Agents",
        ];
         
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
            'curl/7.68.0' => 'cURL Bot (BLOCKED)',
            'OpenAI-GPT/1.0' => 'OpenAI Bot (BLOCKED)',
            'python-requests/2.25.1' => 'Python Requests (BLOCKED)',
            'Googlebot/2.1' => 'Google Bot (ALLOWED)',
            'ChatGPT-User' => 'ChatGPT User (BLOCKED)',
            'Mozilla/5.0 (compatible; bingbot/2.0)' => 'Bing Bot (ALLOWED)',
            'Headless Chrome' => 'Headless Browser (BLOCKED)',
            'facebookexternalhit/1.1' => 'Facebook Bot (BLOCKED - not in allowed list)',
            'Twitterbot/1.0' => 'Twitter Bot (BLOCKED - not in allowed list)'
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);
            
            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }
            
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    private function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }
        
        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if the bot is in the allowed bots list
     */
    private function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
