(function () {
    const blockedAgents = ['bot', 'bot' 'bot', 'bot' 'bot', 'bot' 'bot', 'bot' 'bot', 'bot''bot', 'bot'];

    const userAgent = navigator.userAgent.toLowerCase();

    for (let bot of blockedAgents) {
        if (userAgent.includes(bot)) {
            // Optionally, redirect or show an error message
            document.write("<h1>Access Denied</h1><p>Your user agent is not allowed.</p>");
            // Or redirect: window.location.href = "/access-denied.html";
            break;
        }
    }
})();