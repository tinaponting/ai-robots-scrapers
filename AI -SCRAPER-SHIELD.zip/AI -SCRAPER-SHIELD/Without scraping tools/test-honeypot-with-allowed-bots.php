<?php
/**
 * AI Shield Bot Detection Test
 *
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * FORK OF: https://github.com/common-repository/ai-shield
 * Maintained by: https://teskedsgumman.se
 */

class AI_Shield_Test {

    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;

    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [
           //AI-related patterns
		   ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$","ai=n",
			
		   //AI BOTS
		   //A LIST 
           "360 AI","360 AI Research","360AI browser","360AI Search","360Spider","Abacus AI Deep Agent","AcademicBotRTU","AddSearchBot","Agent-","Agent-3","Agent-E","Agent 3","Agent API","Agent GPT","AgentGPT","Agentic","Agentic-RAG","Agentic Deep Research","Agentic RAG",
           "Agentic RAG with LangGraph","Agentic RAG with Reasoning","Agent Middleware","AgentQL","AgentTimes","AhrefsBot/7.0","ai-agent-playwright","AI-Content-Detector","AI-Crawler","ai-crawlers-training","ai-proxy","AI-Scraper","ai-web-scraper","AI-Web-Scraper","ai-writer",
           "AI2","AI2 Bot","AI2Bot","AI2Bot-DeepResearchEval","ai2thor","AI21 Labs","AI Agent","AI Agentic RAG Pipeline","AI agents","AI Article Writer","AI Assistant","AIBot","AI Chat","AI Chatbot","AI Content Detector","AI copilot","AI Crawler","AI Data Scraper",
           "AI Deep Research Agent","AI Detection","AI Dungeon","AI Ghostwriter","AI guardrails","aiHitBot","AI Journalist","AI Journalist Agent","AI Legion","AIMatrix","air.ai/scanning","AI RAG","Airesearch","airesearchbot","AIScraper","AI Scraper","AISearch","AI Search",
           "AISearchBot","AI Search Engine","AI Search Intent","AI SEO Crawler","AITraining","AI Training","AI Web","AIWebIndex","AI Web Scraper","AI Website Screenshot","AI Writer","AI – WPBot","AkiraBot","Alexa","AlexaTM","Alice","Alice Yandex","AliGenie","AliyunSec",
           "AliyunSecBot","AllenAI Bot","AlphaAI","Alpha AI","Amazon","Amazon-AI","amazon-kendra","amazon-QBusiness","Amazon Athena","Amazon Bedrock","Amazon Bedrock AgentCore Browser","amazonBot","Amazonbot","AmazonBuyForMe","Amazon Comprehend","Amazon Contxbot","Amazon Kendra",
           "Amazon Kendra Web Crawler","AmazonKnowledgeBasesRetriever","Amazon Lex","Amazon SageMaker","Amazon Silk","Amazon Textract","Amazon Titan","Amelia","Amzn-SearchBot","Amzn-User","amzn.to","anchor","AndiBot","Angular","Anomura","Anonymous AI","anonymous AI chatbot",
           "Anthropic","anthropic-ai","Anthropic-Claude","anthropic bot","AnthropicBot","Anthropic Computer Use","AnyPicker","AnyPicker - A.I","AnythingLLM","Anyword","APIC Agent","ApifyBot","ApifyWebsiteContentCrawler","Apple-GenAI","Applebot","Applebot-Extended","Applebot/0.1",
           "Aranet-SearchBot","Aranet-SearchBot/1.0","ARC-AGI-2","arcee-ai/maestro-reasoning","Aria AI","Aria Browse","Aria browse Aria AI","Aria browser AI","Articoolo","Ask.py","Ask AI","atlassian-bot","Atlassian Rovo","atomic-agent","Atomic Agent","Auto-GPT","AutoGen",
           "AutoGLM","AutoGLM Rumination","AutoGPT","Automated Writer","AutoML","Autonomous RAG","AutoRAG","AutoScraper","AutoWebGLM","Awario","AwarioRssBot","AwarioSmartBot","AWS bedrock","AWS Trainium","Aya Vision","Azure","AzureAI-SearchBot","Azure AI Search","AzureAISearchRetriever","Azure OpenAI",

		   //B LIST
		   "BabyAGI","BabyCatAGI","BAGEL","baiduspider-ai","Bard-Ai","BardBot","Basic RAG","Basic RAG Chain","Bedrock","bedrock-chat","bedrock-chatbot","bedrock-claude-chatbot","bedrockbot","Bedrock Claude","Big Sur","Bigsur","bigsur.ai","Big Sur AI","Big Sur AI Crawler","BM25 Retriever",
		   "Bolt","Bonsai","Botsonic","Bravebot","BraveGPT","Brave Leo AI","Brightbot","Brightbot 1.0","Brightbot operator","Bright Data CLI","Bright Data Scraper","Browserbase","BrowserBase Open Operator","Browser MCP Agent","BrowserOS","Browser Use","BuddyBot","Bytebot","ByteDance",
		   "byteDance","ByteDance crawler","ByteDance LLM","ByteDance Lynx","Bytespider",

		   //C LIST
		   "CarynAI","CatBoost","CCBot","ccbot","CC-Crawler","Celia","Ceramic TerraCotta Crawler","Chai","Channel3Bot","Character","Character-AI","Charstar AI","Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGenie","ChatGLM","ChatGLM-Spider","ChatGPT","ChatGPT 4.5","ChatGPT 5",
		   "ChatGPT Agent","ChatGPT Atlas","ChatGPT Operator","ChatGPT Plus","ChatGPT Retrieval","ChatGPT Scraper","ChatGPT search","ChatGPT-Browser","ChatGPT-User","chatgpt-user","ChatLLM","ChatOpenAI","Chatsonic","ChatUp AI","ChatUser","CheerioCrawler","Chinchilla","Cici","Clara",
		   "Claude","Claude 5","Claude Agent","Claude Computer Use","Claude Fable","Claude Haiku","Claude LLM","Claude Opus","Claude Sonnet","ClaudeBot","Claude-Code","Claude-RAG","Claude-SearchBot","claude-searchbot","Claude-User","claude-user","claude.ai","Clawbot","ClawbotLeadScan",
		   "ClearScope","Clearview","Cloudflare AutoRAG","Cloudflare Browser Rendering","cloudflare-ai-search","Cloudflare-AutoRAG","CloudVertexBot","Code","Cognitive AI","Cognitive AI engine","Cohere","Cohere LLM","Cohere RAG","cohere-ai","Cohere-Command","cohere-training-data-crawler",
		   "Command-A-Reasoning","Common Crawl","CommonCrawl","Compass","content crawler spider","Content Harmony","Content King","Content Optimizer","Content Samurai","Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","Copilot","Copilot Read Aloud",
		   "CopilotBot","CopilotNative","CopilotSapphire","CopyAI","Copymatic","Copyscape","copy.ai","CoreWeave","Corrective RAG","Cotoyogi","Coveobot","CRAB","CragCrawler","Crawl web content","Crawl4AI","Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crew AI","CrewAI","Crushon AI",
		   "cURL","Cursor","Cypex","cypex.ai/scanning",
		   
		   //D LIST
		   "DALL-E","Dall-E 4","DALL·E 3","Dalle 4 ","DarkBARD","DarkBard","DarkBERT","DarkGPT","DataFor","DataForAI","DataForSeoBot","dataminr","DataProvider","dataprovider","dataprovider spider","dataproviderbot","Datenbank Crawler","Deep AI","Deep Research","Deep Think 2","DeepAI",
		   "DeepL","DeepL Agent","DeepMind","DeepResearch","DeepSeek","Deepseek Agent","DeepSeekBot/1.0","DeepSeekBot","DeepSeek V2.5","DeepSeekV2.5-Chat","DeepSeek-LLM","DeepSeek-R1","deepseek-r1-distill-llama","DeepSeek-V3.1","deepseek/deepseek-v3.2-exp","DepolarizingGPT","Devin",
		   "devin","Devstral","DiaBrowser","DialoGPT","DialoGPT-medium","Diffbot","diffbot","DigitalOceanGenAICrawler","digitaloceangenai-crawler","DocsGPTOnyx","dolly","Dolma","Dots Chatbot","Doubao AI","Doubao 1.5","DuckAssistBot","duckassistbot","DuckDuckGo Chat","DuckDuckGo LangChain Bot","DuckDuckGo-Enhanced",

		   //E LIST
		   "Echobot","Echobot Bot","ExaSearchBot","Echobox","EchoboxBot","ElasticsearchRetriever","Elixir","Embed ","embed-v4.0","ERNIE",  "ErnieBot","Evil-GPT","Extended GPT Scraper","ExaBot",

		   //F LIST
		   "Fastai","FastGPT","Firebase","Firecrawl","FirecrawlAgent","Fireworks","FIRE-1","FIRE-1 Agent","Finbot","Flux","Flux 2","Flyriver","flyriverbot/1.1","Frase AI","FraudGPT","FriendlyCrawler",

		   //G List
		   "Gato","Gemini","Gemini Agentic RAG","Gemini-Ai","Gemini-Deep-Research","Gemini-User","Gemini URL Context","Gemma","Gen AI","GenAI","gen-ai","GeistHaus-PageFetcher","GenAI Chat","GenAI RAG",
		   "Generative","Genspark","Gentoo-chat","gentoo-chat","GhostGPT","Ghostwriter","GigaChat","GLM","GLM,","GLM-","GLM 4.6","GLM 5","Go","gobrowser","GodMode","Google-Agent","google-agent",
		   "Google-Gemini-CLI","Google Gemini","Gemini-Deep-Research","Gemini-Vertex","GoogleAgent URL Context","GoogleAgent-URLContext","GoogleAgent-Mariner","Google-CloudVertexBot","Google-Extended",
		   "Google-Firebase","Google-NotebookLM","Goose","GPT 4 Omni","GPT 4 Omni Mini","GPT 5.1","GPT Chat", "GPT Image", "gpt-image","GPT OSS","GPT-oss","GPT Researcher","GPT Scraper","GP","GPT-",
		   "GPT4ALL","GPT4Free","GPTBot","GPTBot/1.2","GPTBot/1.3","GPTZero","GPT-","GPT-5","GPT-5 Chat","GPT-5 Mini","GPT-5 Nano","GPT-5 Thinking mini","GPT-5.5","GPT Researcher","GPT-crawler",
		   "gpt-crawler","GPT-Qwen Deep Research","GPT-Shield-AI-Plagiarism-Detector","Grafana","Grammarly","Grendizer","Grok","Grok 4 Fast","Grok AI chatbot","Grok DeepSearch","Grok-DeepSearch/","Grok Imagine",
		   "GrokAI","GrokBot","Grok-","Grok 5","Groq","Groq-Bot","GT Bot","GTBot","GTP","GraphQL",
 
		   ///H LIST
		   "hada.news","Haystack - deepset AI","Haystack RAG Pipeline","Headless AI","Headless AI Agent","Hemingway Editor","HenkBot","HenkBot/Valyu AI","Hermes Agent","Hetzner","HttpClient","Hugging",
		   "hugging-face-ai","HuggingChat","Hugging Face","HuggingFace-Bot","huggingfacebot","Hunyuan","HunyuanBot","Hunyuan-7B-Instruct", "Hunyuan-Large-Instruct","hybrid LLM","Hybrid Search RAG","HyperAgent","Hyperbrowser","Hypotenuse AI",

		   //I LIST
		   "iAsk","iAskAI-Crawler","iAskBot","iaskspider","iaskspider/2.0","IbouBot","ICC-Crawler","Ideogram","ImageGen","ImageGPT","Imagen","ImagesiftBot","imagespider","ImageSpider","img2dataset",
		   "imgproxy","inclusionai","Inferkit","INK Editor","INKforall","Instructor","instructor-php","IntelliSeek","IntelliSeek.ai","ips-agent","ISSCyberRiskCrawler",
	   	   
		   //J LIST
		   "Jamba","Janitor AI","JasperAI","JenkersBot","Jenni AI","Julius AI","June",
   
		   //K LIST
		   "LAION-","laion-huggingface-processor","LAION-huggingface-processor","LAIONDownloader","LangChain","langchain-google-genai","langchain-ollama","langchain-openai","langchain-perplexity",
		   "LangChain-Ruby","langchain-scrapeless","LangChain Agent","LangChain Python","Langchain raptor","langchain_ollama","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
		   "LangSmith","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","liner-bot","LinerBot","LINER Bot","Linguee Bot","LinkupBot","Linkup Deep",
		   "LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama3.1-70B-Instruct","Llama3.1-405B-Instruct","LlamaResearcher","LLM","LLM-jp-Crawler","LLM-Scraper","llm-scraper",
		   "llm-scraper","LLMFeeder","LLM Pigeon","LLM Proxy","LLMs","llms.txt crawler bot","LLM Scraper","LLM Websearch","LocalAI","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","Lorph","Lovable",

		   //L LIST
           "LAIONDownloader","LAION-5B","LAION-huggingface-processor","laion-huggingface-processor","LangChain","LangChain Agent","LangChain Python","Langchain raptor","LangChain-Ruby",
           "langchain-google-genai","langchain-openai","langchain-perplexity","LangChain-Ruby","langchain-scrapeless","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
           "langchain-scrapeless","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","LINER Bot","LinerBot","liner-bot",
           "Linguee Bot","Linkup Deep","LinkupBot","LinkupBot/1.0","LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama 3.1","Llama 3.2","Llama 4","Llama3.1-70B-Instruct",
           "Llama3.1-405B-Instruct","LlamaResearchert","LLM Websearch","LLM Pigeon","LLM Proxy","LLM Scraper","LLM-Scraper", "llm-scraper","LLM","LLMFeeder","llms.txt crawler bot",
		   "LLMs","LLM-jp-Crawler","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","LocalAI","Lorph","Lovable",
		   
		   //M LIST
		   "Magistral","Magistral Medium","Magnus","magpie-crawler","MAI-DS-R1","MAI-Image","MalwareGPT","Manus","Manus-User","Manus Agent","MarketMuse","MBZUAI","MBZUAI Chatbot","MCP",
		   "Medium","Meltwater","Mem0","Meta-AI","Meta-External","Meta-ExternalAgent","meta-externalagent","Meta-ExternalFetcher","meta-externalfetcher","Meta-Webindexer","meta-webindexer",
		   "Meta.AI","Meta Agent","Meta AI","MetaAI","Meta AI Crawler","MetaGPT","Meta Llama","Meta search scraper","MetaTagBot","Middleware","Midjourney","midjourney","Mini AGI","minimal AGI",
		   "MiniMax","MiniMax-Agent","Mintlify","Mistral","mistral-large","mistral-medium","mistral-small","Mistral.ai","MistralAI-User","MistralAI-Training","Mistral Le Chat Agent",
		   "Mistral NeMo Instruct","Mistral OCR","Mistral Perflexity AI","Mixtral","Mixtral-8x22B-Instruct","Mixtral 8x22B","MobileLLM-R1","ModatScanner","Model Context Protocol - MCP",
		   "Molmo","Monica","Moonshot","Moshi","Mozilla-Tabstack","Muse","MyCentralAIScraperBot","Mycroft AI",

		   //N LIST
		   "n8n-nodes-aiscraper","NagetBot","Nano","Nano novellum","Nano Search","nanobot","Nanobrowser","nanochat","nanoclaw","Narrative","Nbot","NeevaBot","netEstate","netEstate Imprint Crawler",
		   "NetShelter ContentScan","Neural Text","NeuralSEO","newsai","NextChat","Nicecrawler","Ninja Deep Research","Ninja - Chatbot AI","NinjaAI","NinjaAIBot","NodeZero","Node.js","NotebookLM",
		   "NotebookLM Deep Research","Notion MCP Agent","Nova","Nova 2 Lite","Nova 2 Sonic","Nova Act","Nova Premier","NovaAct","nova-premier-","Novellum Search","nullclaw","Nutch","Nytheon","Nytheon AI",

		   //O LIST
		   "OAI SearchBot","OAI-SearchBot/1.0","OAI-SearchBot/1.3","OASIS","OIG","Ola","Olivia","Ollama","oLLM","OLM","OLMo","OLMo 2 Chatbot","Olmo Hybrid","OLMoASR","OLMoE","Omgili","omgili",
		   "Omgilibot","omgilibot","Onyx","Open AI","Open Claw browser","Open Deep Research","Open Interpreter","Open Lovable","Open Operator","Open Perflexity","Open Source LLM","OpenAGI","OpenAI",
		   "OpenAI Crawler","OpenAI CUA","OpenAI GPTBot","OpenAI Image Downloader","OpenAI Operator","OpenAI Python","OpenAIContentCrawler","openai-python","openai-user","OpenBot","Openbot",
		   "OpenClaw","OpenClaw Agent","opencode","OpenELM","OpenInterpreter","OpenLens AI","OpenLLaMA","OpenLM","OpenPi","openpi","OpenRouter","openrouter","OpenText AI","OpenVLA","Operator","Opus","Outwrite","OVHcloud","OVHcloud AI Training","OWL","Owlin","OxyCopilot",

           //P LIST
		   "Page Analyzer AI","PandasAI","PanGu Chat","PanguBot","Panscient","panscient.com","Paraphraser.io","PentestGPT","PentestGPT Research","Perflexity","Perplexity AI","Perplexity Chatbot",
		   "Perplexity Deep Research","Perplexity Image","Perplexity LLM","Perplexity pypi","Perplexity Research","Perplexity Scraper","Perplexity Search","Perplexity Stealth","Perplexity Web Scraper",
		   "PerplexityBot","Perplexity-Bot","perplexity-py","Perplexity-Stealth","Perplexity-User","PetalBot","petalBot","Phind","PhindBot","phi-4-multimodal-instruct","phi-4-reasoning-plus","Playwright",
		   "Playwright Agentic AI","Playwright MCP","Playwright Stealth","PlaywrightCrawler","Poe","PoeBot","PoeSearchBot","Poggio","Poseidon","Poseidon Research Crawler","ProWrid","ProWritingAid",
		   "Proximic","proximic","PulsarRPA","Puppeteer","Python AI","python Ai","Python lxml","Python Scrapy","PyTorch","PyTorch Lightning","PyTorch Lightning LLM",

   		   //Q LIST
		   "Qopywriter","Qopywriter.ai","Qualified","QualifiedBot","Quark","QueritBot","Querit-SearchBot","QuillBot","quillbot.com","Qwen","Qwen Chat","Qwen Deep Research","Qwen LLM","QwenLM","Qwen-Agent","Qwen-Chat",

		   //R LIST
		   "AI RAG","RAG","RAG Agent","RAG Agent Cohere","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG Database Routing","RAG IS","RAG LLM","RAG Pipeline","RAG Search","RAG with",
		   "RAG with Vercel AI SDK","RAGify Search","RAG-","RAG-as-a-Service","RAG-","RAG_","RAG_VertexAI","RAG_with_search","RAPTOR LLM","React Agent","ReAct AI Agent","Redis AI RAG","Reka Flash",
		   "Replicate","Replicate-Bot","resec.ai","Retriever","RSS/XML Scraper","Runner H","Rytr",

		   //S LIST
		   "Sambanova","SaplingAI","SBIntuitionsBot","Scala","scaleai","ScrapeGraph","ScrapeGraphAI","Scrapegraph-ai","Scrapegraph","Scrapeless","Scraper","Scraper Bot","Scraping Browser","Scrapling",
		   "Scrapy","Scrapy spider","scrapy-redis","Scrapy crawlspider","Scrapy Middleware","Scrapy Python","Scrapy selenium","Scrapy-LLM","scrapy-playwright","Search RAG","Search retrieval","SearchChat",
		   "Seekr","SEO Content Machine","Serper","SerpApiBot","Sitefinity","SiteSucker", "skrape.ai","Skyvern","SmartScrape","SmartScraperGraph","Spawning AI","Spawning-ai","Spider","Spider Middleware",
		   "Spin Rewrite","Spinbot","Stability","Stable Diffusion","Super Agent","Superagent","ScryBot",

		   //T LIST
           "TaraGroup Intelligent Bot","TavilyBot","TavilySearchAPIRetriever","Tencent AI chatbot","Terra Cotta","TerraCotta","Text Formatter","TextCortex","Text-RAG","The Knowledge AI","thehive.ai",
           "TheKnowledgeAI","Thinkbot","Thinklab","Thordata","TikTokSpider","Timpibot","Together","Together AI","Together-Bot","TongyiBot","Trae","Tulu","Turnitin","TurnitinBot",

           //U LIST
           "uAgents","UseAI","haystack-ai", 

		   //V LIST
           "VaultGemma","VelenPublicWebCrawler","Venus Chub AI","VertexAISearchRetriever","Vidnami AI","VimGPT","Vision RAG","VLM","vnCallbot","vnFace","VNPT AI","VNPT AI Assistant","VNPT SmartBot","VNPT SmartReader",

           //W LIST
           "AI Web Search","AI – WPBot","AIWebIndex","ai-writer","wan","Weaviate","Web 3.0 Navigator","Web Browser Bot","Web Search","Web Search Agent","WebChatGPT","WebCrawler-AI","WebExplorer-8B",
           "WebFetch","WebFetch.MCP","Webscrape","Webscrape AI","webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","Websearch","WebSurfer","WebText","WebVoyager","Webzio","Webzio-Extended",
           "Web-Search-AI","WeSEE","Whisper","WizardLM","WolfGPT","WordAI","Wordtune","WormGPT","WPBot","wpbot","Writecream","WRITER Agent","WriterZen","Writescope","Wrtn","WRTNBot","WRTNBot crawler",

           //X Y  LIST
           "XAIAgent","xAI-SearchBot","xAI-Web-Crawler","xBot","YaK","YiyanBot","YouBot",

		   //Z LIST
           "ZanistaBot","Zero","Zero GTP","ZeroCHAT","Zerochat","ZeroGPT","ZeroSearch","ZeroStep","Zhipu","Zhuque AI","Zhuque AI Detector","Zimm","Zoominfo AI Agents",
        ];
       
        // Initialize allowed bots list (legitimate search engines and crawlers)
        $this->allowed_bots = [
    ];
    // Bots to ALLOW (legitimate search engines and browsers)
    private $allowed_bots = [
            'AdsBot-Google','Android OS','AOL Search','AOL','AdIdxBot','APIs-Google','Applebot','AppleNewsBot','apple-app-site-association','archive.org_bot','Avant',
			'BingPreview','Bing Preview bot','Bingbot','bingbot','bingbot/2.0','bing','BingVideoPreview','BraveBot','Brave',
            'Chrome','coccocbot-image','coccocbot-web','coccocbot-web/1.0','CocCocBot','CocCoc','CriOS',
            'Dogpile','Dolphin Browser','Dolphin Browse','DuckDuckBot','DuckDuckGo-Favicons-Bot','DuckDuckGo','DuplexWeb-Google',
            'EcosiaBot','Ecosia','Edge','Edg','Exabot',
            'Feedfetcher-Google','Firefox','FxiOS',
            'GibiruBot','Google Favicon','AdsBot-Google-Mobile','google page speed','Google Read Aloud','Googlebot/2.1','Google Site Verifier','Googlebot Smartphone','Google-Safety',
            'Google API', 'Googlebot-Image','Googlebot-Image/1.0','Googlebot-Mobile','Googlebot-News','Googlebot-Video','Googlebot-Video/1.0','GoogleOther','GoogleOther-Image/1.0',
            'Googlebot','Googlebot/2.1','GoogleProducer','Google-InspectionTool','Google-InspectionTool/1.0','Google-Mobile-Apps','Google-Safetys','Google-Site-Verification/1.0','Google Web Preview',
            'ia_archiver','IceCat','Iceweasel','Info.com','Instagram','Konqueror',
            'Lighthouse','LinkedInApp','LinkedInBot','linkedinbot','LookseekBot','Lycos', 
            'Mastodon','Maxthon','Mediapartners-Google','Mediapartners-Google/2.1','MeiliBot','MetaBot','Microsoft Previewt','MetaCrawler','MetaGer','Mi Browser','Midori','MojeekBot','MS Search',
            'msnbot-media','MSNBot-NewsBlogs','msnbot','Nimbostratus',
            'Opera','OPR','OscoboBot',
            'PageSpeed','PeekBot','Pinterest','PresearbotBot',
            'QQBrowser','QwantBot','Qwantify','Qwant',
            'Safari','SamsungBrowser','Seamonkey','Search Encrypt','SeznamBot','SeznamBot/4.0','SphinxBot','StartpageBot','StartPage','SwiftBot','Swisscows',
            'TumblrBot','UCBrowser','Vivaldi','WebCrawler','WebwikiBot',
            'WolfBot','YaBrowser','YacyBot','YaDirectFetchery','YaDirectFetcher','Yahoo! Slurp','yahoo-blogs','yahoo-blogs/v3.9','Yandexbot','Yandex','Yeti-Mobile','Yeti','Yeti/1.1',
			// Social link previewers (these appear in the headless_allowlist too)
            'LinkedInBot','Slackbot','Discordbot','TelegramBot','WhatsApp','Slack-LinkPreview','TeamsBot','SkypeUriPreview','iMessageBot','Pinterest','TumblrBot','Mastodon','Instagram','Line','Viber','WeChat',
			// Pinger 
            'UptimeRobot','Pingdom','StatusCake','GTmetrix','Site24x7','Catchpoint','DatadogSynthetics','NewRelicPinger',
			// DK
            'OverskriftBot/1.0',
        ];
        
        // Initialize dummy content templates
        $this->dummy_content_templates = [
         
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
           'bingbot/2.0'=> 'Bingbot (ALLOWED)',
           'Googlebot/2.1' => 'Google Bot (ALLOWED)',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
           'curl/7.68.0' => 'cURL Bot (BLOCKED)',
           'OpenAI-GPT/1.0' => 'OpenAI Bot (BLOCKED)',
           'NuMON Agent/1.1'=> 'NuMON Agent/1.1 (BLOCKED)',
           'python-requests/2.25.1' => 'Python Requests (BLOCKED)',
           'ChatGPT-User' => 'ChatGPT User (BLOCKED)',
           'Headless' => 'Headless Browser (BLOCKED)',
           'ChatGPT-User'=> 'ChatGPT-User (BLOCKED)',
           'Headless Chrome'=> 'Headless Chrome (BLOCKED)',
           'facebookexternalhit/1.1'=> 'Facebook (BLOCKED)',
           'Twitterbot/1.0' => 'Twitter Bot (BLOCKED)'
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);
            
            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }
            
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    public function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }
        
        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, strtolower($pattern)) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if the bot is in the allowed bots list
     */
    public function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }

    /**
     * Block the current request by sending a 403 Forbidden header
     * and terminating script execution.
     *
     * Use this at the very top of a request handler — BEFORE any
     * echo / HTML output — to safely send the header.
     */
    public function block_bot() {
        if (!headers_sent()) {
            header('HTTP/1.0 403 Forbidden');
        }
        exit;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// --- Real-world request guard -------------------------------------------
// If this script is hit by a bot in the wild, block it BEFORE any output
// is produced so the 403 header is sent cleanly. The test harness below
// (echo'ing HTML) only runs for humans / whitelisted crawlers.
$guard = new AI_Shield_Test();
$guard_ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
if ($guard_ua !== '' && $guard->is_bot_request($guard_ua)) {
    $guard->block_bot();
}
// -----------------------------------------------------------------------

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
