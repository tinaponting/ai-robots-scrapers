<?php
/**
 * AI Shield Bot Detection Test
 *
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 * FORK OF: https://github.com/common-repository/ai-shield
 * Maintained by: https://teskedsgumman.se
 */

class AI_Shield_Test {

    private $bot_user_agents;
    private $allowed_bots;
    private $dummy_content_templates;

    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [
 		   //Cloud/SaaS scraping services Updated 260831
		   "Cloudflare","CF-RAY","Akamai","Fastly","CloudFront","Incapsula","Sucuri","DDOS-GUARD","Qrator","Project Shield","Google Shield","axios","got","bent","Bright Data","Luminati",
           "Oxylabs","Decodo","Smartproxy","NetNut","IPRoyal","ZenRows","ScrapFly","ScraperAPI","ScrapingBee","ScraperAPI","Crawlera","Proxy","ProxyCrawl","Zyte","Smartproxy","Oxylabs","Luminati",
		   "Netnut","GeoSurf","Stormproxies","Bright Data","DataImpulse","PacketProxy","Rsocks","Socks5","Socks4","HTTP Proxy","SOCKS Proxy","VPN",
		   
		   //General bot patterns  Updated 260831
           "cURL","curl","JavaScript","wget","Wget","fetch","download","sync",

		   //FALSE: Gecko UPDATED: 260825
           "gecko-traill","Gecko/1.0.","Gecko/1.5.0","Gecko/1.8.1","Gecko/1.9.2","Gecko/2.0","Gecko/5.0","Gecko/10.0","Gecko/27.6.7","Gecko/30.0","Gecko/41.0","Gecko/41.0l","Gecko/56.5.9","Gecko/57.0","Gecko/70.0",
           "Gecko/94.0.9","Gecko/100.0","Gecko/115.0","Gecko/128.0","Gecko/136.","Gecko/136.l","Gecko/2013040","Gecko/20050915","Gecko/20050915l","Gecko/20091102","Gecko/20091102","Gecko/20091102l","Gecko/20100101","Gecko/20100101l","Gecko/20130331","Gecko/20130331l",

		   //Headless and scraping tools
		   "elastic","masscan","nmap","nikto","sqlmap","dirbuster","gobuster","wfuzz","phpunit","puppeteer","HttpClient","scraper","java","Jetty","okhttp",
           "HeadlessChromium","HeadlessFirefox","headful","HeadlessEdge","Data Miner","scan","scanner","attack","vuln","exploit","datado","splunk","newrelic",
		   
		   //HTTP libraries and clients   
		   "LS-Client", "i Go","Curl-impersonate", "Apache-HttpClient","Bulk Extract","Extract","Extract HTML","HttpClient","Jakarta Commons-HttpClient","libwww-perl","LWP::Simple","Net::HTTP","HTTP::Lite","HTTP::Tiny","LWP","Mechanize",
		   "WWW::Mechanize","Mojo::UserAgent","HTTPx::Client","REST::Client","HTTPC::Client","Node.js","js-scraper","node-fetch","undici",
		   
		   //Headless browsers and automation
		   "HeadlessEdg","Headless","HeadlessChrome","Lightpanda","Zombie","SlimerJS","CasperJS","phantom","PhantomJS","Splash","HtmlUnit","TrifleJS","Envjs","J浏览器","Liebao",
		   "Maxthon","Maxthon Nitro","Comodo Dragon","CoolNovo","RockMelt","Flock","Camino","Chimera","K-Meleon","Midori","QupZilla","Vimb","Luakit","Dillo","ELinks","Links","NetSurf","surf","Uzbl","W3m",

		   //Generic mobile patterns Updated 260716
		   "Lynx","K-Meleon","Linux; Android 11; Pixel","UC Browser","Opera Mini","Opera Mobi","Mobile Safari","Mobile/1","Mobile Safari/1","Mobile Safari/2","Mobile Safari/3",
		   "Mobile Safari/4","Mobile Safari/5","Mobile Safari/6","Mobile Safari/7","webOS","hpwOS","Symbian","Series60","Series40","MIDP","CLDC","J2ME","GrapheneOS","BREW","BlackBerry","PlayBook","BB10","RIM Tablet","Nokia","S60","S40",
		   
		   //Misc Scrapers Updated 260825
		   "Brave Chrome/","Apple Safari","cms-checker","GuzzleHttp/7","assetnote","Iron","SeaMonkey","XenWare","Obsidian","Odin","ORT","CriOS",

		   //SCRAPY Updated 260825
           "beautifulsoup","CrawlSpider","CSVFeedSpider","CrawlSpider","Scrapy crawlspider","scrapy-djangoitem","scrapy-proxies","SitemapSpider","scrapy-splash","scrapy php","scrapy.Spider","XMLFeedSpider","Scrapy spider","Scrapy Python",
		   "Python Scrapy","pythonl","Scrapy-r","scrapy-redis","scraper","scrapy","Scrapy JavaScript","scrapyd","Spider Middleware","Scrapy selenium","scrapy-selenium","Scrapy shell","Scrapy Splash","ScraPy Spider","Scrapy - Shell","Python Scrapy","scrapy-playwright",

		   //Screen scraping tools and automation
           "capture", "collect","extract",'Dataminer',"Screenshot","Plesk screenshot bot","Snap","Grab","Scrap","scrape","scraper","Harvest","Fetcher","Grabber","ripper","Extractor","WebZIP","WebWhacker","BlackWidow","Bot","Snoopy","W3mir","WebReaper","WebStripper","WebSnatcher",

		   //Semrush
		   "SemrushBot","semrushbot","SemrushBot/7~bl","SemrushBot/7t","SemrushBot-OCOBt","SemrushBot-SWAt",
		   
		   //Known Scrapers        
           "httpx","MJ12bot","PetalBot","Bytespider","Baiduspider","baiduspider","DataForSeoBot","DotBot","dotbot","Exabot","BLEXBot","Dataprovider","InternetMeasurement",
		   "IbouBot","Laravel/PHP","NuMON Agent","Nicecrawler","serpstatbot","Sogou","Sogou web spider","Sogou web spider/4.0","spider","Clawbot","ClawbotLeadScan","TikTokSpider","Website-info","linksnatcher","websitescrawl",

           //Python-related patterns
           "Crawler Python","python","Python","pyth","pypi","pyscan","py","python-http","httpx","urllib","requests","Text Extraction","python-requests","Python Requests","python\-requests","python requests",
		   "python-requests/2.32.3","pythonrequests","PythonRequests","python-opengraph","python-urllib","PySpider","python\-urllib","python aiohttp","python-httpx","python-async",

		   //Python tools and libraries Updated 26031
		   "curl_cffi","photon","photon/1.0","python/3.12 aiohttp","pycurl","PyOpenGraph","python2 snitch.py","urllib3","httpx","Odin","urllib","beautifulsoup","bs4","Request",
		   "Rust","R","Ruby","PyScrappy","python-scraper","pytest","Pyspider","MechanicalSoup","selenium","Selenium","SeleniumBase","mechanize","middlewares.py","webdriver","pageobj","lxml","feedparser",	   
	   
		   //Robots - not wanted bots Updated 2608230
		   "404checker","Apache-HttpClient","httpclient", "AhrefsBot","Ahrefs-Bot","ahrefsbot","AhrefsBot/7.0","Ahrefs-Bot/7.0","AhrefsSiteAudit","*bot.*.ahrefs.com","*bot.*.ahrefs.com","*bot.*.ahrefs.net",
		   "*bot.*.ahrefs.net","Amazon","Baiduspider","Baiduspider/2.0","BLEXBot","BUbiNG","crawler4j","CensysInspect","CensysInspect/1.1;","copilot.microsoft**.com","content crawler spider","cURL","Curl","DomainStatsBot","Extreme Picture Finder",         
		   "Go-http-client/","Go-http-client","Go-http-client/1.1","Go-http-client/2.0","GuzzleHttp","Java-http-client",
		 
		   //Not wanted Browsers and stuff not wanted Updated 260903
		   "AntBrowser","Avast","Agency","Chromium","CCleaner,CentOS","CrOS","Debian","Django","IE","FreeBSD","GhostBSD","Iron","Redis", "Kali Linux","kinza.jp","OpenBSD","SeaMonkey","MSIE","SputnikBrowser","Linken Sphere","Tor Browser","MSIE","NetBSD","Quark",
		    
		   //WP Scrapers Updated 260731
		   "/api/scrape/","/api/","Puppeteer - Chromium","Fortress","Selenium Chromedriver","undetected_chromedriver","headlessbot","Headless Bot","fetch","Fetch","Fetch Url","js-scraper","Node.js","Node.js Crawler","node-fetch","Nutch","NuMON Agent","RSS Content Importer",
		   "RSS scraper","RSS XML","rss-parser","Scraper","JavaScript","TypeScript","playwright(-chromium|(-webkit)","Playwright","json","Sec-Fetch-","WebScraperBot","WP All Import","WP Scraper","wpscan","XML Scraper",

		   //Other suspicious patterns Updated 260716
		   "ozilla/5.0","Mozlila","Mozilla/6.0","Mozilla/7.0","Mozlila/5.0","Mozilla/5.077692140", "Mozilla/5.081397758","Playwright crawler","WOW64","X10;","X11;","X10; U;","X11; U;","XPath","Ubuntu Linux Chrome",
		   "PhantomJSCloud","Obsidian","Python Selenium","XenWare Pixel Pro","X11","X10","Ubuntu;","x11; fedora","x11; linux","x11; linux","x11; ubuntu","laravel","Mozila/","Kali Linux NetHunter","Kali Linux", "Kali-Linux",
		   
           //AI-related patterns
		   ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$","ai=n",
			
		   //AI BOTS
		   //A LIST 
           "360 AI","360 AI Research","360AI browser","360AI Search","360Spider","Abacus AI Deep Agent","AcademicBotRTU","AddSearchBot","Agent-","Agent-3","Agent-E","Agent 3","Agent API","Agent GPT","AgentGPT","Agentic","Agentic-RAG","Agentic Deep Research","Agentic RAG",
           "Agentic RAG with LangGraph","Agentic RAG with Reasoning","Agent Middleware","AgentQL","AgentTimes","AhrefsBot/7.0","ai-agent-playwright","AI-Content-Detector","AI-Crawler","ai-crawlers-training","ai-proxy","AI-Scraper","ai-web-scraper","AI-Web-Scraper","ai-writer",
           "AI2","AI2 Bot","AI2Bot","AI2Bot-DeepResearchEval","ai2thor","AI21 Labs","AI Agent","AI Agentic RAG Pipeline","AI agents","AI Article Writer","AI Assistant","AIBot","AI Chat","AI Chatbot","AI Content Detector","AI copilot","AI Crawler","AI Data Scraper",
           "AI Deep Research Agent","AI Detection","AI Dungeon","AI Ghostwriter","AI guardrails","aiHitBot","AI Journalist","AI Journalist Agent","AI Legion","AIMatrix","air.ai/scanning","AI RAG","Airesearch","airesearchbot","AIScraper","AI Scraper","AISearch","AI Search",
           "AISearchBot","AI Search Engine","AI Search Intent","AI SEO Crawler","AITraining","AI Training","AI Web","AIWebIndex","AI Web Scraper","AI Website Screenshot","AI Writer","AI – WPBot","AkiraBot","Alexa","AlexaTM","Alice","Alice Yandex","AliGenie","AliyunSec",
           "AliyunSecBot","AllenAI Bot","AlphaAI","Alpha AI","Amazon","Amazon-AI","amazon-kendra","amazon-QBusiness","Amazon Athena","Amazon Bedrock","Amazon Bedrock AgentCore Browser","amazonBot","Amazonbot","AmazonBuyForMe","Amazon Comprehend","Amazon Contxbot","Amazon Kendra",
           "Amazon Kendra Web Crawler","AmazonKnowledgeBasesRetriever","Amazon Lex","Amazon SageMaker","Amazon Silk","Amazon Textract","Amazon Titan","Amelia","Amzn-SearchBot","Amzn-User","amzn.to","anchor","AndiBot","Angular","Anomura","Anonymous AI","anonymous AI chatbot",
           "Anthropic","anthropic-ai","Anthropic-Claude","anthropic bot","AnthropicBot","Anthropic Computer Use","AnyPicker","AnyPicker - A.I","AnythingLLM","Anyword","APIC Agent","ApifyBot","ApifyWebsiteContentCrawler","Apple-GenAI","Applebot","Applebot-Extended","Applebot/0.1",
           "Aranet-SearchBot","Aranet-SearchBot/1.0","ARC-AGI-2","arcee-ai/maestro-reasoning","Aria AI","Aria Browse","Aria browse Aria AI","Aria browser AI","Articoolo","Ask.py","Ask AI","atlassian-bot","Atlassian Rovo","atomic-agent","Atomic Agent","Auto-GPT","AutoGen",
           "AutoGLM","AutoGLM Rumination","AutoGPT","Automated Writer","AutoML","Autonomous RAG","AutoRAG","AutoScraper","AutoWebGLM","Awario","AwarioRssBot","AwarioSmartBot","AWS bedrock","AWS Trainium","Aya Vision","Azure","AzureAI-SearchBot","Azure AI Search","AzureAISearchRetriever","Azure OpenAI",

		   //B LIST
		   "BabyAGI","BabyCatAGI","BAGEL","baiduspider-ai","Bard-Ai","BardBot","Basic RAG","Basic RAG Chain","Bedrock","bedrock-chat","bedrock-chatbot","bedrock-claude-chatbot","bedrockbot","Bedrock Claude","Big Sur","Bigsur","bigsur.ai","Big Sur AI","Big Sur AI Crawler","BM25 Retriever",
		   "Bolt","Bonsai","Botsonic","Bravebot","BraveGPT","Brave Leo AI","Brightbot","Brightbot 1.0","Brightbot operator","Bright Data CLI","Bright Data Scraper","Browserbase","BrowserBase Open Operator","Browser MCP Agent","BrowserOS","Browser Use","BuddyBot","Bytebot","ByteDance",
		   "byteDance","ByteDance crawler","ByteDance LLM","ByteDance Lynx","Bytespider",

		   //C LIST
		   "CarynAI","CatBoost","CCBot","ccbot","CC-Crawler","Celia","Ceramic TerraCotta Crawler","Chai","Channel3Bot","Character","Character-AI","Charstar AI","Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGenie","ChatGLM","ChatGLM-Spider","ChatGPT","ChatGPT 4.5","ChatGPT 5",
		   "ChatGPT Agent","ChatGPT Atlas","ChatGPT Operator","ChatGPT Plus","ChatGPT Retrieval","ChatGPT Scraper","ChatGPT search","ChatGPT-Browser","ChatGPT-User","chatgpt-user","ChatLLM","ChatOpenAI","Chatsonic","ChatUp AI","ChatUser","CheerioCrawler","Chinchilla","Cici","Clara",
		   "Claude","Claude 5","Claude Agent","Claude Computer Use","Claude Fable","Claude Haiku","Claude LLM","Claude Opus","Claude Sonnet","ClaudeBot","Claude-Code","Claude-RAG","Claude-SearchBot","claude-searchbot","Claude-User","claude-user","claude.ai","Clawbot","ClawbotLeadScan",
		   "ClearScope","Clearview","Cloudflare AutoRAG","Cloudflare Browser Rendering","cloudflare-ai-search","Cloudflare-AutoRAG","CloudVertexBot","Code","Cognitive AI","Cognitive AI engine","Cohere","Cohere LLM","Cohere RAG","cohere-ai","Cohere-Command","cohere-training-data-crawler",
		   "Command-A-Reasoning","Common Crawl","CommonCrawl","Compass","content crawler spider","Content Harmony","Content King","Content Optimizer","Content Samurai","Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","Copilot","Copilot Read Aloud",
		   "CopilotBot","CopilotNative","CopilotSapphire","CopyAI","Copymatic","Copyscape","copy.ai","CoreWeave","Corrective RAG","Cotoyogi","Coveobot","CRAB","CragCrawler","Crawl web content","Crawl4AI","Crawl4ai","CrawlGPT","CrawlQ AI","Crawlspace","Crew AI","CrewAI","Crushon AI",
		   "cURL","Cursor","Cypex","cypex.ai/scanning",
		   
		   //D LIST
		   "DALL-E","Dall-E 4","DALL·E 3","Dalle 4 ","DarkBARD","DarkBard","DarkBERT","DarkGPT","DataFor","DataForAI","DataForSeoBot","dataminr","DataProvider","dataprovider","dataprovider spider","dataproviderbot","Datenbank Crawler","Deep AI","Deep Research","Deep Think 2","DeepAI",
		   "DeepL","DeepL Agent","DeepMind","DeepResearch","DeepSeek","Deepseek Agent","DeepSeekBot/1.0","DeepSeekBot","DeepSeek V2.5","DeepSeekV2.5-Chat","DeepSeek-LLM","DeepSeek-R1","deepseek-r1-distill-llama","DeepSeek-V3.1","deepseek/deepseek-v3.2-exp","DepolarizingGPT","Devin",
		   "devin","Devstral","DiaBrowser","DialoGPT","DialoGPT-medium","Diffbot","diffbot","DigitalOceanGenAICrawler","digitaloceangenai-crawler","DocsGPTOnyx","dolly","Dolma","Dots Chatbot","Doubao AI","Doubao 1.5","DuckAssistBot","duckassistbot","DuckDuckGo Chat","DuckDuckGo LangChain Bot","DuckDuckGo-Enhanced",

		   //E LIST
		   "Echobot","Echobot Bot","ExaSearchBot","Echobox","EchoboxBot","ElasticsearchRetriever","Elixir","Embed ","embed-v4.0","ERNIE",  "ErnieBot","Evil-GPT","Extended GPT Scraper","ExaBot",

		   //F LIST
		   "Fastai","FastGPT","Firebase","Firecrawl","FirecrawlAgent","Fireworks","FIRE-1","FIRE-1 Agent","Finbot","Flux","Flux 2","Flyriver","flyriverbot/1.1","Frase AI","FraudGPT","FriendlyCrawler",

		   //G List
		   "Gato","Gemini","Gemini Agentic RAG","Gemini-Ai","Gemini-Deep-Research","Gemini-User","Gemini URL Context","Gemma","Gen AI","GenAI","gen-ai","GeistHaus-PageFetcher","GenAI Chat","GenAI RAG",
		   "Generative","Genspark","Gentoo-chat","gentoo-chat","GhostGPT","Ghostwriter","GigaChat","GLM","GLM,","GLM-","GLM 4.6","GLM 5","Go","gobrowser","GodMode","Google-Agent","google-agent",
		   "Google-Gemini-CLI","Google Gemini","Gemini-Deep-Research","Gemini-Vertex","GoogleAgent URL Context","GoogleAgent-URLContext","GoogleAgent-Mariner","Google-CloudVertexBot","Google-Extended",
		   "Google-Firebase","Google-NotebookLM","Goose","GPT 4 Omni","GPT 4 Omni Mini","GPT 5.1","GPT Chat", "GPT Image", "gpt-image","GPT OSS","GPT-oss","GPT Researcher","GPT Scraper","GP","GPT-",
		   "GPT4ALL","GPT4Free","GPTBot","GPTBot/1.2","GPTBot/1.3","GPTZero","GPT-","GPT-5","GPT-5 Chat","GPT-5 Mini","GPT-5 Nano","GPT-5 Thinking mini","GPT-5.5","GPT Researcher","GPT-crawler",
		   "gpt-crawler","GPT-Qwen Deep Research","GPT-Shield-AI-Plagiarism-Detector","Grafana","Grammarly","Grendizer","Grok","Grok 4 Fast","Grok AI chatbot","Grok DeepSearch","Grok-DeepSearch/","Grok Imagine",
		   "GrokAI","GrokBot","Grok-","Grok 5","Groq","Groq-Bot","GT Bot","GTBot","GTP","GraphQL",
 
		   ///H LIST
		   "hada.news","Haystack - deepset AI","Haystack RAG Pipeline","Headless AI","Headless AI Agent","Hemingway Editor","HenkBot","HenkBot/Valyu AI","Hermes Agent","Hetzner","HttpClient","Hugging",
		   "hugging-face-ai","HuggingChat","Hugging Face","HuggingFace-Bot","huggingfacebot","Hunyuan","HunyuanBot","Hunyuan-7B-Instruct", "Hunyuan-Large-Instruct","hybrid LLM","Hybrid Search RAG","HyperAgent","Hyperbrowser","Hypotenuse AI",

		   //I LIST
		   "iAsk","iAskAI-Crawler","iAskBot","iaskspider","iaskspider/2.0","IbouBot","ICC-Crawler","Ideogram","ImageGen","ImageGPT","Imagen","ImagesiftBot","imagespider","ImageSpider","img2dataset",
		   "imgproxy","inclusionai","Inferkit","INK Editor","INKforall","Instructor","instructor-php","IntelliSeek","IntelliSeek.ai","ips-agent","ISSCyberRiskCrawler",
	   	   
		   //J LIST
		   "Jamba","Janitor AI","JasperAI","JenkersBot","Jenni AI","Julius AI","June",
   
		   //K LIST
		   "LAION-","laion-huggingface-processor","LAION-huggingface-processor","LAIONDownloader","LangChain","langchain-google-genai","langchain-ollama","langchain-openai","langchain-perplexity",
		   "LangChain-Ruby","langchain-scrapeless","LangChain Agent","LangChain Python","Langchain raptor","langchain_ollama","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
		   "LangSmith","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","liner-bot","LinerBot","LINER Bot","Linguee Bot","LinkupBot","Linkup Deep",
		   "LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama3.1-70B-Instruct","Llama3.1-405B-Instruct","LlamaResearcher","LLM","LLM-jp-Crawler","LLM-Scraper","llm-scraper",
		   "llm-scraper","LLMFeeder","LLM Pigeon","LLM Proxy","LLMs","llms.txt crawler bot","LLM Scraper","LLM Websearch","LocalAI","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","Lorph","Lovable",

		   //L LIST
           "LAIONDownloader","LAION-5B","LAION-huggingface-processor","laion-huggingface-processor","LangChain","LangChain Agent","LangChain Python","Langchain raptor","LangChain-Ruby",
           "langchain-google-genai","langchain-openai","langchain-perplexity","LangChain-Ruby","langchain-scrapeless","LangExtract","langextract","Langfuse","LangGraph JS","LangGraph Python",
           "langchain-scrapeless","Language AI","LCC","Le Chat","LeftWingGPT","Lensa","Leonadro","Librarian Bot","Lightpanda","LightRAG","LINER Bot","LinerBot","liner-bot",
           "Linguee Bot","Linkup Deep","LinkupBot","LinkupBot/1.0","LiteLLM","LiteLLM Proxy","LiteLLM Python","LiteLLM Ruby","LLaMA","Llama 3.1","Llama 3.2","Llama 4","Llama3.1-70B-Instruct",
           "Llama3.1-405B-Instruct","LlamaResearchert","LLM Websearch","LLM Pigeon","LLM Proxy","LLM Scraper","LLM-Scraper", "llm-scraper","LLM","LLMFeeder","llms.txt crawler bot",
		   "LLMs","LLM-jp-Crawler","Local AI Chat","Local Hybrid Search RAG","Local RAG","Local RAG Agent","LocalAI","Lorph","Lovable",
		   
		   //M LIST
		   "Magistral","Magistral Medium","Magnus","magpie-crawler","MAI-DS-R1","MAI-Image","MalwareGPT","Manus","Manus-User","Manus Agent","MarketMuse","MBZUAI","MBZUAI Chatbot","MCP",
		   "Medium","Meltwater","Mem0","Meta-AI","Meta-External","Meta-ExternalAgent","meta-externalagent","Meta-ExternalFetcher","meta-externalfetcher","Meta-Webindexer","meta-webindexer",
		   "Meta.AI","Meta Agent","Meta AI","MetaAI","Meta AI Crawler","MetaGPT","Meta Llama","Meta search scraper","MetaTagBot","Middleware","Midjourney","midjourney","Mini AGI","minimal AGI",
		   "MiniMax","MiniMax-Agent","Mintlify","Mistral","mistral-large","mistral-medium","mistral-small","Mistral.ai","MistralAI-User","MistralAI-Training","Mistral Le Chat Agent",
		   "Mistral NeMo Instruct","Mistral OCR","Mistral Perflexity AI","Mixtral","Mixtral-8x22B-Instruct","Mixtral 8x22B","MobileLLM-R1","ModatScanner","Model Context Protocol - MCP",
		   "Molmo","Monica","Moonshot","Moshi","Mozilla-Tabstack","Muse","MyCentralAIScraperBot","Mycroft AI",

		   //N LIST
		   "n8n-nodes-aiscraper","NagetBot","Nano","Nano novellum","Nano Search","nanobot","Nanobrowser","nanochat","nanoclaw","Narrative","Nbot","NeevaBot","netEstate","netEstate Imprint Crawler",
		   "NetShelter ContentScan","Neural Text","NeuralSEO","newsai","NextChat","Nicecrawler","Ninja Deep Research","Ninja - Chatbot AI","NinjaAI","NinjaAIBot","NodeZero","Node.js","NotebookLM",
		   "NotebookLM Deep Research","Notion MCP Agent","Nova","Nova 2 Lite","Nova 2 Sonic","Nova Act","Nova Premier","NovaAct","nova-premier-","Novellum Search","nullclaw","Nutch","Nytheon","Nytheon AI",

		   //O LIST
		   "OAI SearchBot","OAI-SearchBot/1.0","OAI-SearchBot/1.3","OASIS","OIG","Ola","Olivia","Ollama","oLLM","OLM","OLMo","OLMo 2 Chatbot","Olmo Hybrid","OLMoASR","OLMoE","Omgili","omgili",
		   "Omgilibot","omgilibot","Onyx","Open AI","Open Claw browser","Open Deep Research","Open Interpreter","Open Lovable","Open Operator","Open Perflexity","Open Source LLM","OpenAGI","OpenAI",
		   "OpenAI Crawler","OpenAI CUA","OpenAI GPTBot","OpenAI Image Downloader","OpenAI Operator","OpenAI Python","OpenAIContentCrawler","openai-python","openai-user","OpenBot","Openbot",
		   "OpenClaw","OpenClaw Agent","opencode","OpenELM","OpenInterpreter","OpenLens AI","OpenLLaMA","OpenLM","OpenPi","openpi","OpenRouter","openrouter","OpenText AI","OpenVLA","Operator","Opus","Outwrite","OVHcloud","OVHcloud AI Training","OWL","Owlin","OxyCopilot",

           //P LIST
		   "Page Analyzer AI","PandasAI","PanGu Chat","PanguBot","Panscient","panscient.com","Paraphraser.io","PentestGPT","PentestGPT Research","Perflexity","Perplexity AI","Perplexity Chatbot",
		   "Perplexity Deep Research","Perplexity Image","Perplexity LLM","Perplexity pypi","Perplexity Research","Perplexity Scraper","Perplexity Search","Perplexity Stealth","Perplexity Web Scraper",
		   "PerplexityBot","Perplexity-Bot","perplexity-py","Perplexity-Stealth","Perplexity-User","PetalBot","petalBot","Phind","PhindBot","phi-4-multimodal-instruct","phi-4-reasoning-plus","Playwright",
		   "Playwright Agentic AI","Playwright MCP","Playwright Stealth","PlaywrightCrawler","Poe","PoeBot","PoeSearchBot","Poggio","Poseidon","Poseidon Research Crawler","ProWrid","ProWritingAid",
		   "Proximic","proximic","PulsarRPA","Puppeteer","Python AI","python Ai","Python lxml","Python Scrapy","PyTorch","PyTorch Lightning","PyTorch Lightning LLM",

   		   //Q LIST
		   "Qopywriter","Qopywriter.ai","Qualified","QualifiedBot","Quark","QueritBot","Querit-SearchBot","QuillBot","quillbot.com","Qwen","Qwen Chat","Qwen Deep Research","Qwen LLM","QwenLM","Qwen-Agent","Qwen-Chat",

		   //R LIST
		   "AI RAG","RAG","RAG Agent","RAG Agent Cohere","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG Database Routing","RAG IS","RAG LLM","RAG Pipeline","RAG Search","RAG with",
		   "RAG with Vercel AI SDK","RAGify Search","RAG-","RAG-as-a-Service","RAG-","RAG_","RAG_VertexAI","RAG_with_search","RAPTOR LLM","React Agent","ReAct AI Agent","Redis AI RAG","Reka Flash",
		   "Replicate","Replicate-Bot","resec.ai","Retriever","RSS/XML Scraper","Runner H","Rytr",

		   //S LIST
		   "Sambanova","SaplingAI","SBIntuitionsBot","Scala","scaleai","ScrapeGraph","ScrapeGraphAI","Scrapegraph-ai","Scrapegraph","Scrapeless","Scraper","Scraper Bot","Scraping Browser","Scrapling",
		   "Scrapy","Scrapy spider","scrapy-redis","Scrapy crawlspider","Scrapy Middleware","Scrapy Python","Scrapy selenium","Scrapy-LLM","scrapy-playwright","Search RAG","Search retrieval","SearchChat",
		   "Seekr","SEO Content Machine","Serper","SerpApiBot","Sitefinity","SiteSucker", "skrape.ai","Skyvern","SmartScrape","SmartScraperGraph","Spawning AI","Spawning-ai","Spider","Spider Middleware",
		   "Spin Rewrite","Spinbot","Stability","Stable Diffusion","Super Agent","Superagent","ScryBot",

		   //T LIST
           "TaraGroup Intelligent Bot","TavilyBot","TavilySearchAPIRetriever","Tencent AI chatbot","Terra Cotta","TerraCotta","Text Formatter","TextCortex","Text-RAG","The Knowledge AI","thehive.ai",
           "TheKnowledgeAI","Thinkbot","Thinklab","Thordata","TikTokSpider","Timpibot","Together","Together AI","Together-Bot","TongyiBot","Trae","Tulu","Turnitin","TurnitinBot",

           //U LIST
           "uAgents","UseAI","haystack-ai", 

		   //V LIST
           "VaultGemma","VelenPublicWebCrawler","Venus Chub AI","VertexAISearchRetriever","Vidnami AI","VimGPT","Vision RAG","VLM","vnCallbot","vnFace","VNPT AI","VNPT AI Assistant","VNPT SmartBot","VNPT SmartReader",

           //W LIST
           "AI Web Search","AI – WPBot","AIWebIndex","ai-writer","wan","Weaviate","Web 3.0 Navigator","Web Browser Bot","Web Search","Web Search Agent","WebChatGPT","WebCrawler-AI","WebExplorer-8B",
           "WebFetch","WebFetch.MCP","Webscrape","Webscrape AI","webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","Websearch","WebSurfer","WebText","WebVoyager","Webzio","Webzio-Extended",
           "Web-Search-AI","WeSEE","Whisper","WizardLM","WolfGPT","WordAI","Wordtune","WormGPT","WPBot","wpbot","Writecream","WRITER Agent","WriterZen","Writescope","Wrtn","WRTNBot","WRTNBot crawler",

           //X Y  LIST
           "XAIAgent","xAI-SearchBot","xAI-Web-Crawler","xBot","YaK","YiyanBot","YouBot",

		   //Z LIST
           "ZanistaBot","Zero","Zero GTP","ZeroCHAT","Zerochat","ZeroGPT","ZeroSearch","ZeroStep","Zhipu","Zhuque AI","Zhuque AI Detector","Zimm","Zoominfo AI Agents",

           //Browsers used by scraping
		   //Android Updated 26080904
           "Android 1.0","Android 1.1","Android 1.5","Android 1.6","Android 2.0","Android 2.1","Android 2.2","Android 2.3","Android 3.0","Android 3.2","Android 4.0","Android 4.1","Android 4.3",	
           "Android 4.4","Android 4.4.2","Android 5.0","Android 6.0","Android 7.0","Android 7.1","Android 7.1.1","Android 8.0","Android 8.1","Android 9","Android 10","Android 11",	"Android 12",
           "Android 13","Android 14","Android 15","Android 16","Android 17",  

		   //Brave Chrome, uses by scrapers/hackers Updated 260725
           "Brave Chrome/0.2.149","Brave Chrome/0.3.154","Brave Chrome/0.4.154","Brave Chrome/1.0.154","Brave Chrome/2.0.172","Brave Chrome/3.0.195","Brave Chrome/4.0.249","Brave Chrome/4.1.249","Brave Chrome/6.0.472","Brave Chrome/7.0.517","Brave Chrome/7.0.517.441",
		   "Brave Chrome/8.0.552","Brave Chrome/9.0.597","Brave Chrome/10.0.648","Brave Chrome/11.0.696","Brave Chrome/12.0.742.91","Brave Chrome/12.0.742.112","Brave Chrome/12.0.7421","Brave Chrome/13.0.782.215","Brave Chrome/13.0.7821","Brave Chrome/15.0.87414.0.8351",
		   "Brave Chrome/15.0.1901.200","Brave Chrome/16.0.912.63","Brave Chrome/17.0.963.33","Brave Chrome/17.0.963.56","Brave Chrome/17.0.963.65","Brave Chrome/18.0.865.0","Brave Chrome/18.0.1025.162","Brave Chrome/19.0.1084.46","Brave Chrome/19.0.1084.52",
		   "Brave Chrome/20.0.1132.39","Brave Chrome/27.0.1453.94","Brave Chrome/28.0.1500","Brave Chrome/29.0.1547.57","Brave Chrome/30.0.1599.66","Brave Chrome/34.0.824.0","Brave Chrome/34.0.1847.114","Brave Chrome/43.0.845.0","Brave Chrome/45.0.2454.94",
		   "Brave Chrome/46.0.2490.80","Brave Chrome/47.0.2283.102","Brave Chrome/48.0.861.0","Brave Chrome/48.0.2564.97","Brave Chrome/49.0.2623.75","Brave Chrome/50.0.2661","Brave Chrome/50.0.2661.102","Brave Chrome/50.0.3232.292","Brave Chrome/51.0.870.0",
		   "Brave Chrome/51.0.2160.381","Brave Chrome/51.0.2329.290","Brave Chrome/51.0.2704.84","Brave Chrome/52.0.2315.144","Brave Chrome/52.0.2743.116","Brave Chrome/52.0.3133.374","Brave Chrome/52.0.3748.297","Brave Chrome/53.0.2785.116",
		   "Brave Chrome/54.0.1107.38","Brave Chrome/54.0.2840.71","Brave Chrome/55.0.2660.238","Brave Chrome/55.0.2883.75","Brave Chrome/56.0.2924.87","Brave Chrome/57.0.2987.133","Brave Chrome/58.0.3029.96","Brave Chrome/60.0.3112.78","Brave Chrome/60.0.3112.90",
		   "Brave Chrome/60.0.3112.107","Brave Chrome/61.0.3163.79","Brave Chrome/62.0.3202.75","Brave Chrome/63.0.3239.108","Brave Chrome/64.0.3282.140","Brave Chrome/65.0.3325.181","Brave Chrome/66.0.3359.158","Brave Chrome/67.0.3396.79","Brave Chrome/68.0.3440.84",
		   "Brave Chrome/68.0.3440.106","Brave Chrome/69.0.3497.92","Brave Chrome/78.0.3904.70", "Brave Chrome/70.0.3538.77","Brave Chrome/70.0.3538.102","Brave Chrome/71.0.3578.80","Brave Chrome/74.0.3729","Brave Chrome/74.0.3729.169","Brave Chrome/75.0.3770.80","Brave Chrome/76.0.3809.100",
           "Brave Chrome/77.0.3844.0","Brave Chrome/77.0.3865.116","Brave Chrome/78.0.3904.70","Brave Chrome/78.0.3904.97","Brave Chrome/79.0.309.11","Brave Chrome/79.0.309.30","Brave Chrome/79.0.309.65","Brave Chrome/79.0.309.68","Brave Chrome/79.0.309.71",
           "Brave Chrome/78.0.3904.87","Brave Chrome/79.0.3945.88","Brave Chrome/80.0.3987.14","Brave Chrome/83.0.4103.106","Brave Chrome/86.0.4240.198","Brave Chrome/87.0.4280.101","Brave Chrome/88.0.4324.146","Brave Chrome/88.0.4324.152","Brave Chrome/89.0.4389.72","Brave Chrome/79.0.3945.88",
           "Brave Chrome/79.0.3945.0","Brave Chrome/79.0.3945.88","Brave Chrome/79.0.3945.130","Brave Chrome/80.0.361.45","Brave Chrome/80.0.361.48","Brave Chrome/80.0.361.62","Brave Chrome/80.0.361.109","Brave Chrome/80.0.3987.0","Brave Chrome/80.0.3987.132",
           "Brave Chrome/80.0.3987.149","Brave Chrome/80.0.3987.163","Brave Chrome/81.0.416.34","Brave Chrome/81.0.416.58","Brave Chrome/81.0.416.62","Brave Chrome/81.0.416.77","Brave Chrome/81.0.4044.92","Brave Chrome/83.0.478.37","Brave Chrome/83.0.478.58",
           "Brave Chrome/83.0.478.64","Brave Chrome/83.0.4103.0","Brave Chrome/83.0.4103.61","Brave Chrome/83.0.4103.116","Brave Chrome/84.0.522.40","Brave Chrome/84.0.522.52","Brave Chrome/84.0.522.58","Brave Chrome/84.0.522.61","Brave Chrome/84.0.4147.1",
		   "Brave Chrome/84.0.4147.105","Brave Chrome/84.0.4147.135","Brave Chrome/85.0.564.44","Brave Chrome/85.0.4182.0","Brave Chrome/85.0.4183.102","Brave Chrome/85.0.4183.121","Brave Chrome/86.0.622.48","Brave Chrome/86.0.622.56","Brave Chrome/86.0.622.61",
		   "Brave Chrome/86.0.622.68","Brave Chrome/86.0.4240.75","Brave Chrome/87.0.664.47","Brave Chrome/87.0.664.52","Brave Chrome/87.0.4280.14","Brave Chrome/87.0.4280.88","Brave Chrome/88.0.4298.0","Brave Chrome/88.0.4324.0","Brave Chrome/88.0.4324.182","Brave Chrome/88.0.4324.186",
		   "Brave Chrome/89.0.774.45","Brave Chrome/89.0.774.50","Brave Chrome/89.0.4389.72","Brave Chrome/89.0.4389.86","Brave Chrome/89.0.4389.90","Brave Chrome/90.0.818.42","Brave Chrome/90.0.818.56","Brave Chrome/90.0.818.62","Brave Chrome/90.0.4430.72","Brave Chrome/90.0.4430.85",
		   "Brave Chrome/90.0.4430.85","Brave Chrome/90.0.4430.85","Brave Chrome/91.0.864.53","Brave Chrome/91.0.864.70","Brave Chrome/91.0.864.71","Brave Chrome/91.0.4472.77","Brave Chrome/91.0.4472.114","Brave Chrome/91.0.4472.124","Brave Chrome/92.0.902.55",
           "Brave Chrome/92.0.4512.0","Brave Chrome/92.0.4515.107","Brave Chrome/92.0.4515.159","Brave Chrome/93.0.4577.0","Brave Chrome/93.0.4577.82","Brave Chrome/94.0.992.31","Brave Chrome/94.0.992.37","Brave Chrome/94.0.992.50","Brave Chrome/94.0.4606.61",
           "Brave Chrome/95.0.1020.53","Brave Chrome/95.0.4638.54","Brave Chrome/96.0.1054.41","Brave Chrome/96.0.1054.53","Brave Chrome/96.0.4641.0","Brave Chrome/96.0.4664.45","Brave Chrome/96.0.4664.110","Brave Chrome/97.0.1072.55","Brave Chrome/97.0.1072.62",
           "Brave Chrome/97.0.1072.69","Brave Chrome/97.0.4280.67","Brave Chrome/97.0.4680.0","Brave Chrome/98.0.1108.6","Brave Chrome/98.0.1108.43","Brave Chrome/98.0.4758.80","Brave Chrome/99.0.1150.46","Brave Chrome/100.0.1185.36","Brave Chrome/101.0.1210.4",
           "Brave Chrome/101.0.4951.41","Brave Chrome/101.0.4951.64","Brave Chrome/101.0.4951.67","Brave Chrome/102.0.1245.30","Brave Chrome/102.0.1245.44","Brave Chrome/102.0.5005.63","Brave Chrome/103.0.0.0","Brave Chrome/103.0.1264.49","Brave Chrome/104.0.0.0",
           "Brave Chrome/104.0.0.1","Brave Chrome/104.0.1293.47","Brave Chrome/104.0.1293.54","Brave Chrome/104.0.5112.79","Brave Chrome/104.0.5112.79","Brave Chrome/104.0.5112.97","Brave Chrome/104.0.5112.102","Brave Chrome/105.0.1343.42","Brave Chrome/105.0.1343.50",
           "Brave Chrome/105.0.5195.52","Brave Chrome/105.0.5195.125","Brave Chrome/106.0.0.0","Brave Chrome/106.0.1370.34","Brave Chrome/106.0.1370.47","Brave Chrome/106.0.5249.30","Brave Chrome/106.0.5249.62","Brave Chrome/106.0.5249.91","Brave Chrome/106.0.5249.119",
           "Brave Chrome/107.0.0.0","Brave Chrome/107.0.1418.24","Brave Chrome/107.0.1418.52","Brave Chrome/107.0.1418.62","Brave Chrome/107.0.5304.63","Brave Chrome/107.0.5304.106","Brave Chrome/107.0.5304.110","Brave Chrome/107.0.5304.121","Brave Chrome/108.0.0.0",
           "Brave Chrome/108.0.1462.46","Brave Chrome/108.0.1462.76","Brave Chrome/108.0.5359.94","Brave Chrome/108.0.5359.98","Brave Chrome/109.0.0.0","Brave Chrome/109.0.1518.52","Brave Chrome/109.0.1518.61","Brave Chrome/109.0.1518.70","Brave Chrome/109.0.5414.46",
           "Brave Chrome/109.0.5414.119","Brave Chrome/110.0.0.0","Brave Chrome/110.0.1587.50","Brave Chrome/110.0.1587.57","Brave Chrome/110.0.1587.63","Brave Chrome/110.0.1587.69","Brave Chrome/110.0.5481.30","Brave Chrome/110.0.5481.78","Brave Chrome/110.0.5481.100",
           "Brave Chrome/110.0.5481.178","Brave Chrome/110.0.5481.192","Brave Chrome/111.0.0.0","Brave Chrome/111.0.1661.54","Brave Chrome/111.0.5532.0","Brave Chrome/111.0.5532.2","Brave Chrome/111.0.5563.8","Brave Chrome/111.0.5563.19","Brave Chrome/111.0.5563.64",
           "Brave Chrome/111.0.5563.65","Brave Chrome/112.0.1722.34","Brave Chrome/112.0.1722.39","Brave Chrome/112.0.1722.48","Brave Chrome/112.0.5596.2","Brave Chrome/112.0.5614.0","Brave Chrome/112.0.5615.20","Brave Chrome/112.0.5615.49","Brave Chrome/112.0.5615.50",
           "Brave Chrome/112.0.5615.87","Brave Chrome/112.0.5615.121","Brave Chrome/112.0.5615.165","Brave Chrome/113.0.0.0","Brave Chrome/113.0.1774.35","Brave Chrome/113.0.1774.57","Brave Chrome/113.0.5672.64","Brave Chrome/114.0.1823.37","Brave Chrome/114.0.1823.43",
           "Brave Chrome/114.0.1823.55","Brave Chrome/114.0.1823.67","Brave Chrome/114.0.1823.82","Brave Chrome/114.0.5735.91","Brave Chrome/114.0.5735.133","Brave Chrome/115.0.1901.203","Brave Chrome/115.0.5790.24","Brave Chrome/115.0.5790.98","Brave Chrome/116.0.5845.0",
           "Brave Chrome/116.0.1938.76","Brave Chrome/116.0.5845.82","Brave Chrome/117.0.2045.41","Brave Chrome/117.0.5938.60","Brave Chrome/117.0.5938.132","Brave Chrome/117.0.5938.149","Brave Chrome/118.0.0.0","Brave Chrome/119.0.2151.72","Brave Chrome/119.0.6045.9",
           "Brave Chrome/119.0.6045.9","Brave Chrome/119.0.6045.123","Brave Chrome/119.0.6045.159","Brave Chrome/119.0.6045.199","Brave Chrome/120.0.0.0.0","Brave Chrome/120.0.0.0","Brave Chrome/120.0.2210.91","Brave Chrome/120.0.6099.28","Brave Chrome/120.0.6099.109",
           "Brave Chrome/120.0.6099.129","Brave Chrome/120.0.6099.939","Brave Chrome/121.0.0.0","Brave Chrome/121.0.0.0","Brave Chrome/121.0.2277.106","Brave Chrome/121.0.6167.0","Brave Chrome/121.0.6167.57","Brave Chrome/121.0.6167.85","Brave Chrome/121.0.6167.184",
           "Brave Chrome/122.0.2365.52","Brave Chrome/122.0.2365.66","Brave Chrome/122.0.2365.92","Brave Chrome/122.0.6261.57","Brave Chrome/122.0.6261.94","Brave Chrome/123.0.2420.65","Brave Chrome/123.0.6312.0","Brave Chrome/123.0.6312.4","Brave Chrome/123.0.6312.105",
           "Brave Chrome/124.0.0.0","Brave Chrome/124.0.2478.67","Brave Chrome/124.0.6367.78","Brave Chrome/124.0.6367.91","Brave Chrome/124.0.6367.92","Brave Chrome/124.0.6367.118","Brave Chrome/125.0.0","Brave Chrome/125.0.2535.85","Brave Chrome/125.0.2535.92",
           "Brave Chrome/125.0.6422.26","Brave Chrome/125.0.6422.60","Brave Chrome/126.0.0.0","Brave Chrome/126.0.2592.68","Brave Chrome/126.0.2592.87","Brave Chrome/126.0.6478.61","Brave Chrome/126.0.6478.126","Brave Chrome/126.0.6478.128","Brave Chrome/126.0.6478.182",
           "Brave Chrome/127.0.0.0","Brave Chrome/127.0.0.1","Brave Chrome/127.0.2651.86","Brave Chrome/127.0.2651.98","Brave Chrome/127.0.6533.17","Brave Chrome/127.0.6533.73","Brave Chrome/127.0.6533.89","Brave Chrome/127.0.6533.99","Brave Chrome/127.0.6533.100",
           "Brave Chrome/127.0.6533.119","Brave Chrome/127.0.6533.122","Brave Chrome/127.0.6533","Brave Chrome/128.0.0.0","Brave Chrome/128.0.6613.18","Brave Chrome/128.0.6613.84","Brave Chrome/128.0.6613.120","Brave Chrome/128.0.6613.138","Brave Chrome/129.0.0.0",
           "Brave Chrome/129.0.6668.29","Brave Chrome/129.0.6668.59","Brave Chrome/129.0.6668.71","Brave Chrome/129.0.6668.71","Brave Chrome/129.0.6668.90","Brave Chrome/129.0.6668.101","Brave Chrome/130.0.6723.70","Brave Chrome/130.0.6723.117","Brave Chrome/130.0.6778.70",
           "Brave Chrome/131.0.6778.86","Brave Chrome/131.0.6778.140","Brave Chrome/131.0.6778.265","Brave Chrome/132.0.6834.111","Brave Chrome/133.0.6943.60","Brave Chrome/133.0.6943.127","Brave Chrome/134.0.6998.36","Brave Chrome/134.0.6998.89","Brave Chrome/134.0.6998.118",
           "Brave Chrome/135.0.7049.42","Brave Chrome/135.0.7049.96","Brave Chrome/136.0.7103.93","Brave Chrome/136.0.7103.114","Brave Chrome/136.0.7103.59","Brave Chrome/136.0.7103.92","Brave Chrome/136.0.7103.113","Brave Chrome/137.0.7151.55","Brave Chrome/137.0.7151.68",
           "Brave Chrome/137.0.7151.103","Brave Chrome/137.0.7151.119","Brave Chrome/138.0.7204.49","Brave Chrome/103.0.5060.66","Brave Chrome/138.0.7204.92","Brave Chrome/138.0.7204.96","Brave Chrome/138.0.7204.157","Brave Chrome/138.0.7204.168","Brave Chrome/138.0.7204.183","Brave Chrome/138.0.7194.0",
           "Brave Chrome/138.0.7194.0","Brave Chrome/138.0.7194.0","Brave Chrome/138.0.7204.97","Brave Chrome/141.0.7340.0","Brave Chrome/141.0.7376.0","Brave Chrome/141.0.7390.55","Brave Chrome/142.0.7416.0","Brave Chrome/142.0.7444.60","Brave Chrome/142.0.7444.135",
           "Brave Chrome/142.0.7444.163","Brave Chrome/142.0.7444.176","Brave Chrome/1143.0.7499.193","Brave Chrome/143.0.7499.147","Brave Chrome/143.0.7499.170","Brave Chrome/143.0.7499.110","Brave Chrome/143.0.7499.41","Brave Chrome/144.0.7559.110",
           "Brave Chrome/144.0.7559.97","Brave Chrome/144.0.7559.60","Brave Chrome/144.0.7559.133","Brave Chrome/144.0.7547.0","Brave Chrome/144.0.7559.133","Brave Chrome/145.0.7632.117","Brave Chrome/145.0.7632.110","Brave Chrome/145.0.7632.76","Brave Chrome/147.0.7727.56",
           "Brave Chrome/147.0.7683.0","Brave Chrome/148.0.7730.0","Brave Chrome/148.0.7778.97","Brave Chrome/148.0.7778.168","Brave Chrome/149.0.7814.0","Brave Chrome/149.0.7814.0","Brave Chrome/149.0.7827.54","Brave Chrome/149.0.7827.103","Brave Chrome/149.0.7827.115",
           "Brave Chrome/149.0.7827.156","Brave Chrome/149.0.7827.197","Brave Chrome/149.0.7827.201","Brave Chrome/150.0.7871.47","Brave Chrome/150.0.7871.101","Brave Chrome/151.0.7910.0",

           //Chrome old versions  Updated 260825
           "Chrome/0.2.149","Chrome/0.2.149.6","Chrome/0.3.154","Chrome/0.4.154","Chrome/1.0.154","Chrome/2.0.172","Chrome/3.0.195","Chrome/4.0.249","Chrome/4.1.249","Chrome/6.0.472","Chrome/7.0.517","Chrome/7.0.517.441","Chrome/8.0.552","Chrome/9.0.597","Chrome/10.0.648","Chrome/11.0.696","Chrome/12.0.742.91",
           "Chrome/12.0.742.112","Chrome/12.0.7421","Chrome/13.0.782.215","Chrome/13.0.7821","Chrome/15.0.87414.0.8351","Chrome/15.0.1901.200","Chrome/16.0.912.63","Chrome/17.0.963.33","Chrome/17.0.963.56","Chrome/17.0.963.65","Chrome/18.0.865.0","Chrome/18.0.1025.162","Chrome/19.0.1084.46",
		   "Chrome/19.0.1084.52","Chrome/20.0.1132.39","Chrome/27.0.1453.94","Chrome/28.0.1500","Chrome/29.0.1547.57","Chrome/30.0.1599.66","Chrome/34.0.824.0","Chrome/34.0.1847.114","Chrome/43.0.845.0","Chrome/45.0.2454.84","Chrome/45.0.2454.94","Chrome/35.0.1916.47","Chrome/39.0.2171.95","Chrome/41.0.2225.0",
		   "Chrome/41.0.2227.0","Chrome/47.0.2526.106","Chrome/48.0.2564.116","Chrome/63.0.3239.132","Chrome/65.0.3325.5","Chrome/66.0.3359.2","Chrome/46.0.2490.80","Chrome/47.0.2283.102","Chrome/48.0.861.0","Chrome/48.0.2564.97","Chrome/49.0.2623.75","Chrome/50.0.2661","Chrome/50.0.2661.102",
		   "Chrome/50.0.3232.292","Chrome/51.0.870.0","Chrome/51.0.2160.381","Chrome/51.0.2329.290","Chrome/51.0.2704.84","Chrome/52.0.2315.144","Chrome/52.0.2743.116","Chrome/52.0.3133.374","Chrome/52.0.3748.297","Chrome/53.0.2785.116","Chrome/54.0.1107.38","Chrome/54.0.2840.71","Chrome/55.0.2660.238",
		   "Chrome/55.0.2883.75","Chrome/56.0.2924.87","Chrome/57.0.2987.133","Chrome/58.0.3029.96","Chrome/60.0.3112.78","Chrome/60.0.3112.90","Chrome/60.0.3112.107","Chrome/61.0.3163.79","Chrome/62.0.3202.75","Chrome/63.0.3239.108","Chrome/64.0.3282.140","Chrome/65.0.3325.181","Chrome/66.0.3359.158",
		   "Chrome/67.0.3396.79","Chrome/68.0.3440.84","Chrome/60.0.3112.116","Chrome/96.7.9","Chrome/1.7.9","Chrome/65.0.3325.779","Chrome/79.0","Chrome/27.0.1453.90","Chrome/27.0.1453.93","Chrome/27.0.1453.116","Chrome/28.0.1464.0","Chrome/31.0.1650.16","Chrome/32.0.1664.3","Chrome/34.0.1847.137",
		   "Chrome/66.0.3359.181","Chrome/67.0.3396.87","Chrome/68.0.3409.1","Chrome/68.0.3440.106","Chrome/69.0.0.3016","Chrome/69.0.3497.100","Chrome/72.0.3626.92","Chrome/74.0.3729.131","Chrome/74.0.3729.169","Chrome/68.0.3440.106","Chrome/69.0.3497.92","Chrome/70.0.3538.77","Chrome/70.0.3538.102",
		   "Chrome/71.0.3578.80","Chrome/74.0.3729","Chrome/74.0.3729.169","Chrome/75.0.3770.80","Chrome/76.0.3809.100","Chrome/75.0.3770.100","Chrome/77.0.3865.90","Chrome/77.0.3865.99","Chrome/78.0.3904.108","Chrome/79.0.3945.79","Chrome/79.0.3945.88","Chrome/79.0.3945.130","Chrome/80.0.3987.122",
		   "Chrome/80.0.3987.132","Chrome/77.0.3844.0","Chrome/77.0.3865.116","Chrome/78.0.3904.70","Chrome/78.0.3904.97","Chrome/78.0.3904.108","Chrome/79.0.309.11","Chrome/79.0.309.30","Chrome/79.0.309.65","Chrome/79.0.309.68","Chrome/79.0.309.71","Chrome/79.0.3945.0","Chrome/79.0.3945.88","Chrome/79.0.3945.130",
		   "Chrome/80.0.361.45","Chrome/80.0.361.48","Chrome/80.0.361.62","Chrome/80.0.361.109","Chrome/80.0.3987.0","Chrome/80.0.3987.132","Chrome/80.0.3987.136","Chrome/80.0.3987.162","Chrome/81.0.4044.113","Chrome/83.0.4103.61","Chrome/83.0.4103.106","Chrome/83.0.4103.116","Chrome/84.0.4137.1",
		   "Chrome/84.0.4147.89","Chrome/84.0.4147.105","Chrome/80.0.3987.149","Chrome/80.0.3987.163","Chrome/81.0.416.34","Chrome/81.0.416.58","Chrome/81.0.416.62","Chrome/81.0.416.77","Chrome/81.0.4044.92","Chrome/83.0.478.37","Chrome/83.0.478.58","Chrome/83.0.478.64","Chrome/83.0.4103.0",
		   "Chrome/83.0.4103.61","Chrome/83.0.4103.116","Chrome/84.0.522.40","Chrome/84.0.522.52","Chrome/84.0.522.58","Chrome/84.0.522.61","Chrome/84.0.4147.1","Chrome/84.0.4147.105","Chrome/84.0.4147.135","Chrome/85.0.564.44","Chrome/85.0.4182.0","Chrome/85.0.4183.102","Chrome/85.0.4183.121",
		   "Chrome/86.0.622.48","Chrome/86.0.622.56","Chrome/86.0.622.61","Chrome/84.0.4147.108","Chrome/84.0.4147.135","Chrome/85.0.4183.48","Chrome/86.0.4240.198","Chrome/87.0.4280.60","Chrome/87.0.4280.66","Chrome/87.0.4280.88","Chrome/88.0.4324.41","Chrome/88.0.4324.146","Chrome/86.0.622.68",
		   "Chrome/86.0.4240.75","Chrome/87.0.664.47","Chrome/87.0.664.52","Chrome/87.0.4280.14","Chrome/87.0.4280.88","Chrome/88.0.4298.0","Chrome/88.0.4324.0","Chrome/88.0.4324.186","Chrome/88.0.4324.150","Chrome/88.0.4324.152","Chrome/89.0.4371.0","Chrome/89.0.4389.90","Chrome/89.0.4389.105",
		   "Chrome/89.0.4389.114","Chrome/89.0.4389.127","Chrome/90.0.4427.5","Chrome/90.0.4430.93","Chrome/89.0.774.45","Chrome/89.0.774.50","Chrome/89.0.4389.86","Chrome/89.0.4389.90","Chrome/90.0.818.42","Chrome/90.0.818.56","Chrome/90.0.818.62","Chrome/90.0.4430.72","Chrome/90.0.4430.85",
		   "Chrome/90.0.4430.85","Chrome/90.0.4430.85","Chrome/91.0.864.53","Chrome/91.0.864.70","Chrome/91.0.864.71","Chrome/91.0.4472.77","Chrome/91.0.4472.114","Chrome/91.0.4472.124","Chrome/92.0.902.55","Chrome/90.0.4430.212","Chrome/91.0.4450.0","Chrome/91.0.4472.124","Chrome/92.0.4515.131",
		   "Chrome/93.0.4564.0","Chrome/93.0.4577.82","Chrome/94.0.4606.71","Chrome/94.0.4606.81","Chrome/94.0.4606.114","Chrome/92.0.4512.0","Chrome/92.0.4515.107","Chrome/92.0.4515.159","Chrome/93.0.4577.0","Chrome/93.0.4577.82","Chrome/94.0.992.31","Chrome/94.0.992.37","Chrome/94.0.992.50",
		   "Chrome/94.0.4606.61","Chrome/95.0.1020.53","Chrome/95.0.4638.54","Chrome/95.0.4638.69","Chrome/96.0.4664.55","Chrome/96.0.4664.110","Chrome/97.0.4692.99","Chrome/97.0.4950.0","Chrome/98.0.4758.80","Chrome/99.0.3538.77","Chrome/95.0.1020.53","Chrome/95.0.4638.54","Chrome/96.0.1054.41",
		   "Chrome/96.0.1054.53","Chrome/96.0.4641.0","Chrome/96.0.4664.45","Chrome/96.0.4664.110","Chrome/97.0.1072.55","Chrome/97.0.1072.62","Chrome/97.0.1072.69","Chrome/97.0.4280.67","Chrome/97.0.4680.0","Chrome/98.0.1108.6","Chrome/98.0.1108.43","Chrome/98.0.4758.80","Chrome/99.0.1150.46",
		   "Chrome/100.0.1185.36","Chrome/101.0.1210.4","Chrome/99.0.4844.84","Chrome/100.0.4896.58","Chrome/100.0.4896.75","Chrome/100.0.4896.127","Chrome/101.0.4951.64","Chrome/101.0.4951.67","Chrome/102.0.0.0","Chrome/103.0.0.0","Chrome/104.0.0.0","Chrome/105.0.0.0","Chrome/101.0.4951.41","Chrome/101.0.4951.64",
		   "Chrome/101.0.4951.67","Chrome/102.0.1245.30","Chrome/102.0.1245.44","Chrome/102.0.5005.63","Chrome/103.0.0.0","Chrome/103.0.1264.49","Chrome/104.0.0.0","Chrome/104.0.0.1","Chrome/104.0.1293.47","Chrome/104.0.1293.54","Chrome/104.0.5112.79","Chrome/104.0.5112.79","Chrome/104.0.5112.81",
		   "Chrome/104.0.5112.97","Chrome/104.0.5112.102","Chrome/105.0.1343.42","Chrome/105.0.1343.50","Chrome/105.0.5195.52","Chrome/105.0.5195.125","Chrome/106.0.0.0","Chrome/106.0.1370.34","Chrome/106.0.1370.47","Chrome/106.0.5249.30","Chrome/106.0.5249.62","Chrome/106.0.5249.91",
		   "Chrome/106.0.5249.119","Chrome/106.0.0.0","Chrome/107.0.0.0","Chrome/108.0.5163.147","Chrome/108.0.5399.183","Chrome/110.0.0.0","Chrome/113.0.0.0","Chrome/113.0.0.99999","Chrome/113.0.9999.0","Chrome/113.9999.0.0","Chrome/107.0.0.0","Chrome/107.0.1418.24","Chrome/107.0.1418.52",
		   "Chrome/107.0.1418.62","Chrome/107.0.5304.63","Chrome/107.0.5304.106","Chrome/107.0.5304.110","Chrome/107.0.5304.121","Chrome/108.0.0.0","Chrome/108.0.1462.46","Chrome/108.0.1462.76","Chrome/108.0.5359.94","Chrome/108.0.5359.98","Chrome/109.0.0.0","Chrome/109.0.1518.52","Chrome/109.0.1518.61",
		   "Chrome/109.0.1518.70","Chrome/109.0.5414.46","Chrome/109.0.5414.119","Chrome/110.0.0.0","Chrome/110.0.1587.50","Chrome/110.0.1587.57","Chrome/110.0.1587.63","Chrome/110.0.1587.69","Chrome/110.0.5481.30","Chrome/110.0.5481.78","Chrome/110.0.5481.100","Chrome/110.0.5481.178",
		   "Chrome/110.0.5481.192","Chrome/111.0.0.0","Chrome/111.0.1661.54","Chrome/111.0.5532.0","Chrome/111.0.5532.2","Chrome/111.0.5563.8","Chrome/111.0.5563.19","Chrome/111.0.5563.64","Chrome/111.0.5563.65","Chrome/112.0.1722.34","Chrome/112.0.1722.39","Chrome/112.0.1722.48","Chrome/112.0.5596.2",
		   "Chrome/112.0.5614.0","Chrome/112.0.5615.20","Chrome/112.0.5615.49","Chrome/112.0.5615.50","Chrome/112.0.5615.87","Chrome/112.0.5615.121","Chrome/112.0.5615.165","Chrome/113.0.0.0","Chrome/113.0.1774.35","Chrome/113.0.1774.57","Chrome/113.0.5672.64","Chrome/114.0.1823.37","Chrome/114.0.1823.43",
           "Chrome/114.0.1823.55","Chrome/114.0.1823.67","Chrome/114.0.1823.82","Chrome/114.0.5735.91","Chrome/114.0.5735.133","Chrome/115.0.1901.203","Chrome/115.0.5790.24","Chrome/115.0.5790.98","Chrome/116.0.5845.0","Chrome/115.0.6099.71","Chrome/116.0.0.0","Chrome/116.0.5005.0","Chrome/118.0.0.0",
		   "Chrome/119.0.6045.214","Chrome/120","Chrome/120.0.0.0","Chrome/122.0.6261.94","Chrome/123.0.0.0","Chrome/116.0.1938.76","Chrome/116.0.5845.82","Chrome/117.0.2045.41","Chrome/117.0.5938.60","Chrome/117.0.5938.132","Chrome/117.0.5938.149","Chrome/118.0.0.0","Chrome/119.0.2151.72",
		   "Chrome/119.0.6045.9","Chrome/119.0.6045.9","Chrome/119.0.6045.123","Chrome/119.0.6045.159","Chrome/119.0.6045.199","Chrome/120.0.0.0.0","Chrome/120.0.0.0","Chrome/120.0.2210.91","Chrome/120.0.6099.28","Chrome/120.0.6099.109","Chrome/120.0.0.0","Chrome/123.0.0.0","Chrome/124.0.6367.82","Chrome/135.0.0.0",
           "Chrome/136.0.0.0","Chrome/146.0.0.0","Chrome/120.0.6099.129","Chrome/120.0.6099.939","Chrome/121.0.0.0","Chrome/121.0.0.0","Chrome/121.0.2277.106","Chrome/121.0.6167.0","Chrome/121.0.6167.57","Chrome/121.0.6167.85","Chrome/121.0.6167.184","Chrome/122.0.2365.52","Chrome/122.0.2365.66",
		   "Chrome/122.0.2365.92","Chrome/122.0.6261.57","Chrome/122.0.6261.94","Chrome/123.0.2420.65","Chrome/123.0.6312.0","Chrome/123.0.6312.4","Chrome/123.0.6312.105","Chrome/123.0.6312.86","Chrome/124.0.0.0","Chrome/124.0.6367.155","Chrome/124.0.6367.207","Chrome/125.0.0.0","Chrome/125.0.6422.60",
		   "Chrome/125.0.6422.141","Chrome/125.0.6422.176","Chrome/126.0.6478.55","Chrome/124.0.0.0","Chrome/124.0.2478.67","Chrome/124.0.6367.78","Chrome/124.0.6367.91","Chrome/124.0.6367.92","Chrome/124.0.6367.118","Chrome/125.0.0","Chrome/125.0.2535.85","Chrome/125.0.2535.92","Chrome/125.0.6422.26",
		   "Chrome/125.0.6422.60","Chrome/126.0.0.0","Chrome/126.0.2592.68","Chrome/126.0.2592.87","Chrome/126.0.6478.61","Chrome/126.0.6478.126","Chrome/126.0.6478.128","Chrome/126.0.6478.182","Chrome/126.0.6478.126","Chrome/127.0.6533.17","Chrome/127.0.6533.72","Chrome/118.0.0.0","Chrome/128.0.6613.36",
		   "Chrome/129.0.0.0","Chrome/129.0.6668.29","Chrome/129.0.6668.58","Chrome/130.0.6723.69","Chrome/127.0.0.0","Chrome/127.0.0.1","Chrome/127.0.2651.86","Chrome/127.0.2651.98","Chrome/127.0.6533.17","Chrome/127.0.6533.73","Chrome/127.0.6533.89","Chrome/127.0.6533.99","Chrome/127.0.6533.100",
           "Chrome/127.0.6533.119","Chrome/127.0.6533.122","Chrome/127.0.6533","Chrome/128.0.0.0","Chrome/128.0.6613.18","Chrome/128.0.6613.84","Chrome/128.0.6613.120","Chrome/128.0.6613.138","Chrome/129.0.0.0","Chrome/129.0.6668.29","Chrome/129.0.6668.59","Chrome/129.0.6668.71","Chrome/129.0.6668.71",
		   "Chrome/129.0.6668.90","Chrome/129.0.6668.101","Chrome/130.0.6723.70","Chrome/130.0.6723.117","Chrome/130.0.6778.70","Chrome/131.0.0.0","Chrome/132.0.6834.110","Chrome/133.0.0.0","Chrome/133.0.6943.53","Chrome/134.0","Chrome/134.0.0","Chrome/134.0.0.0","Chrome/134.0.6998.88","Chrome/135.0.0",
           "Chrome/131.0.6778.86","Chrome/131.0.6778.140","Chrome/131.0.6778.265","Chrome/132.0.6834.111","Chrome/133.0.6943.60","Chrome/133.0.6943.127","Chrome/134.0.6998.36","Chrome/134.0.6998.89","Chrome/134.0.6998.118","Chrome/135.0.0.0","Chrome/136.0.0.0","Chrome/142.0.0.0","Chrome/144.0.0.0",
		   "Chrome/145.0.0.0","Chrome/146.0.0.0","Chrome/150.0.0.0","Chrome/94.3.8","Chrome/42.5.9","Chrome/120.0.0.0","Chrome/135.0.7049.42","Chrome/135.0.7049.96","Chrome/136.0.7103.93","Chrome/136.0.7103.114","Chrome/136.0.7103.59","Chrome/136.0.7103.92","Chrome/136.0.7103.113","Chrome/137.0.7151.55",
		   "Chrome/137.0.7151.68","Chrome/137.0.7151.103","Chrome/137.0.7151.119","Chrome/138.0.7204.49","Chrome/103.0.5060.66","Chrome/138.0.7204.92","Chrome/138.0.7204.96","Chrome/138.0.7204.157","Chrome/138.0.7204.168","Chrome/138.0.7204.183","Chrome/138.0.7194.0","Chrome/138.0.7194.0","Chrome/138.0.7194.0",
		   "Chrome/138.0.7204.97","Chrome/141.0.7340.0","Chrome/141.0.7376.0","Chrome/141.0.7390.55","Chrome/142.0.7416.0","Chrome/142.0.7444.60","Chrome/142.0.7444.135","Chrome/142.0.7444.163","Chrome/142.0.7444.176","Chrome/1143.0.7499.193","Chrome/143.0.7499.147","Chrome/143.0.7499.170",
		   "Chrome/143.0.7499.110","Chrome/143.0.7499.41","Chrome/144.0.7559.110","Chrome/144.0.7559.97","Chrome/144.0.7559.60","Chrome/144.0.7559.133","Chrome/144.0.7547.0","Chrome/144.0.7559.133","Chrome/145.0.7632.117","Chrome/145.0.7632.110","Chrome/145.0.7632.76","Chrome/147.0.7727.56",
           "Chrome/147.0.7683.0","Chrome/148.0.7730.0","Chrome/148.0.7778.97","Chrome/148.0.7778.168","Chrome/149.0.7814.0","Chrome/149.0.7814.0","Chrome/149.0.7827.54","Chrome/149.0.7827.103","Chrome/149.0.7827.115","Chrome/149.0.7827.156","Chrome/149.0.7827.197","Chrome/149.0.7827.201","Chrome/150.0.7871.47",
		   "Chrome/150.0.7871.101","Chrome/151.0.7910.0","Chrome/151.0.7922.72","Chrome/151.0.7922.76","Chrome/151.0.7922.109","Chrome/151.0.7922.138","Chrome/151.0.7922.170",

           //Headlesschrome updated 2600905
           "HeadlessChrome/0.2.149","HeadlessChrome/0.3.154","HeadlessChrome/0.4.154","HeadlessChrome/1.0.154","HeadlessChrome/2.0.172","HeadlessChrome/3.0.195","HeadlessChrome/4.0.249","HeadlessChrome/4.1.249","HeadlessChrome/6.0.472","HeadlessChrome/7.0.517","HeadlessChrome/7.0.517.441","HeadlessChrome/8.0.552",
           "HeadlessChrome/9.0.597","HeadlessChrome/10.0.648","HeadlessChrome/11.0.696","HeadlessChrome/12.0.742.91","HeadlessChrome/12.0.742.112","HeadlessChrome/12.0.7421","HeadlessChrome/13.0.782.215","HeadlessChrome/13.0.7821","HeadlessChrome/15.0.87414.0.8351","HeadlessChrome/15.0.1901.200",
           "HeadlessChrome/16.0.912.63","HeadlessChrome/17.0.963.33","HeadlessChrome/17.0.963.56","HeadlessChrome/17.0.963.65","HeadlessChrome/18.0.865.0","HeadlessChrome/18.0.1025.162","HeadlessChrome/19.0.1084.46","HeadlessChrome/19.0.1084.52","HeadlessChrome/20.0.1132.39","HeadlessChrome/27.0.1453.94",
           "HeadlessChrome/28.0.1500","HeadlessChrome/29.0.1547.57","HeadlessChrome/30.0.1599.66","HeadlessChrome/34.0.824.0","HeadlessChrome/34.0.1847.114","HeadlessChrome/43.0.845.0","HeadlessChrome/45.0.2454.94","HeadlessChrome/46.0.2490.80","HeadlessChrome/47.0.2283.102","HeadlessChrome/48.0.861.0",
           "HeadlessChrome/48.0.2564.97","HeadlessChrome/49.0.2623.75","HeadlessChrome/50.0.2661","HeadlessChrome/50.0.2661.102","HeadlessChrome/50.0.3232.292","HeadlessChrome/51.0.870.0","HeadlessChrome/51.0.2160.381","HeadlessChrome/51.0.2329.290","HeadlessChrome/51.0.2704.84","HeadlessChrome/52.0.2315.144",
           "HeadlessChrome/52.0.2743.116","HeadlessChrome/52.0.3133.374","HeadlessChrome/52.0.3748.297","HeadlessChrome/53.0.2785.116","HeadlessChrome/54.0.1107.38","HeadlessChrome/54.0.2840.71","HeadlessChrome/55.0.2660.238","HeadlessChrome/55.0.2883.75","HeadlessChrome/56.0.2924.87","HeadlessChrome/57.0.2987.133",
           "HeadlessChrome/58.0.3029.96","HeadlessChrome/60.0.3112.78","HeadlessChrome/60.0.3112.90","HeadlessChrome/60.0.3112.107","HeadlessChrome/61.0.3163.79","HeadlessChrome/62.0.3202.75","HeadlessChrome/63.0.3239.108","HeadlessChrome/64.0.3282.140","HeadlessChrome/65.0.3325.181","HeadlessChrome/66.0.3359.158",
           "HeadlessChrome/67.0.3396.79","HeadlessChrome/68.0.3440.84","HeadlessChrome/68.0.3440.106","HeadlessChrome/69.0.3497.92","HeadlessChrome/70.0.3538.77","HeadlessChrome/71","HeadlessChrome/70.0.3538.102","HeadlessChrome/71.0.3578.80","HeadlessChrome/74.0.3729","HeadlessChromee/74.0.3729.169",
           "HeadlessChrome/75.0.3770.80","HeadlessChrome/76.0.3809.100","HeadlessChrome/77.0.3844.0","HeadlessChrome/77.0.3865.116","HeadlessChrome/78.0.3904.70","HeadlessChrome/78.0.3904.97","HeadlessChrome/79.0.309.11","HeadlessChrome/79.0.309.30","HeadlessChrome/79.0.309.65","HeadlessChrome/79.0.309.68",
           "HeadlessChrome/79.0.309.71","HeadlessChrome/79.0.3945.0","HeadlessChrome/79.0.3945.88","HeadlessChrome/79.0.3945.130","HeadlessChrome/80.0.361.45","HeadlessChrome/80.0.361.48","HeadlessChrome/80.0.361.62","HeadlessChrome/80.0.361.109","HeadlessChrome/80.0.3987.0","HeadlessChrome/80.0.3987.132",
           "HeadlessChrome/80.0.3987.149","HeadlessChrome/80.0.3987.163","HeadlessChrome/81.0.416.34","HeadlessChrome/81.0.416.58","HeadlessChrome/81.0.416.62","HeadlessChrome/81.0.416.77","HeadlessChrome/81.0.4044.92","HeadlessChrome/83.0.478.37","HeadlessChrome/83.0.478.58","HeadlessChrome/83.0.478.64",
           "HeadlessChrome/83.0.4103.0","HeadlessChrome/83.0.4103.61","HeadlessChrome/83.0.4103.116","HeadlessChrome/84.0.522.40","HeadlessChrome/84.0.522.52","HeadlessChrome/84.0.522.58","HeadlessChrome/84.0.522.61","HeadlessChrome/84.0.4147.1","HeadlessChrome/84.0.4147.105","HeadlessChrome/84.0.4147.135",
           "HeadlessChrome/85.0.564.44","HeadlessChrome/85.0.4182.0","HeadlessChrome/85.0.4183.102","HeadlessChrome/85.0.4183.121","HeadlessChrome/86.0.622.48","HeadlessChrome/86.0.622.56","HeadlessChrome/86.0.622.61","HeadlessChrome/86.0.622.68","HeadlessChrome/86.0.4240.75","HeadlessChrome/87.0.664.47",
           "HeadlessChrome/87.0.664.52","HeadlessChrome/87.0.4280.14","HeadlessChrome/87.0.4280.88","HeadlessChrome/88.0.4298.0","HeadlessChrome/88.0.4324.0","HeadlessChrome/88.0.4324.186","HeadlessChrome/89.0.774.45","HeadlessChrome/89.0.774.50","HeadlessChrome/89.0.4389.86","HeadlessChrome/89.0.4389.90",
           "HeadlessChrome/90.0.818.42","HeadlessChrome/90.0.818.56","HeadlessChrome/90.0.818.62","HeadlessChrome/90.0.4430.72","HeadlessChrome/90.0.4430.85","HeadlessChrome/90.0.4430.85","HeadlessChrome/90.0.4430.85","HeadlessChrome/91.0.864.53","HeadlessChrome/91.0.864.70","HeadlessChrome/91.0.864.71",
           "HeadlessChrome/91.0.4472.77","HeadlessChrome/91.0.4472.114","HeadlessChrome/91.0.4472.124","HeadlessChrome/92.0.902.55","HeadlessChrome/92.0.4512.0","HeadlessChrome/92.0.4515.107","HeadlessChrome/92.0.4515.159","HeadlessChrome/93.0.4577.0","HeadlessChrome/93.0.4577.82","HeadlessChrome/94.0.992.31",
           "HeadlessChrome/94.0.992.37","HeadlessChrome/94.0.992.50","HeadlessChrome/94.0.4606.61","HeadlessChrome/95.0.1020.53","HeadlessChrome/95.0.4638.54","HeadlessChrome/96.0.1054.41","HeadlessChrome96.0.1054.53","HeadlessChrome/96.0.4641.0","HeadlessChrome/96.0.4664.45","HeadlessChrome/96.0.4664.110",
           "HeadlessChrome/97.0.1072.55","HeadlessChrome/97.0.1072.62","HeadlessChrome/97.0.1072.69","HeadlessChrome/97.0.4280.67","HeadlessChrome/97.0.4680.0","HeadlessChrome/98.0.1108.6","HeadlessChrome/98.0.1108.43","HeadlessChrome/98.0.4758.80","HeadlessChrome/99.0.1150.46","HeadlessChrome/100.0.1185.36",
           "HeadlessChrome/101.0.1210.4","HeadlessChrome/101.0.4951.41","HeadlessChrome/101.0.4951.64","HeadlessChrome/101.0.4951.67","HeadlessChrome/102.0.1245.30","HeadlessChrome/102.0.1245.44","HeadlessChrome/102.0.5005.63","HeadlessChrome/103.0.0.0","HeadlessChrome/103.0.1264.49","HeadlessChrome/104.0.0.0",
           "HeadlessChrome/104.0.0.1","HeadlessChrome/104.0.1293.47","HeadlessChrome/104.0.1293.54","HeadlessChrome/104.0.5112.79","HeadlessChrome/104.0.5112.79","HeadlessChrome104.0.5112.97","HeadlessChrome/104.0.5112.102","HeadlessChrome/105.0.1343.42","HeadlessChrome/105.0.1343.50","HeadlessChrome/105.0.5195.52",
           "HeadlessChrome/105.0.5195.125","HeadlessChrome/106.0.0.0","HeadlessChrome/106.0.1370.34","HeadlessChrome/106.0.1370.47","HeadlessChrome/106.0.5249.30","HeadlessChrome/106.0.5249.62","HeadlessChrome/106.0.5249.91","HeadlessChrome/106.0.5249.119","HeadlessChrome/107.0.0.0","HeadlessChrome/107.0.1418.24",
           "HeadlessChrome/107.0.1418.52","HeadlessChrome/107.0.1418.62","HeadlessChrome/107.0.5304.63","HeadlessChrome/107.0.5304.106","HeadlessChrome/107.0.5304.110","HeadlessChrome/107.0.5304.121","HeadlessChrome/108.0.0.0","HeadlessChrome/108.0.1462.46","HeadlessChrome/108.0.1462.76","HeadlessChrome/108.0.5359.94",
           "HeadlessChrome/108.0.5359.98","HeadlessChrome/109.0.0.0","HeadlessChrome/109.0.1518.52","HeadlessChrome/109.0.1518.61","HeadlessChrome/109.0.1518.70","HeadlessChrome/109.0.5414.46","HeadlessChrome/109.0.5414.119","HeadlessChrome/110.0.0.0","HeadlessChrome/110.0.1587.50","HeadlessChrome/110.0.1587.57",
           "HeadlessChrome/110.0.1587.63","HeadlessChrome/110.0.1587.69","HeadlessChrome/110.0.5481.30","HeadlessChrome/110.0.5481.78","HeadlessChrome/110.0.5481.100","HeadlessChrome/110.0.5481.178","HeadlessChrome/110.0.5481.192","HeadlessChrome/111.0.0.0","HeadlessChrome/111.0.1661.54","HeadlessChrome/111.0.5532.0",
           "HeadlessChrome/111.0.5532.2","HeadlessChrome/111.0.5563.8","HeadlessChrome/111.0.5563.19","HeadlessChrome/111.0.5563.64","HeadlessChrome/111.0.5563.65","HeadlessChrome/112.0.1722.34","HeadlessChrome/112.0.1722.39","HeadlessChrome/112.0.1722.48","HeadlessChrome/112.0.5596.2","HeadlessChrome/112.0.5614.0",
           "HeadlessChrome/112.0.5615.20","HeadlessChrome/112.0.5615.49","HeadlessChrome/112.0.5615.50","HeadlessChrome/112.0.5615.87","HeadlessChrome/112.0.5615.121","HeadlessChrome/112.0.5615.165","HeadlessChrome/113.0.0.0","HeadlessChrome/113.0.1774.35","HeadlessChrome/113.0.1774.57","HeadlessChrome/113.0.5672.64",
           "HeadlessChrome/114.0.1823.37","HeadlessChrome/114.0.1823.43","HeadlessChrome/114.0.1823.55","HeadlessChrome/114.0.1823.67","HeadlessChrome/114.0.1823.82","HeadlessChrome/114.0.5735.91","HeadlessChrome/114.0.5735.133","HeadlessChrome/115.0.1901.203","HeadlessChrome/115.0.5790.24","HeadlessChrome/115.0.5790.98",
           "HeadlessChrome/116.0.5845.0","HeadlessChrome/116.0.1938.76","HeadlessChrome/116.0.5845.82","HeadlessChrome/117.0.2045.41","HeadlessChrome/117.0.5938.60","HeadlessChrome/117.0.5938.132","HeadlessChrome/117.0.5938.149","HeadlessChrome/118.0.0.0","HeadlessChrome/119.0.2151.72","HeadlessChrome/119.0.6045.9",
           "HeadlessChrome/119.0.6045.9","HeadlessChrome/119.0.6045.123","HeadlessChrome/119.0.6045.159","HeadlessChrome/119.0.6045.199","HeadlessChrome/120.0.0.0.0","HeadlessChrome/120.0.0.0","HeadlessChrome/120.0.2210.91","HeadlessChrome/120.0.6099.28","HeadlessChrome/120.0.6099.109","HeadlessChrome/120.0.6099.129",
           "HeadlessChrome/120.0.6099.939","HeadlessChrome/121.0.0.0","HeadlessChrome/121.0.0.0","HeadlessChrome/121.0.2277.106","HeadlessChrome/121.0.6167.0","HeadlessChrome/121.0.6167.57","HeadlessChrome/121.0.6167.85","HeadlessChrome/121.0.6167.184","HeadlessChrome/122.0.2365.52","HeadlessChrome/122.0.2365.66",
           "HeadlessChrome/122.0.2365.92","HeadlessChrome/122.0.6261.57","HeadlessChrome/122.0.6261.94","HeadlessChrome/123.0.2420.65","HeadlessChrome/123.0.6312.0","HeadlessChrome/123.0.6312.4","HeadlessChrome/123.0.6312.105","HeadlessChrome/124.0.0.0","HeadlessChrome/124.0.2478.67","HeadlessChrome/124.0.6367.78",
           "HeadlessChrome/124.0.6367.91","HeadlessChrome/124.0.6367.92","HeadlessChrome/124.0.6367.118","HeadlessChrome/125.0.0","HeadlessChrome/125.0.2535.85","HeadlessChrome/125.0.2535.92","HeadlessChrome/125.0.6422.26","HeadlessChrome/125.0.6422.60","HeadlessChrome/126.0.0.0","HeadlessChrome/126.0.2592.68",
           "HeadlessChrome/126.0.2592.87","HeadlessChrome/126.0.6478.61","HeadlessChrome/126.0.6478.126","HeadlessChrome/126.0.6478.128","HeadlessChrome/126.0.6478.182","HeadlessChrome/127.0.0.0","HeadlessChrome/127.0.0.1","HeadlessChrome/127.0.2651.86","HeadlessChrome/127.0.2651.98","HeadlessChrome/127.0.6533.17",
           "HeadlessChrome/127.0.6533.73","HeadlessChrome/127.0.6533.89","HeadlessChrome/127.0.6533.99","HeadlessChrome/127.0.6533.100","HeadlessChrome/127.0.6533.119","HeadlessChrome/127.0.6533.122","HeadlessChrome/127.0.6533","HeadlessChrome/128.0.0.0","HeadlessChrome/128.0.6613.18","HeadlessChrome/128.0.6613.84",
           "HeadlessChrome/128.0.6613.120","HeadlessChrome/128.0.6613.138","HeadlessChrome/129.0.0.0","HeadlessChrome/129.0.6668.29","HeadlessChrome/129.0.6668.59","HeadlessChrome/129.0.6668.71","HeadlessChrome/129.0.6668.71","HeadlessChrome/129.0.6668.90","HeadlessChrome/129.0.6668.101","HeadlessChrome/130.0.6723.70",
           "HeadlessChrome/130.0.6723.117","HeadlessChrome/130.0.6778.70","HeadlessChrome/131.0.6778.86","HeadlessChrome/131.0.6778.140","HeadlessChrome/131.0.6778.265","HeadlessChrome/132.0.6834.111","HeadlessChrome/133.0.6943.60","HeadlessChrome/133.0.6943.127","HeadlessChrome/134.0.6998.36","HeadlessChrome/134.0.6998.89",
           "HeadlessChrome/134.0.6998.118","HeadlessChrome/135.0.7049.42","HeadlessChrome/135.0.7049.96","HeadlessChrome/136.0.7103.93","HeadlessChrome/136.0.7103.114","HeadlessChrome/136.0.7103.59","HeadlessChrome/136.0.7103.92","HeadlessChrome/136.0.7103.113","HeadlessChrome/137.0.7151.55","HeadlessChrome/137.0.7151.68",
           "HeadlessChrome/137.0.7151.103","HeadlessChrome/137.0.7151.119","HeadlessChrome/138.0.7194.0","HeadlessChrome/138.0.7194.0","HeadlessChrome/138.0.7204.97","HeadlessChrome/141.0.7340.0","HeadlessChrome/141.0.7376.0","HeadlessChrome/141.0.7390.55","HeadlessChrome/142.0.7416.0","HeadlessChrome/138.0.7204.49",
           "HeadlessChrome/138.0.7204.92","HeadlessChrome/138.0.7204.96","HeadlessChrome/138.0.7204.157","HeadlessChrome/138.0.7204.168","HeadlessChrome/138.0.7204.183","HeadlessChrome/138.0.7194.0","HeadlessChrome/142.0.7444.60","HeadlessChrome/142.0.7444.135","HeadlessChrome/142.0.7444.163","HeadlessChrome/142.0.7444.176",
           "HeadlessChrome/1143.0.7499.193","HeadlessChrome/143.0.7499.147","HeadlessChrome/143.0.7499.170","HeadlessChrome/143.0.7499.110","HeadlessChrome/143.0.7499.41","HeadlessChrome/144.0.7559.110","HeadlessChrome/144.0.7559.97","HeadlessChrome/144.0.7559.60","HeadlessChrome/144.0.7559.133","HeadlessChrome/144.0.7547.0",
           "HeadlessChrome/144.0.7559.133","HeadlessChrome/145.0.7632.117","HeadlessChrome/145.0.7632.110","HeadlessChrome/145.0.7632.76","HeadlessChrome/147.0.7727.56","HeadlessChrome/147.0.7683.0","HeadlessChrome/148.0.7730.0","HeadlessChrome/148.0.7778.97","HeadlessChrome/148.0.7778.168","HeadlessChrome/149.0.7814.0",
           "HeadlessChrome/149.0.7814.0","HeadlessChrome/149.0.7827.54","HeadlessChrome/149.0.7827.103","HeadlessChrome/149.0.7827.115","HeadlessChrome/149.0.7827.156","HeadlessChrome/149.0.7827.197","HeadlessChrome/149.0.7827.201","HeadlessChrome/150.0.0.0","HeadlessChrome/150.0.7871.47","HeadlessChrome/150.0.7871.101",
           "HeadlessChrome/151.0.7910.0","HeadlessChrome/151.0.7922.72","HeadlessChrome/151.0.7922.76","HeadlessChrome/151.0.7922.109","HeadlessChrome/151.0.7922.138","HeadlessChrome//151.0.7922.170",

           //Edge Updated 260825
           "Edg/16.16299","Edg/79.0.309.14","Edg/79.0.309.63","Edge/87.0.0.0","Edg/80.0.361.9","Edg/81.0.416.68","Edg/.0.664.75","Edg/.0.705.18","Edg/88.0.705.50","Edg/89.0.774.18","Edge/90.0.0.0","Edg/89.0.774.48","Edg/90.0.818.8","Edg/90.0.818.39","Edg/91.0.864.11","Edg/91.0.864.37","Edg/92.0.902.9","Edg/92.0.902.55","Edg/93.0.961.11",
           "Edg/93.0.961.38","Edg/94.0.992.9","Edg/94.0.992.31","Edg/95.0.1020.9","Edg/95.0.1020.30","Edg/96.0.1054.8","Edg/96.0.1054.29","Edg/97.0.1072.21","Edg/97.0.1072.55","Edg/98.0.1108.23","Edg/98.0.1108.43","Edg/99.0.1150.11","Edg/99.0.1150.30","Edg/100.0.1185.10","Edg/100.0.1185.29","Edg/101.0.1210.10",
           "Edg/101.0.1210.32","Edg/101.0.1210.47","Edg/102.0.1245.7","Edg/102.0.1245.30","Edg/103.0.1264.13","Edg/103.0.1264.37","Edg/104.0.1293.14","Edg/104.0.1293.47","Edg/105.0.1343.7","Edg/105.0.1343.25","Edg/106.0.1370.15","Edg/106.0.1370.34","Edg/107.0.1418.8","Edg/107.0.1418.24","Edg/107.0.1418.26",
           "Edg/107.0.1418.35","Edg/108.0.1462.15","Edg/108.0.1462.42","Edg/109.0.1518.14","Edg/109.0.1518.49","Edg/110.0.1587.17","Edg/110.0.1587.41","Edg/111.0.1661.4","Edg/111.0.1661.15","Edg/111.0.1661.41","Edg/112.0.1722.11","Edg/112.0.1722.34","Edg/112.0.1722.68","Edg/113.0.1774.3","Edg/113.0.1774.9",
           "Edg/114.0.1823.11","Edg/114.0.1823.37","Edg/115.0.1901.7","Edg/115.0.1901.183","Edg/115.0.1901.200","Edg/115.0.1901.203","Edg/116.0.1938.29","Edg/116.0.1938.54","Edg/117.0.2045.9","Edg/117.0.2045.31","Edg/117.0.2045.41","Edg/118.0.2088.11","Edg/118.0.2088.46","Edg/119.0.2151.12","Edg/119.0.2151.44",
           "Edg/118.0.2088.69","Edg/119.0.2151.72","Edg/120.0.1054.29","Edg/120.0.2210.7","Edg/120.0.2210.61","Edg/120.0.2210.91","Edg/121.0.0.0","Edg/121.0.2277.4","Edg/121.0.2277.83","Edg/121.0.2277.106","Edg/122.0.0.0","Edg/122.0.2365.8","Edg/122.0.2365.52","Edg/122.0.2365.66","Edg/122.0.2365.92",
           "Edg/123.0.2420.10","Edg/123.0.2420.53","Edg/123.0.2420.65","Edg/124.0.2478.10","Edg/124.0.2478.51","Edg/124.0.2478.67","Edg/125.0.2535.13","Edg/125.0.2535.51","Edg/125.0.2535.85","Edg/125.0.2535.92","Edg/126.0.2592.13","Edg/126.0.2592.56","Edg/126.0.2592.68","Edg/126.0.2592.87","Edg/127.0.2651.74",
           "Edg/127.0.2651.86","Edg/127.0.2651.98","Edg/128.0.2739.5","Edg/128.0.2739.42","Edg/128.0.2739.54","Edg/128.0.2739.63","Edg/128.0.2739.67","Edg/129","Edg/129.0","Edg/129.0.2792.12","Edg/129.0.2792.52","Edg/130.0.2849.5","Edg/130.0.2849.46","Edg/130.0.2849.56","Edg/131.0.2903.51","Edg/131.0.2903.70",
           "Edg/131.0.2903.146","Edg/132.0.2957.127","Edg/134.0.0.0","Edg/133.0.3065.59","Edg/133.0.3065.69","Edg/133.0.3065.82","Edg/133.0.3065.92","Edg/134.0.3124.62","Edg/134.0.3124.85","Edg/135.0.0.0","Edg/135.0.3179.54","Edg/135.0.3179.66","Edg/136.0.3240.76","Edg/137.0.3296.62","Edg/137.0.3296.68","Edg/138.0.3351.77",
           "Edg/138.0.3351.83","Edg/138.0.3351.95","Edg/138.0.3351.109","Edg/139.0.3405.86","Edg/139.0.3405.111","Edg/140.0.3485.54","Edg/141.0.3537.71","Edg/141.0.3537.99","Edg/142.0.3595.53","Edg/142.0.3595.65","Edg/142.0.3595.80","Edg/142.0.3595.90","Edg/142.0.3595.94","Edg/143.0.3650.96","Edg/143.0.3650.80",
           "Edg/143.0.3650.139","Edg/143.0.3650.75","Edg/143.0.3650.66","Edg/144.0.3719.115","Edg/144.0.3719.128","Edg/144.0.3719.10","Edg/144.0.3719.92","Edg/144.0.3719.82","Edg/145.0.3800.58","Edg/145.0.3800.65","Edg/145.0.3800.70","Edg/145.0.3800.82","Edg/145.0.3800.97","Edg/146.0.3856.97","Edg/146.0.3856.109",
           "Edg/146.0.3856.78","Edg/146.0.3856.84","Edg/146.0.3856.62","Edg/146.0.3856.72","Edg/147.0.3912.98","Edg/147.0.3912.86","Edg/147.0.3912.60","Edg/147.0.3912.72","Edg/148.0.3967.54","Edg/148.0.3967.70","Edg/148.0.3967.83","Edg/148.0.3967.96","Edg/149.0.4022.52","Edg/149.0.4022.62","Edg/149.0.4022.69","Edg/149.0.4022.80",
           "Edg/149.0.4022.96","Edg/150.0.4078.48","Edg/150.0.4078.65","Edg/151.0.4129.101","Edg/151.0.4129.93","Edg/151.0.4129.78","Edg/151.0.4129.72","Edg/151.0.4129.59","Edg/150.0.4078.105","Edg/150.0.4078.99","Edg/150.0.4078.83","Edg/150.0.4078.65",
           
           //Firefox Updaterad 260825
           "Firefox/3.6","Firefox/3.6.1","Firefox/3.6.19","Firefox/4.0","Firefox/7.0","Firefox/10.0","Firefox/12.0","Firefox/13.0","Firefox/15.0.1","Firefox/16.0.1","Firefox/30","Firefox/41.0","Firefox/42.0.0","Firefox/46.0","Firefox/46.0.1",
           "Firefox/46.8","Firefox/47.0","Firefox/47.2","Firefox/48.0","Firefox/48.0.1","Firefox/48.0.2","Firefox/49.0","Firefox/49.5","Firefox/49.6","Firefox/50.0","Firefox/50.0.1","Firefox/50.1.0","Firefox/50.7","Firefox/50.9","Firefox/51.0",
           "Firefox/51.0.1","Firefox/51.1","Firefox/51.4","Firefox/51.7","Firefox/52.0","Firefox/52.0.1","Firefox/52.0.2","Firefox/52.3","Firefox/52.8","Firefox/53.0","Firefox/53.0.3","Firefox/53.2","Firefox/54.0","Firefox/54.1","Firefox/55.0",
           "Firefox/55.0.2","Firefox/55.0.3","Firefox/55.8","Firefox/55.9","Firefox/56.0","Firefox/56.0.1","Firefox/57.0","Firefox/57.0.1","Firefox/57.0.4","Firefox/57.9","Firefox/58.0","Firefox/58.1","Firefox/59.0","Firefox/59.0.3","Firefox/59.4",
           "Firefox/59.7","Firefox/60.0.1","Firefox/60.1","Firefox/60.3","Firefox/60.9","Firefox/61.0","Firefox/61.0.2","Firefox/61.9","Firefox/62.0","Firefox/62.3","Firefox/62.6","Firefox/64.0","Firefox/64.1","Firefox/64.8","Firefox/65.0","Firefox/65.2",
           "Firefox/66.4","Firefox/66.9","Firefox/67.0","Firefox/67.0.3","Firefox/68.0","Firefox/68.0.2","Firefox/68.6","Firefox/69.0","Firefox/69.0.1","Firefox/69.1","Firefox/69.2","Firefox/69.3","Firefox/69.8","Firefox/70.0","Firefox/70.0.1",
           "Firefox/71.0","Firefox/71.8","Firefox/71.9","Firefox/72.0","Firefox/72.0.1","Firefox/72.4","Firefox/73.0","Firefox/73.1","Firefox/73.8","Firefox/74.0","Firefox/74.5","Firefox/75.0","Firefox/76.0","Firefox/76.0.1","Firefox/77.0","Firefox/77.0.1",
           "Firefox/78.0","Firefox/78.0.1","Firefox/78.0.2","Firefox/78.1.0","Firefox/78.2.0","Firefox/78.3.0","Firefox/78.3.1","Firefox/78.4.0","Firefox/78.4.1","Firefox/78.5.0","Firefox/78.6.0","Firefox/78.6.1","Firefox/78.7.0","Firefox/78.7.1",
           "Firefox/78.8.0","Firefox/78.9.0","Firefox/78.10.0","Firefox/78.10.1","Firefox/78.11.0","Firefox/78.12.0","Firefox/78.13.0","Firefox/78.14.0","Firefox/78.15.0","Firefox/79.0","Firefox/80","Firefox/81.0","Firefox/81.0.1","Firefox/82.0",
           "Firefox/82.0.1","Firefox/83.0","Firefox/84.0","Firefox/84.0.1","Firefox/84.0.2","Firefox/85.0","Firefox/85.0.2","Firefox/86.0","Firefox/86.0.1","Firefox/87.0","Firefox/88.0","Firefox/88.0.1","Firefox/89.0","Firefox/89.0.1","Firefox/89.0.2",
           "Firefox/90.0","Firefox/90.0.1","Firefox/90.0.2","Firefox/91.0","Firefox/91.0.1","Firefox/91.0.2","Firefox/92.0","Firefox/92.0.1","Firefox/93.0","Firefox/94.0","Firefox/94.0.1","Firefox/94.0.2","Firefox/95.0","Firefox/95.0.1","Firefox/95.0.2",
           "Firefox/96.0","Firefox/96.0.1","Firefox/96.0.2","Firefox/96.0.3","Firefox/97.0","Firefox/97.0.1","Firefox/97.0.2","Firefox/98.0.1","Firefox/98.0.2","Firefox/99.0.1","Firefox/100","Firefox/100.0","Firefox/100.0.1","Firefox/100.0.2","Firefox/101.0",
           "Firefox/101.0.1","Firefox/102.0","Firefox/103.0","Firefox/103.0.2","Firefox/104.0","Firefox/104.0.1","Firefox/105.0","Firefox/105.0.1","Firefox/105.0.2","Firefox/105.0.3","Firefox/106.0","Firefox/106.0.1","Firefox/106.0.2","Firefox/106.0.4",
           "Firefox/107.0","Firefox/108.0","Firefox/108.0.2","Firefox/109.0","Firefox/109.0.1","Firefox/110.0","Firefox/111.0","Firefox/111.0.1","Firefox/112.0","Firefox/112.0.1","Firefox/112.0.2","Firefox/113.0","Firefox/113.0.1","Firefox/113.0.2","Firefox/114.0",
           "Firefox/114.0.1","Firefox/114.0.2","Firefox/115.0","Firefox/115.0.1","Firefox/115.0.2","Firefox/116.0","Firefox/116.0.2","Firefox/116.0.3","Firefox/117.0","Firefox/117.0.1","Firefox/118.0","Firefox/118.0.1","Firefox/118.0.2","Firefox/119.0",
           "Firefox/119.0.1","Firefox/120.0","Firefox/120.0.1","Firefox/121.0","Firefox/121.0.1","Firefox/122.0","Firefox/122.0.1","Firefox/123.0","Firefox/123.0.1","Firefox/124.0","Firefox/124.0.2","Firefox/125.0.1","Firefox/125.0.2","Firefox/125.0.3",
           "Firefox/125.0","Firefox/127.02.", "Firefox/131.","Firefox/92.0.0.0","Firefox/29.2.9","Firefox/61.2.9 I","Firefox/126.0","Firefox/126.0.1","Firefox/127.0","Firefox/127.0.2","Firefox/128.0","Firefox/129.0","Firefox/129.0.1","Firefox/129.0.2",
           "Firefox/130.0","Firefox/130.0.1","Firefox/131.0","Firefox/131.0.2","Firefox/131.0.3","Firefox/132.0","Firefox/132.0.1","Firefox/132.0.2","Firefox/132.0.11","Firefox/133.0","Firefox/133.0.3","Firefox/134.0","Firefox/134.0.1","Firefox/134.0.2",
           "Firefox/135.0","Firefox/135.0.1","Firefox/136.0","Firefox/136.0.1","Firefox/136.0.2","Firefox/136.0.3","Firefox/136.0.4","Firefox/137.0","Firefox/137.0.1","Firefox/137.0.2","Firefox/138.0","Firefox/138.0.1","Firefox/138.0.3","Firefox/138.0.4",
           "Firefox/139.0","Firefox/139.0.1","Firefox/139.0.4","Firefox/140.0","Firefox/140.0.1","Firefox/140.0.2","Firefox/140.0.4","Firefox/140.1.0","Firefox/140.2.0","Firefox/140.3.0","Firefox/140.3.1","Firefox/140.4.0","Firefox/140.5.0","Firefox/141.0",
           "Firefox/141.0.2","Firefox/141.0.3","Firefox/142.0","Firefox/142.0.1","Firefox/143.0","Firefox/143.0.3","Firefox/143.0.4","Firefox/144.0","Firefox/144.0.2","Firefox/145.0.2","Firefox/147.0","Firefox/147.0.3","Firefox/148.0","Firefox/148.0.1",
           "Firefox/148.0.2","Firefox/150.0","Firefox/150.0","Firefox/150.0.2","Firefox/150.0.3","Firefox/151.0.0","Firefox/151.0.1","Firefox/151.0.2","Firefox/151.0.3","Firefox/151.0.4","Firefox/152.0.0","Firefox/152.0.1","Firefox/152.0.2","Firefox/152.0.3",
           "Firefox/152.0.4","Firefox/152.0.5","Firefox/152.0","Firefox/152.0.6","Firefox/153.0","Firefox/153.0.1","Firefox/153.0.3","Firefox/153.0.4",

           //Linux Android Updated 260826
           "Linux; Android 1.0","Linux; Android 1.1","Linux; Android 1.5","Linux; Android 1.6","Linux; Android 2.0","Linux; Android 2.1","Linux; Android 2.2",
           "Linux; Android 2.3","Linux; Android 3.0","Linux; Android 3.2","Linux; Android 4.0","Linux; Android 4.1","Linux; Android 4.3","Linux; Android 4.4","Linux; Android 5.0",
           "Linux; Android 6.0","Linux; Android 7.0","Linux; Android 7.1","Linux; Android 7.1.1","Linux; Android 8.0","Linux; Android 8.1",	
           "Linux; Android 9","Linux; Android 10","Linux; Android 10; K","Linux; Android 11","Linux; Android 12","Linux; Android 13","Linux; Android 14","Linux; Android 15","Linux; Android 16",

           //Linux browser patterns Updated 260825
           "Alpine Linux","AlmaLinux","Beautiful Soup",
		   "Linux scrapy","Linux x86","Linux i686","Linux i386","Linux x86_64","Linux amd64","Linux arm","Linux arm7","Linux aarch64","Ubuntu","Linux; U; en-US",
		   "Debian","Fedora","Fedora Linux","CentOS","Red Hat","openSUSE","Arch Linux","Mint","Gentoo","Selenium","Slackware","OpenBSD","Puppeteer","X11; U; Linux armv7",
           "Rocky Linux","Kali Linux","Xubuntu","Kubuntu","Lubuntu","Edubuntu","Xandros","Mandriva","Mageia","PCLinuxOS","Puppy Linux","Tiny Core","Linux; Ubuntu",
			            							
           //MacOS Updated 26086
           "Macintosh; Intel Mac OS X 1_5","Macintosh; Intel Mac OS X 3_6","Macintosh; Intel Mac OS X 10_10","Macintosh; Intel Mac OS X 10_13","Macintosh; Intel Mac OS X 10_13_1",
		   "Macintosh; Intel Mac OS X 10.15; rv:134.0","Macintosh; Intel Mac OS X 13.2; rv:126.0","Macintosh; Intel Mac OS X 10.15; rv:137.0","U; PPC","U; PPC","U; Intel","U; PPC",
           "Macintosh; Intel Mac OS X 10_13_2","Macintosh; Intel Mac OS X 10_13_3","Macintosh; Intel Mac OS X 10_13_4","Macintosh; Intel Mac OS X 10_13_5","Macintosh; Intel Mac OS X 10_13_6",
           "Macintosh; Intel Mac OS X 10_14","Macintosh; Intel Mac OS X 10_14_1","Macintosh; Intel Mac OS X 10_14_2","Macintosh; Intel Mac OS X 10_14_3","Macintosh; Intel Mac OS X 10_14_4",
           "Macintosh; Intel Mac OS X 10_14_5","Macintosh; Intel Mac OS X 10_14_6","Macintosh; Intel Mac OS X 10_15","Macintosh; Intel Mac OS X 10_15_1","Macintosh; Intel Mac OS X 10_15_2",
           "Macintosh; Intel Mac OS X 10_15_3","Macintosh; Intel Mac OS X 10_15_4","Macintosh; Intel Mac OS X 10_15_4","Macintosh; Intel Mac OS X 10_15_5","Macintosh; Intel Mac OS X 10_15_6",
           "Macintosh; Intel Mac OS X 10_15_7","Macintosh; Intel Mac OS X 11","Macintosh; Intel Mac OS X 11_0","Macintosh; Intel Mac OS X 11_0_1","Macintosh; Intel Mac OS X 11_1",
           "Macintosh; Intel Mac OS X 11_2","Macintosh; Intel Mac OS X 11_2_0","Macintosh; Intel Mac OS X 11_2_1","Macintosh; Intel Mac OS X 11_2_1","Macintosh; Intel Mac OS X 11_2_2",
           "Macintosh; Intel Mac OS X 11_2_3","Macintosh; Intel Mac OS X 11_3","Macintosh; Intel Mac OS X 11_3_1","Macintosh; Intel Mac OS X 11_4","Macintosh; Intel Mac OS X 11_5",
           "Macintosh; Intel Mac OS X 11_5_1","Macintosh; Intel Mac OS X 11_5_2","Macintosh; Intel Mac OS X 11_6","Macintosh; Intel Mac OS X 11_6_1","Macintosh; Intel Mac OS X 11_6_2",
           "Macintosh; Intel Mac OS X 11_6_3","Macintosh; Intel Mac OS X 11_6_4","Macintosh; Intel Mac OS X 11_6_5","Macintosh; Intel Mac OS X 11_6_6","Macintosh; Intel Mac OS X 11_6_7",
           "Macintosh; Intel Mac OS X 11_6_8","Macintosh; Intel Mac OS X 11_7","Macintosh; Intel Mac OS X 11_7_1","Macintosh; Intel Mac OS X 11_7_2","Macintosh; Intel Mac OS X 11_7_3",
           "Macintosh; Intel Mac OS X 11_7_4","Macintosh; Intel Mac OS X 11_7_5","Macintosh; Intel Mac OS X 11_7_6","Macintosh; Intel Mac OS X 11_7_7","Macintosh; Intel Mac OS X 11_7_8",
           "Macintosh; Intel Mac OS X 11_7_9","Macintosh; Intel Mac OS X 11_7_10","Macintosh; Intel Mac OS X 12_6_6","Macintosh; Intel Mac OS X 12_6_7","Macintosh; Intel Mac OS X 12_6_8",
           "Macintosh; Intel Mac OS X 12_2","Macintosh; Intel Mac OS X 12_2_1","Macintosh; Intel Mac OS X 12_3","Macintosh; Intel Mac OS X 12_3_1","Macintosh; Intel Mac OS X 12_4",
           "Macintosh; Intel Mac OS X 12_5","Macintosh; Intel Mac OS X 12_5_1","Macintosh; Intel Mac OS X 12_6","Macintosh; Intel Mac OS X 12_6_1","Macintosh; Intel Mac OS X 12_6_2",
           "Macintosh; Intel Mac OS X 12_6_3","Macintosh; Intel Mac OS X 12_6_4","Macintosh; Intel Mac OS X 12_6_5","Macintosh; Intel Mac OS X 12_7","Macintosh; Intel Mac OS X 12_7_1",
           "Macintosh; Intel Mac OS X 12_6_9","Macintosh; Intel Mac OS X 12","Macintosh; Intel Mac OS X 12_0","Macintosh; Intel Mac OS X 12_0_1","Macintosh; Intel Mac OS X 12_1",
           "Macintosh; Intel Mac OS X 12_7_2","Macintosh; Intel Mac OS X 12_7_3","Macintosh; Intel Mac OS X 12_7_4","Macintosh; Intel Mac OS X 12_7_5","Macintosh; Intel Mac OS X 12_7_6",
           "Macintosh; Intel Mac OS X 13_0","Macintosh; Intel Mac OS X 13_0_1","Macintosh; Intel Mac OS X 13_1","Macintosh; Intel Mac OS X 13_2","Macintosh; Intel Mac OS X 13_2_1",
           "Macintosh; Intel Mac OS X 13_3","Macintosh; Intel Mac OS X 13_3_0","Macintosh; Intel Mac OS X 13_3_1","Macintosh; Intel Mac OS X 13_4","Macintosh; Intel Mac OS X 13_4_1",
           "Macintosh; Intel Mac OS X 13_5_0","Macintosh; Intel Mac OS X 13_5_1","Macintosh; Intel Mac OS X 13_5_2","Macintosh; Intel Mac OS X 13_6_1","Macintosh; Intel Mac OS X 13_6_2",
           "Macintosh; Intel Mac OS X 13_6_2","Macintosh; Intel Mac OS X 13_6_3","Macintosh; Intel Mac OS X 13_6_4","Macintosh; Intel Mac OS X 13_6_5","Macintosh; Intel Mac OS X 13_6_6",
           "Macintosh; Intel Mac OS X 13_6_7","Macintosh; Intel Mac OS X 13_6_8","Macintosh; Intel Mac OS X 13_7","Macintosh; Intel Mac OS X 14_2","Macintosh; Intel Mac OS X 14_0",
           "Macintosh; Intel Mac OS X 14_1","Macintosh; Intel Mac OS X 14_2_1","Macintosh; Intel Mac OS X 14_3","Macintosh; Intel Mac OS X 14_3_1","Macintosh; Intel Mac OS X 14_4_1",
           "Macintosh; Intel Mac OS X 14_5","Macintosh; Intel Mac OS X 14_6","Macintosh; Intel Mac OS X 14_6_1","Macintosh; Intel Mac OS X 14_7","Macintosh; Intel Mac OS X 14_7_1",
           "Macintosh; Intel Mac OS X 15_0","Macintosh; Intel Mac OS X 15_3_0","Macintosh; Intel Mac OS X 15_3_2","Macintosh; Intel Mac OS X 15_4","Macintosh; Intel Mac OS X 15_4_1",
           "Macintosh; Intel Mac OS X 15_2","Macintosh; Intel Mac OS X 15_3","Macintosh; Intel Mac OS X 15_3_1","Macintosh; Intel Mac OS X 15_7_7","Macintosh; Intel Mac OS X 26_0","Macintosh; Intel Mac OS X 14_4",
           "Macintosh; Intel Mac OS X 15_5","Macintosh; Intel Mac OS X 15_0","Macintosh; Intel Mac OS X 15_0_1","Macintosh; Intel Mac OS X 15_1","Macintosh; Intel Mac OS X 15_1_1",
           "Macintosh; PPC Mac OS X 9","Macintosh; PPC Mac OS X 10_6_9","Macintosh; PPC Mac OS X 10_7_4","Macintosh; U; Intel Mac OS X 10_12_5","Macintosh; U; Intel Mac OS X 10_12_6",
           "Macintosh; U; PPC Mac OS X 10_11_0","Macintosh; Intel Mac OS X 11_1_0","Mac OS X 10_11_6","Macintosh; Intel Mac OS X 10_14_3","Macintosh; Intel Mac OS X 10_15_1 AppleWebKit/537.36",

           //MacOS FALSE 260826
           "Macintosh; Intel Mac OS X 10.15; rv:134.0","Macintosh; Intel Mac OS X 10.15; rv:137.0","Macintosh; Intel Mac OS X 10_11_6","Macintosh; Intel Mac OS X 10_12_6","Macintosh; Intel Mac OS X 10_14_3",
           "Macintosh; Intel Mac OS X 10_14_4","Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36","Macintosh; Intel Mac OS X 11_1_0","Macintosh; Intel Mac OS X 13.2; rv:126.0","Macintosh; Intel Mac OS X 14_6_1","Macintosh; Intel Mac OS X 14.4; rv:127.0",
           "Macintosh; Intel Mac OS X 15_3_1","Macintosh; U; PPC Mac OS; en-en","Macintosh; U; PPC Mac OS; en-en) AppleWebKit/412","Macintosh; U; PPC Mac OS X; it-it","Safari/537.36",

		   //iPhone Updated 2600826
           "iPhone OS 1_","iPhone OS 2_","iPhone OS 3_","iPhone OS 4_","iPhone OS 5_","iPhone OS 6_","iPhone OS 7_","iPhone OS 8_","iPhone OS 9_","iPhone OS 10_","iPhone OS 11_",
		   "iPhone OS 12_","iPhone OS 13_","iPhone OS 14_",	"iPhone OS 15_","iPhone OS 16_","iPhone OS 17_","iPhone OS 18_","CPU iPhone OS 9_2","CPU iPhone OS 13_2","iPhone OS 13_2_3",

           //iOS Updated 260718
		   "iOS 1_","iOS 2_","iOS 3_","iOS 4_","iOS 4.3.3","iOS 5_","iOS 5.1.1","iOS 6_","iOS 6.1.2", "OS 7_","iOS 8_","iOS 9_","iOS 9.2.1","iOS 10_","iOS 11_","iOS 12_","iOS 13_","iOS 14_",			
		   "iOS 15_","15.8.7_","iOS 16_","iOS 16.7.15_","iOS 17_","17.2_","iOS 5.8.7","iOS 16.7.15","iOS 17.2","iOS 18", 	   

           //Ios_platform Updated 260826 +ake.ios
		   "iPad; CPU iPad OS 10_3_4 like Mac OS","iPad; CPU iPad OS 17_1 like Mac OS X","iPhone; CPU iPhone OS 12_4_8 like Mac OS X","iPad; CPU iPad OS 16_7_7 like Mac OS X","iPad; CPU iPad OS 17_2_1 like Mac OS X","iPad; CPU iPad OS 10_3_4 like Mac OS", 

           //Windows NT versions Updated 260904
           "Windows NT","Windows NT 3.1","Windows NT 3.11","Windows NT 3.5","Windows NT 3.5 NT ","Windows NT 3.10","Windows NT 3.14.0","Windows NT 3.50","Windows NT 3.51","Windows NT 3.52",
           "Windows NT 3.51 NT 3","Windows NT 3.10","Windows NT 3.52","Windows NT 4","Windows NT 4.0","Windows NT 4.5","Windows NT 5","Windows NT/5","Windows NT 5.0","Windows NT 5.2","Windows NT 5.1",
           "Windows NT 5.01","Windows NT 5.2","Windows NT 6","Windows NT 6.0", "Windows NT/6","Windows NT 6.0","Windows NT 6.1","Windows NT 6.1; WOW64","Windows NT 6.1; Win64; x64","Windows NT 6.2",
           "Windows NT 6.3","Windows NT 6.3","Win 9x","WinNT","windows NT 7.0","windows NT 8.0","windows NT 9.0","Windows NT 10", "Windows NT 10.0", "Windows 11",
		   
           //Old Windows Patterns+ FALSE Updated 260826
		   "X11; U; Linux","X11; U; Linux armv7","Windows 95","Windows 98","Windows ME","Windows 2000","Windows XP","Windows Vista","Windows 7","Windows 8","Windows 8.1", 
		   "WinCE","Win32","Windows Mobile","Windows Phone","X11; U; Linux","X11; U; Linux armv7","X11; Linux x86_64","X11; Linux x86_64","X11; Linux i686","X11; Linux x86_64",

		   //VERY Old Opera versions Updated 260906
           "Opera/20","Opera/21","Opera/22","Opera/23","Opera/24","Opera/25","Opera/26","Opera/27","Opera/28","Opera/29","Opera/30","Opera/31","Opera/32","Opera/33","Opera/34","Opera/35","Opera/36","Opera/37",
           "Opera/38","Opera/39","Opera/40","Opera/41","Opera/42","Opera/43","Opera/44","Opera/45","Opera/46","Opera/47","Opera/48","Opera/49","Opera/50","Opera/51","Opera/52","Opera/53","Opera/54","Opera/55",
           "Opera/56","Opera/57","Opera/58","Opera/59","Opera/60","Opera/61","Opera/62","Opera/63","Opera/64","Opera/65","Opera/66","Opera/67","Opera/68","Opera/69","Opera/70","Opera/71","Opera/72","Opera/73",
           "Opera/74","Opera/75","Opera/76","Opera/77","Opera/78","Opera/79","Opera/80","Opera/81","Opera/82","Opera/83","Opera/84","Opera/85","Opera/86","Opera/87","Opera/88","Opera/89","Opera/90","Opera/91",
           "Opera/92","Opera/93","Opera/94","Opera/95","Opera/96","Opera/97","Opera/98","Opera/99","Opera/100",
		  
		   //Opera old versions Updated 260906
           "OPR/1","OPR/2","OPR/3","OPR/4","OPR/5","OPR/6","OPR/7","OPR/8","OPR/9","OPR/10","OPR/11","OPR/12","OPR/13","OPR/14","OPR/15","OPR/16","OPR/17","OPR/18","OPR/19","OPR/20","OPR/21",
		   "OPR/22","OPR/23","OPR/24","OPR/25","OPR/26","OPR/27","OPR/28","OPR/29","OPR/30","OPR/31","OPR/32","OPR/33","OPR/34","OPR/35","OPR/36","OPR/37","OPR/38","OPR/39","OPR/40","OPR/41",
		   "OPR/42","OPR/43","OPR/44","OPR/45","OPR/46","OPR/47","OPR/48","OPR/49","OPR/50","OPR/51","OPR/52","OPR/53","OPR/54","OPR/55","OPR/56","OPR/57","OPR/58","OPR/59","OPR/60","OPR/61",
		   "OPR/62","OPR/63","OPR/64","OPR/65","OPR/66","OPR/67","OPR/68","OPR/69","OPR/70","OPR/71","OPR/72","OPR/73","OPR/74","OPR/75","OPR/76","OPR/77","OPR/78","OPR/79","OPR/80","OPR/81",
		   "OPR/82","OPR/83","OPR/84","OPR/85","OPR/86","OPR/87","OPR/88","OPR/89","OPR/90","Opera/9","Opera/10","Opera/11","Opera/12","Opera/15","Opera/16","Opera/17","Opera/18","Opera/19", 
           "OPR/100.0.4815.20","OPR/100.0.4815.21","OPR/100.0.4815.30","OPR/100.0.4815.47","OPR/100.0.4815.54","OPR/100.0.4815.76","OPR/101.0.4843.25","OPR/101.0.4843.33","OPR/101.0.4843.43",
           "OPR/101.0.4843.58","OPR/102.0.4880.16","OPR/102.0.4880.29","OPR/102.0.4880.33","OPR/102.0.4880.40","OPR/102.0.4880.46","OPR/102.0.4880.51","OPR/102.0.4880.56","OPR/102.0.4880.70",
           "OPR/102.0.4880.78","OPR/103.0.4928.16","OPR/103.0.4928.26","OPR/103.0.4928.34","OPR/103.0.4928.47","OPR/104.0.4944.23","OPR/104.0.4944.28","OPR/104.0.4944.33","OPR/104.0.4944.36",
           "OPR/104.0.4944.54","OPR/104.0.4944.72","OPR/105.0.4970.13","OPR/105.0.4970.16","OPR/105.0.4970.21","OPR/105.0.4970.29","OPR/105.0.4970.34","OPR/105.0.4970.48","OPR/105.0.4970.60",
		   "OPR/106.0.4998.16","OPR/106.0.4998.19","OPR/106.0.4998.28","OPR/106.0.4998.41","OPR/106.0.4998.52","OPR/106.0.4998.66","OPR/106.0.4998.70","OPR/107.0.5045.15","OPR/107.0.5045.21",
           "OPR/107.0.5045.36","OPR/107.0.5045.71","OPR/108.0.5067.20","OPR/108.0.5067.24","OPR/108.0.5067.29","OPR/108.0.5067.40","OPR/109.0.5097.33","OPR/109.0.5097.35","OPR/109.0.5097.38",
           "OPR/109.0.5097.45","OPR/109.0.5097.59","OPR/109.0.5097.68","OPR/109.0.5097.80","OPR/110.0.5130.23","OPR/110.0.5130.35","OPR/110.0.5130.39","OPR/110.0.5130.49","OPR/110.0.5130.64",
           "OPR/110.0.5130.66","OPR/110.0.5130.82","OPR/111.0.5168.25","OPR/111.0.5168.43","OPR/111.0.5168.55","OPR/111.0.5168.61","OPR/112.0.0.0","OPR/112.0.5197.24","OPR/112.0.5197.25",
           "OPR/112.0.5197.30","OPR/112.0.5197.39","OPR/112.0.5197.53","OPR/113.0.0.0","OPR/113.0.5230.31","OPR/113.0.5230.32","OPR/113.0.5230.47","OPR/113.0.5230.55","OPR/113.0.5230.62",
           "OPR/113.0.5230.86","OPR/113.0.5230.132","OPR/113.0.5230.136","OPR/113.0.5230.142","OPR/114.0.5282.21","OPR/114.0.5282.86","OPR/114.0.5282.94","OPR/114.0.5282.102","OPR/114.0.5282.115",
           "OPR/114.0.5282.144","OPR/114.0.5282.154","OPR/114.0.5282.185","OPR/114.0.5282.222","OPR/114.0.5282.235","OPR/115.0.5322.68","OPR/115.0.5322.77","OPR/115.0.5322.109","OPR/115.0.5322.119",
           "OPR/116.0.5366.21","OPR/116.0.5366.35","OPR/116.0.5366.51","OPR/116.0.5366.71","OPR/116.0.5366.127","OPR/117.0.5408.32","OPR/117.0.5408.35","OPR/117.0.5408.39","OPR/117.0.5408.53",
           "OPR/117.0.5408.93","OPR/117.0.5408.142","OPR/117.0.5408.154","OPR/117.0.5408.163","OPR/117.0.5408.197","OPR/118.0.5461.41","OPR/118.0.5461.60","OPR/118.0.5461.83","OPR/118.0.5461.104",
           "OPR/119.0.5497.29","OPR/119.0.5497.38","OPR/119.0.5497.40","OPR/119.0.5497.56","OPR/119.0.5497.70","OPR/119.0.5497.88","OPR/119.0.5497.110","OPR/119.0.5497.131","OPR/119.0.5497.141",
           "OPR/120.0.5543.38","OPR/120.0.5543.61","OPR/120.0.5543.93","OPR/120.0.5543.128","OPR/120.0.5543.161","OPR/120.0.5543.201","OPR/121.0.5600.38","OPR/121.0.5600.50","OPR/122.0.5643.17",
           "OPR/122.0.5643.24","OPR/122.0.5643.51","OPR/122.0.5643.71","OPR/122.0.5643.92","OPR/122.0.5643.142","OPR/122.0.5643.150","OPR/123.0.5669.23","OPR/123.0.5669.47","OPR/124.0.5705.15",
           "OPR/124.0.5705.42","OPR/124.0.5705.65","OPR/125.0.5729.12","OPR/125.0.5729.15","OPR/125.0.5729.21","OPR/125.0.5729.49","OPR/126.0.5750.124","OPR/126.0.5750.18","OPR/126.0.5750.37",
           "OPR/126.0.5750.43","OPR/126.0.5750.59","OPR/127.0.5778.125","OPR/127.0.5778.14","OPR/127.0.5778.47","OPR/127.0.5778.64","OPR/127.0.5778.76","OPR/128.0.5807.25","OPR/128.0.5807.37",
           "OPR/128.0.5807.52","OPR/128.0.5807.66","OPR/128.0.5807.77","OPR/129.0.5823.15","OPR/129.0.5823.22","OPR/129.0.5823.28","OPR/129.0.5823.44","OPR/129.0.5823.65","OPR/130.0.5847.12",
           "OPR/130.0.5847.41","OPR/130.0.5847.82","OPR/130.0.5847.92","OPR/131.0.5877.116","OPR/131.0.5877.24","OPR/131.0.5877.5","OPR/131.0.5877.5","OPR/131.0.5877.74","OPR/131.0.5877.97",
           "OPR/132.0.5905.102","OPR/132.0.5905.11","OPR/132.0.5905.114","OPR/132.0.5905.19","OPR/132.0.5905.22","OPR/132.0.5905.37","OPR/132.0.5905.73","OPR/133.0.0.0","OPR/133.0.5932.10",
           "OPR/133.0.5932.20","OPR/133.0.5932.24","OPR/133.0.5932.34","OPR/133.0.5932.60","OPR/133.0.5932.8","OPR/134.0.5954.46","OPR/134.0.5954.56","OPR/134.0.5954.66","OPR/135.0.5973.41",
           "OPR/135.0.5973.55","OPR/135.0.5973.66","OPR/135.0.5973.76",

		   //Safari webkit Updated 260905
           "Version/1","Version/2","Version/3","Version/4","Version/4.0","Version/5","Version/6","Version/7","Version/8","Version/9","Version/10","Version/11","Version/12","Version/13","Version/14",
		   "Version/15","Version/16","Version/17","Version/17.4","Version/17.5","Version/18","Version/18.3.1","Version/19","Version/20","Version/26.0","Version/120",

		   //Safari webkit Updated 2600905
		   "AppleWebKit/420","AppleWebKit/528","AppleWebKit/534","AppleWebKit/534.46","AppleWebKit/535","AppleWebKit/536","AppleWebKit/537","AppleWebKit/603.3.8","AppleWebKit/605.1.15",

		   ///Safari Versions Updated 2609
		   "Safari/0.8","Safari/1","Safar0i5/1.0","Safari/2","Safari/2.0","Safari/2.0.4","Safari/3","Safari/3.0","Safari/3.1","Safari/3.2","Safari/3.2.3","Safari/4","Safari/4.0",
		   "Safari/4.0.4","Safari/4.1.3","Safari/5","Safari/5.0","Safari/5.0.3","Safari/5.1","Safari/5.1.1","Safari/5.1.2","Safari/5.1.5","Safari/5.1.10","Safari/5.34.57.2",
		   "Safari/6","Safari/6.0","Safari/6.1","Safari/6.2.8","Safari/7","Safari/7.0","Safari/7.1","Safari/7.1.8","Safari/8","Safari/8.0","Safari/8.0.8","Safari/9","Safari/9.0",
		   "Safari/9.1","Safari/9.1.3","Safari/10","Safari/10.0","Safari/10.1","Safari/10.1.2","Safari/11","Safari/11.0","Safari/11.1","Safari/11.1.2","Safari/12","Safari/12.0",
		   "Safari/12.1","Safari/12.1.2","Safari/13","Safari/13.0","Safari/13.1","Safari/13.1.2","Safari/14","Safari/14.0","Safari/14.1","Safari/14.1.2","Safari/15","Safari/15.0",
		   "Safari/15.1","Safari/15.2","Safari/15.3","Safari/15.4","Safari/15.5","Safari/15.6","Safari/15.6.1","Safari/16","Safari/16.0","Safari/16.1","Safari/16.2","Safari/16.3",
		   "Safari/16.4","Safari/16.5","Safari/16.6","Safari/16.6.1","Safari/17","Safari/17.0","Safari/17.1","Safari/17.1.1","Safari/17.1.2","Safari/17.2","Safari/17.2.1","Safari/17.3",
		   "Safari/17.4","Safari/17.5","Safari/17.6","Safari/18","Safari/18.0","Safari/18.0.1","Safari/18.1","Safari/18.1.1","Safari/18.2","Safari/18.3","Safari/18.4","Safari/18.5",
		   "Safari/18.6","Safari/18.7","Safari/19","Safari/20","Safari/26.0","Safari 26.0.","Safari/26.1","Safari/26.2","Safari/26.3","Safari/26.4","Safari/26.5"
		
		   ///FAKE Safari Updated 260825
           "Safari/4E423F","Safari/416.13","Safari/525.13","Safari/524.34","Safari/605.1.15","Safari/412","Safari/537.3637.239.99.12","Safari/412.2","Safari/605.1.15","Safari/15.0.0.0","Safari/10.0.0.0",
	       "Safari/419.3","Safari/537.3","Safari/6534.49.4","Safari/6535.10.3","Safari/6531.6.6","Safari/6534.6.1","Safari/6534.21.","Safari/604.1","Safari/537.3",

		   //Vivaldi old versions
		   "Vivaldi/1_","Vivaldi/2_","Vivaldi/3_","Vivaldi/4_","Vivaldi/5_","Vivaldi/6_","Vivaldi/7_","Vivaldi/8_",	
			
        ];
        // Initialize allowed bots list (legitimate search engines and crawlers)
        $this->allowed_bots = [
    ];
    // Bots to ALLOW (legitimate search engines and browsers)
    private $allowed_bots = [
            'AdsBot-Google','Android OS','AOL Search','AOL','AdIdxBot','APIs-Google','Applebot','AppleNewsBot','apple-app-site-association','archive.org_bot','Avant',
			'BingPreview','Bing Preview bot','Bingbot','bingbot','bingbot/2.0','bing','BingVideoPreview','BraveBot','Brave',
            'Chrome','coccocbot-image','coccocbot-web','coccocbot-web/1.0','CocCocBot','CocCoc','CriOS',
            'Dogpile','Dolphin Browser','Dolphin Browse','DuckDuckBot','DuckDuckGo-Favicons-Bot','DuckDuckGo','DuplexWeb-Google',
            'EcosiaBot','Ecosia','Edge','Edg','Exabot',
            'Feedfetcher-Google','Firefox','FxiOS',
            'GibiruBot','Google Favicon','AdsBot-Google-Mobile','google page speed','Google Read Aloud','Googlebot/2.1','Google Site Verifier','Googlebot Smartphone','Google-Safety',
            'Google API', 'Googlebot-Image','Googlebot-Image/1.0','Googlebot-Mobile','Googlebot-News','Googlebot-Video','Googlebot-Video/1.0','GoogleOther','GoogleOther-Image/1.0',
            'Googlebot','Googlebot/2.1','GoogleProducer','Google-InspectionTool','Google-InspectionTool/1.0','Google-Mobile-Apps','Google-Safetys','Google-Site-Verification/1.0','Google Web Preview',
            'ia_archiver','IceCat','Iceweasel','Info.com','Instagram','Konqueror',
            'Lighthouse','LinkedInApp','LinkedInBot','linkedinbot','LookseekBot','Lycos', 
            'Mastodon','Maxthon','Mediapartners-Google','Mediapartners-Google/2.1','MeiliBot','MetaBot','Microsoft Previewt','MetaCrawler','MetaGer','Mi Browser','Midori','MojeekBot','MS Search',
            'msnbot-media','MSNBot-NewsBlogs','msnbot','Nimbostratus',
            'Opera','OPR','OscoboBot',
            'PageSpeed','PeekBot','Pinterest','PresearbotBot',
            'QQBrowser','QwantBot','Qwantify','Qwant',
            'Safari','SamsungBrowser','Seamonkey','Search Encrypt','SeznamBot','SeznamBot/4.0','SphinxBot','StartpageBot','StartPage','SwiftBot','Swisscows',
            'TumblrBot','UCBrowser','Vivaldi','WebCrawler','WebwikiBot',
            'WolfBot','YaBrowser','YacyBot','YaDirectFetchery','YaDirectFetcher','Yahoo! Slurp','yahoo-blogs','yahoo-blogs/v3.9','Yandexbot','Yandex','Yeti-Mobile','Yeti','Yeti/1.1',
			// Social link previewers (these appear in the headless_allowlist too)
            'LinkedInBot','Slackbot','Discordbot','TelegramBot','WhatsApp','Slack-LinkPreview','TeamsBot','SkypeUriPreview','iMessageBot','Pinterest','TumblrBot','Mastodon','Instagram','Line','Viber','WeChat',
			// Pinger 
            'UptimeRobot','Pingdom','StatusCake','GTmetrix','Site24x7','Catchpoint','DatadogSynthetics','NewRelicPinger',
			// DK
            'OverskriftBot/1.0',
        ];

        // Initialize dummy content templates
        $this->dummy_content_templates = [
         
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'=>'Human Browser (allowed)',
           'curl/7.68.0'=> 'cURL (BLOCKED)',
           'OpenAI-GPT/1.0'=> 'OpenAI bot (BLOCKED)',
           'NuMON Agent/1.1'=> 'NuMON Agent/1.1 (BLOCKED)',
           'python-requests/2.25.1'=> 'Python Requests (BLOCKED)',
           'Mediapartners-Google'=> 'Mediapartners-Google (BLOCKED)',
           'ChatGPT-User'=> 'ChatGPT-User (BLOCKED)',
           'Headless Chrome'=> 'Headless Chrome (BLOCKED)',
           'facebookexternalhit/1.1'=> 'Facebook previewer (BLOCKED)',
           'Twitterbot/1.0'=> 'Twitter (BLOCKED)',
           'bingbot/2.0'=> 'Bingbot (ALLOWED)',
           'Googlebot/2.1'=>'Google (allowed)',
           'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'=>'Google (allowed)',
           'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.7922.173 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'=> 'Google (allowed)',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Vivaldi/8.4.3067.53'=> 'Vivaldi(allowed)',
           'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.3859.58.55 Safari/537.36 Brave/146.3859.58.55'=> 'Brave (allowed)',
           'Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15'=> 'Safari (allowed)',
           'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36'=> 'Bing(allowed)',
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Action</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $is_allowed = $this->is_allowed_bot($agent);
            
            if ($is_allowed) {
                $result = '✅ ALLOWED';
                $style = 'color: green; font-weight: bold;';
            } elseif ($is_bot) {
                $result = '🚫 BLOCKED';
                $style = 'color: red; font-weight: bold;';
            } else {
                $result = '👤 HUMAN/NORMAL';
                $style = 'color: blue;';
            }
            
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td style='{$style}'>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    public function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // First check if it's an allowed bot (return false - not malicious)
        if ($this->is_allowed_bot($user_agent)) {
            return false;
        }
        
        // Check for bot patterns in user agent (only flag if not allowed)
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, strtolower($pattern)) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if the bot is in the allowed bots list
     */
    public function is_allowed_bot($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Check if user agent matches any allowed bot
        foreach ($this->allowed_bots as $allowed_bot) {
            if (stripos($user_agent, $allowed_bot) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get the allowed bots list (for display purposes)
     */
    public function get_allowed_bots() {
        return $this->allowed_bots;
    }

    /**
     * Block the current request by sending a 403 Forbidden header
     * and terminating script execution.
     *
     * Use this at the very top of a request handler — BEFORE any
     * echo / HTML output — to safely send the header.
     */
    public function block_bot() {
        if (!headers_sent()) {
            header('HTTP/1.0 403 Forbidden');
        }
        exit;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// --- Real-world request guard -------------------------------------------
// If this script is hit by a bot in the wild, block it BEFORE any output
// is produced so the 403 header is sent cleanly. The test harness below
// (echo'ing HTML) only runs for humans / whitelisted crawlers.
$guard = new AI_Shield_Test();
$guard_ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
if ($guard_ua !== '' && $guard->is_bot_request($guard_ua)) {
    $guard->block_bot();
}
// -----------------------------------------------------------------------

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "<h2>✅ Allowed Bots Configuration</h2>";
echo "<p><strong>Total Allowed Bots:</strong> " . count($test->get_allowed_bots()) . "</p>";
echo "<p>This honeypot system now includes an extensive list of legitimate search engine crawlers and bots that will be allowed to access your content. This ensures your site remains SEO-friendly while protecting against malicious AI scrapers.</p>";
echo "<p><strong>Key Benefits:</strong></p>";
echo "<ul>";
echo "<li>✅ <strong>SEO Friendly:</strong> Google, Bing, Yandex and other search engines can still crawl your site</li>";
echo "<li>🛡️ <strong>AI Protection:</strong> Blocks malicious AI scrapers and content harvesters</li>";
echo "<li>⚖️ <strong>Balanced Approach:</strong> Allows legitimate bots while preventing content theft</li>";
echo "<li>🔧 <strong>Customizable:</strong> Easy to add or remove bots from the allowed list</li>";
echo "</ul>";

echo "</body></html>";
?>
