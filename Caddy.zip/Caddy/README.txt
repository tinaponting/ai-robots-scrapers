Caddy (v2)
In Caddy, define a named matcher that uses a regular expression on the User-Agent header. For example, in your Caddyfile:


@openaiBots {
header_regexp User-Agent (?i)(OAI-SearchBot|ChatGPT-User|GPTBot)
}

handle @openaiBots {
respond 403
}