<?php
$block = array('some ai','adress')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('some ai','adress')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
}
}
?>