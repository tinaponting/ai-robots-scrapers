<?php
// (No dots needed unless you _specifically_ want ".bot" in the UA)
$blockList = ['bot', 'domain'];

$userAgent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

foreach ($blockList as $needle) {
    if ($needle !== '' && strpos($userAgent, $needle) !== false) {
        header( 'Status: 403 Forbidden', true, 403 );
        exit;
    }
}