READ ME:)

You can use any of these options, if you can't get some stubborn AI or other user agent.