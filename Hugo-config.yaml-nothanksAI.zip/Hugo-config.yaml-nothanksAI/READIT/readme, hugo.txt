The important part is the robots section inside params, the rest of the yaml should contain your custom configuration. 
Do not forget to set the enableRobotsTXT: true.
Then you can write your custom template for building the robots.txt using the params previously specified, with something like this:

{{ if hugo.IsProduction }}
  {{ range $robot := .Site.Params.robots }}
  User-agent: {{ $robot }}
  Disallow: /
  {{end}}
{{ else }}
  User-agent: *
  Disallow: /
{{ end }}

This template should be named robots.txt and placed inside your layouts folder; if Hugo is deployed in production, 
it basically tells Hugo to iterate over the bots specified in the config.yaml and build the directives.

Second approach: Caddy’s settings
If you don’t trust companies to follow your robots.txt instructions and you have full access to your server’s configuration, 
then you can forbid access to your website using the User-Agent header, no matter what the robots.txt says.

Here’s what you can do for Caddy in your Caddyfile (usually located by default in /etc/caddy/Caddyfile):

yourdomain.com {
        #your custom settings here
        encode gzip zstd

@botForbidden header_regexp User-Agent "(?i) "
    
    handle @botForbidden   {
            respond /* "Access denied" 403 {
                close
            }
        }

        file_server
        root * /path/to/your/blog/public
        log {
                output file /path/to/your/logs/your-blog-access.log {
                        roll_size 20mb
                        roll_keep 10
                        roll_keep_for 720h
                }
        }
}


The @botForbidden and the related handle @botForbidden instruction are the important bits of configuration in order to 
return a 403 Forbidden status to the bots. The rest of the config should be customized taking into account your 
specific configuration; as you can see, I also added a logging section in order to keep track of requests.

To test if everything is ok, you can use cURL or change the User-Agent header from Chrome’s dev tools. 
Since I’m using Firefox and it’s a bit less practical to change the User-Agent setting in this case, I will tell you how to use curl.