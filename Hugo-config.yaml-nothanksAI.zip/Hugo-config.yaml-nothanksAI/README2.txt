enableRobotsTXT = true
That tells Hugo to process layouts/robots.txt, which I have set up with this content to insert the sitemap and greet robots who aren't assholes:

Copy
Sitemap: {{ .Site.BaseURL }}sitemap.xml
# hello robots [^_^]
# let's be friends <3
User-agent: *
Disallow:
# except for these bots which are not friends:
{{ partial "bad-robots.html" . }}
I opted to break the heavy lifting out into layouts/partials/bad-robots.html to keep things a bit tidier in the main template. This starts out simply enough with using resources.GetRemote to fetch the desired JSON file, and printing an error if that doesn't work:

Copy
{{- $url := "https://raw.githubusercontent.com/ai-robots-txt/ai.robots.txt/main/robots.json" -}}
{{- with resources.GetRemote $url -}}
	{{- with .Err -}}
		{{- errorf "%s" . -}}
	{{- else -}}
The JSON file looks a bit like this, with the user agent strings as the top-level keys:

Copy
{
    "Amazonbot": { 
        "operator": "Amazon",
        "respect": "Yes",
        "function": "Service improvement and enabling answers for Alexa users.",
        "frequency": "No information. provided.",
        "description": "Includes references to crawled website when surfacing answers via Alexa; does not clearly outline other uses."
    },
    "anthropic-ai": { 
        "operator": "[Anthropic](https:\/\/www.anthropic.com)",
        "respect": "Unclear at this time.",
        "function": "Scrapes data to train Anthropic's AI products.",
        "frequency": "No information. provided.",
        "description": "Scrapes data to train LLMs and AI products offered by Anthropic."
    },
    "Applebot-Extended": { 
        "operator": "[Apple](https:\/\/support.apple.com\/en-us\/119829#datausage)",
        "respect": "Yes",
        "function": "Powers features in Siri, Spotlight, Safari, Apple Intelligence, and others.",
        "frequency": "Unclear at this time.",
        "description": "Apple has a secondary user agent, Applebot-Extended ... [that is] used to train Apple's foundation models powering generative AI features across Apple products, including Apple Intelligence, Services, and Developer Tools."
    },
    {...}
}
There's quite a bit more detail in this JSON than I really care about; all I need for this are the bot names. So I unmarshal the JSON data, iterate through the top-level keys to extract the names, and print a line starting with User-agent: followed by the name for each bot.

Copy
    {{- $robots := unmarshal .Content -}}
    {{- range $botname, $_ := $robots }}
      {{- printf "User-agent: %s\n" $botname }}
    {{- end }}
And once the loop is finished, I print the important Disallow: / rule (and a plug for the repo) and clean up:

Copy
    {{- printf "Disallow: /\n" }}
    {{- printf "\n# (bad bots bundled by https://github.com/ai-robots-txt/ai.robots.txt)" }}
	{{- end -}}
{{- else -}}
	{{- errorf "Unable to get remote resource %q" $url -}}
{{- end -}}
So here's the completed layouts/partials/bad-robots.html:

Copy
{{- $url := "https://raw.githubusercontent.com/ai-robots-txt/ai.robots.txt/main/robots.json" -}}
{{- with resources.GetRemote $url -}}
	{{- with .Err -}}
		{{- errorf "%s" . -}}
	{{- else -}}
    {{- $robots := unmarshal .Content -}}
    {{- range $botname, $_ := $robots }}
      {{- printf "User-agent: %s\n" $botname }}
    {{- end }}
    {{- printf "Disallow: /\n" }}
    {{- printf "\n# (bad bots bundled by https://github.com/ai-robots-txt/ai.robots.txt)" }}
	{{- end -}}
{{- else -}}
	{{- errorf "Unable to get remote resource %q" $url -}}
{{- end -}}
After that's in place, I can fire off a quick hugo server in the shell and check out my work at http://localhost:1313/robots.txt:

Copy
Sitemap: http://localhost:1313/sitemap.xml
 
# hello robots [^_^]
# let's be friends <3
 
User-agent: *
Disallow:
 
# except for these bots which are not friends:
 
User-agent: A
User-agent: B

Disallow: /
 
# (bad bots bundled by https://github.com/ai-robots-txt/ai.robots.txt)