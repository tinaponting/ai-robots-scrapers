The important part is the robots section inside params, the rest of the yaml should contain your custom configuration. 
Do not forget to set the enableRobotsTXT: true.
Then you can write your custom template for building the robots.txt using the params previously specified, with something like this:

{{ if hugo.IsProduction }}
  {{ range $robot := .Site.Params.robots }}
  User-agent: {{ $robot }}
  Disallow: /
  {{end}}
{{ else }}
  User-agent: *
  Disallow: /
{{ end }}

This template should be named robots.txt and placed inside your layouts folder; if Hugo is deployed in production, it basically tells Hugo to iterate over the bots specified in the config.yaml and build the directives.

Second approach: Caddy’s settings
If you don’t trust companies to follow your robots.txt instructions and you have full access to your server’s configuration, then you can forbid access to your website using the User-Agent header, no matter what the robots.txt says.

Here’s what you can do for Caddy in your Caddyfile (usually located by default in /etc/caddy/Caddyfile):

yourdomain.com {
        #your custom settings here
        encode gzip zstd

        @botForbidden header_regexp User-Agent "(?i).ai|AutoML|aiHitBot|ai-proxy|Agent GPT|Agentic|Agentic Deep Research|AI agents /|AI Article Writer|AI Content Detector|AI Dungeon|AI Search Engine|
AI SEO Crawler|AI Training|AITraining /|AI Writer|AI2 Bot|AI2Bot|AI21 Labs|AIBot|AndiBot|AIMatrix|AISearchBot|Alexa|AlexaTM|Alpha AI|AlphaAI|
Amazon Bedrock|Amazon Comprehend|Amazon Lex|Amazon SageMaker|Amazon Sagemaker|Amazon Silk|Amazon Textract|AmazonBot|Amazon-Kendra|Amelia|AndersPinkBot|Anthropic|anthropic-ai|
AnyPicker|Anyword|Applebot-Extended|Aria Browse|Aria browse Aria AI|Aria browser AI|Articoolo|AutoGPT|Automated Writer|AwarioRssBot|AwarioSmartBot|AWS Trainium|Azure|
BabyAGI|Brave Leo|Brave Leo AI|Brightbot 1.0|ByteDance|ByteDance crawler|Bytespider|
CatBoost|CCBot|ccbot|CCBot/2.0|CC-Crawler|CC-Crawler/2.0|ChatGLM|ChatGPT|ChatGPT-User|ChatGPT-User/1.0|ChatGPT-User/2.0|ChatGPT search|chatUser /|
Chinchilla|Claude|Claude 3.5|Claude 4|Claude 3.5 Haiku|Claude 3.7 Sonnet|Claude Claude Sonnet 4|Claude Opus|Claude Opus 4| ClaudeBot|ClaudeBot/1.0|Claude-SearchBot|Claude-User|claude-web/1.0|
ClearScope|Cohere|cohere-ai|cohere-ai/1.0|cohere-training-data-crawler|Common Crawl|CommonCrawl|Content Harmony|Content King|Content Optimizer|
Content Samurai|Content Scraper GPT|ContentAtScale|ContentBot|Contentedge|Conversion AI|Copilot|CopyAI|Copymatic|Copyscape|Cotoyogi|CrawlGPT|CrawlQ AI|Crawlspace|Crew AI|CrewAI|
DALL-E|DALL-E 2|DALL-E Mini|DALL·E 3|DataForSeoBot|DataProvider|dataprovider|DeepAI|DeepL|DeepMindDeepSeek|DeepSeek-R1|DepolarizingGPT|DialoGPT|Diffbot|Doubao AI|DuckAssistBot|Extended GPT Scraper|
FacebookBot|FacebookBot/1.0|FacebookExternalHit|facebookexternalhit/1.1|Falcon|Firecrawl|Flyriver|flyriverbot/1.1|Frase AI|FraudGPT|FriendlyCrawler|
Gato|Gemini|Gemma|GenAI|Genspark|GLM|Google Gemini|Google-CloudVertexBot|Goose|GPT|GPT 4 Omni|GPT 4 Omni Mini|GPT Scraper|GPTBot /|GTP|GPTZero|GPT-1|
GPTBot/1.2|GPT-2|GPT-3|GPT-3.5|GPT-3.5 turbo|GPT-4|GPT-4o|GPT-4o mini|GPT-4V|GPT-4,5|gpt-4-turbo|GPT-4.1|GPT-4.1-mini|GPT-4.1-nano|
GPT-5|ChatGPT search|gpt-crawler|Grammarly|Grendizer|Grok|GrokAI|GT Bot|GTBot|GTPBOT|Hemingway Editor|Hugging Face|Hypotenuse AI|
iAskBot|iaskspider|iaskspider/2.0|ICC-Crawler|ImageGen|ImageGen /|ImagesiftBot|img2dataset|Inferkit|INK Editor|INKforall|IntelliSeek|IntelliSeek.ai|ISSCyberRiskCrawler|
JasperAI|Kafkai|Kangaroo|Kangaroo Bot|Keyword Density AI|knowledge /|KomoBot|
LeftWingGPT|Manus|LLaMA|Llama 3.2|Llama 4|LLMs|magpie-crawler|MarketMuse|Meltwater|Meta AI|Meta Llama|MetaAI|MetaTagBot|Meta-AI|
Meta-External|Meta-ExternalAgent|meta-externalagent|Meta-ExternalFetcher|meta-externalfetcher/1.1|Mistral|MistralAI-User/1.0|MSBot|Narrative|NeevaBot|Neural Text|NeuralSEO|Nicecrawler|Nova Act|
OAI SearchBot|OAI-SearchBot/1.0|Omgili|Omgilibot|Open AI|OpenAI|OpenAIContentCrawler|OpenAI Operator|OpenBot|OpenText AI|Operator|Outwrite|Page Analyzer AI|PanguBot|PaperLiBot|PaperLiBot/2.1|
Paraphraser.io|peer39_crawler|peer39_crawler/1.0|Perplexity|PerplexityBot|PerplexityBot/1.0|PerplexityUser|Perplexit-User|PetalBot|Phindbot|PiplBot|ProWritingAid|proximic|
QuillBot|RightWingGPT|RobotSpider|Rytr|SaplingAI|Scalenut|Scraper|ScraperGPT|Scrapy|Scrapy/2.0|ScriptBook|
SearchGPT|Seekr|SemrushBot-OCOB|Sentibot|SEO Content Machine|SEO Robot|ShadowGPT|Sidetrade|Simplified AI|Sitefinity|Skydancer|Slack-ImgProxy|SlickWrite|
Sonic|Spin Rewriter|Spinbot|Stability|Stability AI|StableDiffusionBot|Sudowrite|Super Agent|Surfer AI|Text Blaze|TextCortex|The Knowledge AI|thehive.a1Timpibot|TurnitinBot|
VelenPublicWebCrawler|Vidnami AI|WebChatGPT|WebText /|Webzio|Webzio-Extended|Whisper|WordAI|Wordtune|WormGPT|WormGPT V3.0|WormsGTP|Writecream|WriterZen|Writescope|
xAI|XBot|xBot|x.AI|yarchatgpt|YaLM|YarGPT|YouBot|Zero GTP|ZeroCHAT|Zerochat|ZeroGPT|Zhipu|Zimm"

        handle @botForbidden   {
            respond /* "Access denied" 403 {
                close
            }
        }

        file_server
        root * /path/to/your/blog/public
        log {
                output file /path/to/your/logs/your-blog-access.log {
                        roll_size 20mb
                        roll_keep 10
                        roll_keep_for 720h
                }
        }
}


The @botForbidden and the related handle @botForbidden instruction are the important bits of configuration in order to return a 403 Forbidden status to the bots. The rest of the config should be customized taking into account your specific configuration; as you can see, I also added a logging section in order to keep track of requests.

To test if everything is ok, you can use cURL or change the User-Agent header from Chrome’s dev tools. Since I’m using Firefox and it’s a bit less practical to change the User-Agent setting in this case, I will tell you how to use curl.