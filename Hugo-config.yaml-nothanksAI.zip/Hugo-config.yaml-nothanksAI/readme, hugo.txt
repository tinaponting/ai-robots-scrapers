The important part is the robots section inside params, the rest of the yaml should contain your custom configuration. 
Do not forget to set the enableRobotsTXT: true.
Then you can write your custom template for building the robots.txt using the params previously specified, with something like this:

{{ if hugo.IsProduction }}
  {{ range $robot := .Site.Params.robots }}
  User-agent: {{ $robot }}
  Disallow: /
  {{end}}
{{ else }}
  User-agent: *
  Disallow: /
{{ end }}

This template should be named robots.txt and placed inside your layouts folder; if Hugo is deployed in production, it basically tells Hugo to iterate over the bots specified in the config.yaml and build the directives.

Second approach: Caddy’s settings
If you don’t trust companies to follow your robots.txt instructions and you have full access to your server’s configuration, then you can forbid access to your website using the User-Agent header, no matter what the robots.txt says.

Here’s what you can do for Caddy in your Caddyfile (usually located by default in /etc/caddy/Caddyfile):

yourdomain.com {
        #your custom settings here
        encode gzip zstd

@botForbidden header_regexp User-Agent "(?i).ai|-ai|_ai|ai.|ai-|ai_|ai=|.*?-ai$|ai=n|AddSearchBot|AcademicBotRTU|Agent Middleware|Agentic|Agent 3|Agentic Deep Research|
Agentic RAG|Agentic-RAG|Agentic RAG with LangGraph|AgentQL|AI Agent|AI agents /|AgentGPT|Agent API|
AI Legion|Agent|Middleware|AI Article Writer|AI Chat|AI Chatbot|AI Content Detector|AI copilot|
AI Detection|AI Dungeon|AI Journalist|AI Journalist Agent|AI Search|AI Search Engine|AI Search Intent|AI SEO Crawler|
AI Web|AI Writer|AI2|AI2 BotAI2Bot|AI21 Labs|AIBot|aiHitBot|AIMatrix|AISearchBot|AITraining|AITraining /|AI-Crawler|
ai-crawlers-training|AI Web Scraper|AI Scraper|AI Website Screenshot|ai-proxy|Alexa|AlexaTM|Alice Yandex|
AliGenie|Alpha AI|AlphaAI|Amazon|Amazon Athena|Amazon Bedrock|AliyunSecBot|
Amazon Comprehend|Amazon Lex|Amazon SageMaker|Amazon Silk|Amazon Textract|amazonBot|Amazonbot|amazon-kendra|AWS bedrock|AWS Trainium|
Bedrock Claude|bedrock-chat|bedrock-chatbot|bedrock-claude-chatbot|Amelia|AndiBot|Anonymous AI|anonymous AI chatbot|
Anthropic|anthropic-ai|AnyPicker|AnythingLLM|Anyword|Apple|Applebot-Extended|Apple-GenAI|Applebot/0.1|Aria AI|Aria Browse|Aria browse Aria AI|
Aria browser AI|Articoolo|Ask AI|AutoGLM|AutoGPT|Auto-GPT|AutoGen|Automated Writer|AutoML|Autonomous RAG|
AwarioRssBot|AwarioSmartBot|Azure|Azure AI Search|
BabyAGI|BabyCatAGI|Basic RAG|Basic RAG Chain|BardBot|Brave Leo|Brave Leo AI|bigsur.ai|Big Sur AI|Big Sur AI Crawler|
BraveGPT|Brightbot|Brightbot 1.0|Brightbot operator|ByteDance|byteDance|ByteDance crawler|Bytespider|Browser MCP Agent|Browser Use|Bedrock
CarynAI|CatBoost|CCBot|ccbot|CCBot/2.0|CC-Crawler|CC-Crawler/2.0|Ceramic TerraCotta Crawler|Chai|Ceramic TerraCotta Crawler|Charstar AI|
Chatbot|chatbot|ChatGLM|ChatGPT|ChatGPT 4o|ChatGPT 4o-mini|
ChatGPT 4.1|ChatGPT 4.5|ChatGPT o1|ChatGPT o3-mini|ChatGPT Operator|ChatGPT search|ChatAnthropic|ChatGPT-User|ChatGPT-User/1.0|ChatGPT-User/2.0|ChatGPT Agent|
ChatLLM|ChatOpenAI|ChatUser|chatUser /|Chinchilla|Claude|laude.ai|Claude 3.5|Claude 3.5 Haiku|Claude 3.5 Sonnet|Claude 3.7 Sonnet|Claude 4|
Claude Opus|Claude Opus 4|Claude Sonnet 4|Claude Opus 4.1|ClaudeBot|ClaudeBot/1.0|Claude-RAG|Claude-SearchBot|Claude-User|Claude-Web|claude-web/1.0|Claude LLM|ClearScope|
Cognitive AI|Cognitive AI engine|Cohere|cohere-ai|cohere-ai/1.0|cohere-training-data-crawler|Common Crawl|CommonCrawl|Content Harmony|
Content King|Content Optimizer|Content Samurai|Content Scraper GPT|ContentAtScale|ContentBot|Contentedge|ContentShake|Conversion AI|
Copilot|CopilotBot|CopyAI|Copymatic|Copyscape|CoreWeave|Corrective RAG|Cohere RAG|Cotoyogi|CRAB|CrawlGPT|CrawlQ AI|Crawlspace|Crew AI|CrewAI|cURL|cURL /|Crushon AI|
DALL-E|DALL-E 2|DALL·E 3|Dall-E 4|DALL-E Mini|DarkBard|DataForAI|DataForSeoBot|DataProvider|dataprovider|Datenbank Crawler|DeepAI|DeepL|DeepMind|DeepSeek|
DeepSeek R1 Y|DeepSeek V3|DeepSeek-R1|DepolarizingGPT|Deep Research|DialoGPT|Devin|Diffbot|
Doubao AI|DuckAssistBot|DuckDuckGo Chat|DuckDuckGo-Enhanced|Duck.ai|DeepSeekV2.5-Chat|DigitalOceanGenAICrawler|
Echobox|Elixir|Extended GPT Scraper|FacebookBot|FacebookBot/1.0|FacebookExternalHit|facebookexternalhit/1.1|Factset|Factset_spyderbot
Falcon|FastGPT|Firecrawl|FirecrawlAgent|FIRE-1|FIRE-1 Agent|Flux|Flyriver|flyriverbot/1.1|Frase AI|FraudGPT|FriendlyCrawler|Firebase|
AI Ghostwriter|Gato|Gemini|Gemini Agentic RAG|Gemma|Gemma 3|Gen AI|GenAI|GenAI Chat|Genspark|Go|
gentoo-chat|GenAI RAG|gen-ai|Ghostwriter|GigaChat|GLM|Google Gemini|Gemini-Deep-Research|Gemini-User|Google-CloudVertexBot|Google-Extended|GoogleAgent-Mariner|
Goose|GPT|GPT 4 Omni|GPT 4 Omni Mini|GPT Scraper|GPTBot|GPTBot /|GPTBot/1.2|GPTZero|GPT-1|GPT-2|GPT-3|GPT-3.5|GPT-3.5 turbo|
GPT-4|GPT-4o|GPT-4o Image|GPT-4o mini|GPT-4V|GPT-4,5|gpt-4-turbo|GPT-4.1|GPT-4.1-mini|GPT-4.1-nano|GPT-5|GPT-5 Mini|GPT-5 Nano|GPT-5 Chat|
gpt-crawler|GPT /|GPT-oss /|GPT4Free|GPT Researcher|Grammarly|Grendizer|Grok|Grok AI chatbot|GrokAI|GT Bot|GTBot|GTP|GTPBOT
Hemingway Editor|Hugging Face|Hypotenuse AI|Hybrid Search RAG|hybrid LLM|Hunyuan-Large-Instruct|Hunyuan-7B-Instruct	7B|	
iAskBot|iaskspider|iaskspider/2.0|ICC-Crawler|ImageGen|ImageGen /|ImagesiftBot|
img2dataset|imgproxy|ImageGPT|Inferkit|INK Editor|INKforall|IntelliSeek|IntelliSeek.ai|Instructor|instructor-php|ISSCyberRiskCrawler|
JasperAI|Janitor AI|Jenni AI|Julius AI|
Kaggle agent|Kafkai|Kaggle|Kangaroo|Kangaroo Bot|Keyword Density AI|Knowledge|knowledge-base|knowledge /|KomoBot|Kimi K2|Kimi-2|Kimi-k1.5|Kimi-VL|
LangChain|LangExtract|langchain-google-genai|Langchain raptor|langchain-perplexity|langchain-openai|Le Chat|
LeftWingGPT|Lensa|Lightpanda|LinerBot|LINER Bot|LLaMA|Llama 3.2|Llama 4|LLM|LLM Scraper|Local RAG Agent|Llama 3.1 Local RAG|
Llama3.1-405B-Instruct|	Llama3.1-70B-Instruct|Local Hybrid Search RAG|LiteLLM Proxy|
magpie-crawler|Manus|Magistral|MarketMuse|Meltwater|Meta AI|Meta AI Crawler|Meta Llama|MetaAI|Meta-AI|Meta.AI|Meta-AI|MetaGPT|MetaTagBot|Meta-External|Meta-ExternalAgent|Meta-ExternalFetcher|
meta-externalfetcher|meta-externalfetcher/1.1|MiniMax|Mini AGI|Mistral|MistralAI-User/1.0|meta-webindexer/1.1|Meta-Webindexer 1.1|Meta-Webindexer 1/1|Mixtral 8x22B|
Mixtral-8x22B-Instruct|midjourney|Monica|model-training|
Narrative|NeevaBot|Neural Text|NeuralSEO|netEstate Imprint Crawler|Nicecrawler|NinjaAIBot/1.0|NinjaAI|Nova Act|NovaAct|NodeZero|Node.js|n8n-nodes-aiscrape
OAI SearchBot|OAI-SearchBot|OAI-SearchBot/1.0compatible; OAI-SearchBot/1.0|Omgili|Omgilibot|OASIS|Open AI|OpenAI|OpenAI Crawler|OpenAI CUA|OpenAI o1|OpenAI o3|OpenAI o4|
OpenAI o1-mini|OpenAI o3-mini|OpenAI o4-mini|OpenAI Operator|OpenAIContentCrawler|Open Deep Research|Open Perflexity|
Openbot|OpenText AI|Operator|OpenAI GPTBot|OpenAI Image Downloader|openpi|OpenAGI|Open Interpreter|Open Lovable|Outwrite|Olivia|Ola|
Page Analyzer AI|PanguBot|Panscient|panscient.com|PaperLiBot|Paraphraser.io|peer39_crawler|peer39_crawler/1.0|Perplexity|PerplexityBot|
PerplexityBot/1.0|PerplexityUser|Perplexity-User|Perplexity-User/1.0|Perplexit-User|Perplexity Deep Research|PerfectChatGPT|
Open Perflexity|petalBot|PetalBot|Phind|PhindBot|PiplBot|ProWritingAid|proximic|Puppeteer|Poe|PoeBot|PoeSearchBot|python Ai
Qualified|QualifiedBot|QuillBotquillbot.com|Quark|Qwen|qwen /|Qwen Chat|Qwen-Chat|Qwen2|Qwen3|Qwen 4|qwen:4b|Qwen 4 LLM|QwenLM|Qwen2.5 72B|Qwen 2.5‑VL||Qwen-Agent|Qopywriter.ai|
RAG|RAG Agent|RAG Agent Cohere|RAG Azure AI|RAG Chatbot|RAG ChatGPT|RAG LLM|RAG pipeline|RAG Database Routing|RAG-as-a-Service|RAG_VertexAI|RAG_with_search|
Redis AI RAG|RAG IS|RAG Search|RAG with|Raptor|ReAct AI Agent|React Agent|RAPTOR LLM|RightWingGPT|RobotSpider|Rytr|
SaplingAI|Scala|Scalenut|ScrapeGraph|ScrapeGraphAI|Scrapegraph-ai|Scraper|ScraperGPT|Scrapy|Scrapy 2.12.0|Scrapy 2.13.1|Scrapy/2.0|
ScriptBook|Search GPT|SearchGPT|Seekr|SemrushBot|SemrushBot-FT|SemrushBot-OCOB|SemrushBot-SWA|ShapBot|Sentibot|SEO Content Machine|
SEO Robot|SEObot|ShadowGPT|Sidetrade|Sidetrade /|Simplified AI|Sitefinity|skrape.ai|Skydancer|SlickWrite|SmartBot|SmartScrape|
Sonic|Sora|Spin Rewrite|Spinbot|Stability AI|StableDiffusionBot|Sudowrite|SummalyBot|Super Agent|Superagent|superagi|Surfer AI|SmartScraperGraph|spawning-ai|Spider/2.0; +https://spider.cloud
Text Blaze|TextCortex|KnowledgeThe Knowledge AI|thehive.a1|Thinkbot|Thinkbot/0.5.8|TikTokSpider|Timpibot|Traefik|TerraCotta|TorChat|Thordata|Together AI|TurnitinBot|
VelenPublicWebCrawler|Venus Chub AI|Vidnami AI|Vision RAG|WebChatGPT|WebCrawler-AI|Webscrape AI|Webscrape|webscraping-ai-ruby|webscraping-ai-php|webscraping-ai-python|WebText||WebText /|Webzio|
Webzio-Extended|WeChat|Whisper|WordAI|Wordtune|WormGPT|WormGPT V3.0|WPBot|wpbot|WPBot/1.1|WPBot/1.2|AI – WPBot|Writecream|WriterZen|Writescope|Writesonic|WRTNBot|WRTNBot/1.0| 
xAI|xBot|x.AI|YaML|YandexGPT|YandexLLM|YandexAdditional|YandexAdditionalBot|yarchatgpt|YarGPT|YouBot|YourGPT|Zero /|Zero|Zero GTP|ZeroCHAT|Zerochat|ZeroGPT|ZeroSearch|Zhuque AI|Zhuque AI Detector|Zhipu|XXXGPT|Zimm"
    
    handle @botForbidden   {
            respond /* "Access denied" 403 {
                close
            }
        }

        file_server
        root * /path/to/your/blog/public
        log {
                output file /path/to/your/logs/your-blog-access.log {
                        roll_size 20mb
                        roll_keep 10
                        roll_keep_for 720h
                }
        }
}


The @botForbidden and the related handle @botForbidden instruction are the important bits of configuration in order to return a 403 Forbidden status to the bots. The rest of the config should be customized taking into account your specific configuration; as you can see, I also added a logging section in order to keep track of requests.

To test if everything is ok, you can use cURL or change the User-Agent header from Chrome’s dev tools. Since I’m using Firefox and it’s a bit less practical to change the User-Agent setting in this case, I will tell you how to use curl.