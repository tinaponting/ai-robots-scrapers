# AI Shield WordPress Plugin - Enhanced Version

## Overview

AI Shield is an enhanced WordPress plugin designed to protect your content from being harvested by AI scrapers and bots. This improved version includes a sophisticated honeypot system that serves fake content to detected bots while providing the real content to human visitors.

## Features

### 🛡️ Dual Protection Modes

1. **Traditional Obscuration Mode**: Inserts invisible zero-width characters into content to disrupt AI training
2. **NEW: Honeypot Mode**: Serves completely fake content to detected bots while showing real content to humans

### 🎯 Smart Bot Detection

The plugin automatically detects bots and scrapers using multiple indicators:

- **User Agent Analysis**: Detects common bot patterns including:
  - AI scrapers (OpenAI, GPT, Claude, ChatGPT, etc.)
  - Search engine bots (Googlebot, Bingbot, etc.)
  - Generic scrapers (curl, wget, Python requests, etc.)
  - Headless browsers (Phantom, Selenium, Playwright)
  
- **Behavioral Analysis**: Identifies suspicious patterns:
  - Missing common browser headers
  - Suspicious accept headers
  - Headless browser indicators
  - Multiple bot indicators present

### 🍯 Honeypot Strategies

**Replace Mode** (Default):
- Serves completely fake Lorem Ipsum-style content to bots
- Maintains similar structure and length to original content
- Zero real content exposure

**Combine Mode** (Advanced):
- Mixes fake content with obscured real content
- Makes bot detection harder by providing some "real-looking" data
- Reduces training quality through contaminated data

### 📊 Monitoring & Logging

- **Bot Attempt Logging**: Track when bots are detected and served dummy content
- **User Agent Logging**: See exactly which bots are trying to scrape your content
- **IP Address Tracking**: Monitor scraping attempts by source

### ⚡ Performance Features

- **Smart Caching**: Caches both dummy and processed content to reduce server load
- **Configurable Cache Duration**: Set cache expiration from 1 minute to 24+ hours
- **Efficient Processing**: Minimal impact on human visitor experience

## Installation

1. Upload the `ai-shield` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the WordPress admin panel
3. Navigate to Settings > AI Shield to configure options

## Configuration Options

### Basic Settings

- **Enabled**: Master switch to enable/disable the plugin
- **Cache Enabled**: Enable caching of processed content for better performance
- **Cache Duration**: How long to cache content (in minutes)

### Honeypot Settings

- **Honeypot Mode**: Enable the advanced honeypot system
- **Honeypot Strategy**: 
  - `Replace`: Serve only fake content to bots
  - `Combine`: Mix fake content with obscured real content
- **Log Bot Attempts**: Record bot detection events in WordPress error logs

## How It Works

### For Human Visitors
1. Content is served normally (or with invisible character obscuration if traditional mode is also enabled)
2. Reading experience is completely unaffected
3. No performance impact

### For Detected Bots
1. Bot detection algorithms analyze the request
2. If a bot is detected:
   - **Replace Mode**: Completely fake content is generated and served
   - **Combine Mode**: Fake content is mixed with obscured real content
3. Bot receives plausible but fake content
4. Attempt is logged (if enabled)

### Content Generation
- Dummy content maintains similar structure to original (headings, paragraphs, etc.)
- Word count and paragraph count approximately match original
- Content uses varied Lorem Ipsum-style text
- Multiple template variations prevent pattern recognition

## Advanced Features

### Debug Mode
Add `?ai_shield_debug=true` to any URL to see how content is being processed (visible characters replace invisible ones for testing).

### Cache Management
- Separate cache keys for human vs. bot content
- Cache invalidation when content changes
- Configurable expiration times

### Logging
Bot detection events are logged to WordPress error logs with details:
```
AI Shield Honeypot: Bot detected - IP: 123.456.789.0, UA: SomeBot/1.0, Mode: replace
```

## Best Practices

1. **Enable Honeypot Mode**: More effective than traditional obscuration alone
2. **Use Replace Mode**: Provides maximum protection by serving zero real content to bots
3. **Enable Logging**: Monitor bot activity to understand scraping patterns
4. **Configure Appropriate Cache Duration**: Balance performance vs. content freshness
5. **Test with Debug Mode**: Verify the plugin is working as expected

## Technical Details

### Bot Detection Accuracy
The plugin uses a scoring system that considers multiple factors:
- User agent patterns (most reliable)
- Missing browser headers
- Suspicious request patterns
- Known bot IP ranges

### Performance Impact
- Minimal impact on human visitors
- Caching reduces server load
- Bot processing is slightly higher but acceptable

### Content Quality
- Dummy content is designed to appear legitimate to basic analysis
- Maintains structural similarity to original content
- Uses varied templates to avoid pattern detection

## Troubleshooting

### Plugin Not Working
1. Check that the plugin is activated
2. Verify settings are saved correctly
3. Clear any caching plugins
4. Test with debug mode

### False Positives
If legitimate users are getting dummy content:
1. Check user agent patterns in logs
2. Reduce bot detection sensitivity
3. Whitelist specific user agents if needed

### Performance Issues
1. Enable caching
2. Increase cache duration
3. Consider server resources for high-traffic sites

## Changelog

### v1.1.0 (Enhanced Version)
- Added honeypot mode with dummy content generation
- Implemented advanced bot detection
- Added combine mode for mixing fake and real content
- Enhanced logging and monitoring
- Improved caching system
- Added debug mode for testing

### v1.0.3 (Original)
- Basic zero-width character obscuration
- Simple caching system
- WordPress admin integration

## Support

This enhanced version builds upon the original AI Shield plugin by Matthew Davidson, extending it with advanced honeypot capabilities for superior bot protection.

## License

GPL-2.0 - Same as original plugin

---

**Protect your content effectively**: This enhanced AI Shield plugin provides a sophisticated multi-layered defense against AI content harvesting while maintaining an excellent experience for legitimate human visitors.
