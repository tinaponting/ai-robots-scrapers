<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
    
/**
 * Provide a admin area view for the plugin. Currently unused as all config is done with Settings API
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @since      1.0.0
 *
 * @package    Ai_Shield
 * @subpackage Ai_Shield/admin/partials
 */
?>
