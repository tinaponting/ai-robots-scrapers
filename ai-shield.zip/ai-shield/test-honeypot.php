<?php
/**
 * AI Shield Bot Detection Test
 * 
 * This file allows you to test the honeypot functionality
 * outside of WordPress for development/testing purposes.
 */

class AI_Shield_Test {
    
    private $bot_user_agents;
    private $dummy_content_templates;
    
    public function __construct() {
        // Initialize bot detection patterns
        $this->bot_user_agents = [  
			'aiohttp','aiohttp/3.12.15','apache-useragent','Apache-HttpClient','Apache\-HttpClient','apache-json-scanners',
			'apache-scanners','404checker','ALittle Client','Amazonbot','amazonbot','ahrefsbot','AhrefsBot','AhrefsSiteAudit','AhrefsBot/7.0',
			'Apache Nutch','apache-scanners','bot','BLEXBot/1.0','Barkrowler','BUbiNG','BitSightBot/1.0','crawl','CensysInspect',
			'curl','copyseeker.net','dotbot','DataForSeoBot','DomainStatsBot','evc-batch','Extreme Picture Finder','Guzzle', 'GuzzleHttp', 
            'GuzzleHttp/7', 'Go1.1packagehttp', 'golang', 'Golang Scraper', 'Go Web Scraping', 'Go-http-client', 'Go-http-client/1.1', 
            'Go-http-client/2.0', 'Grabber', 'HeadlessChrome','Headless','Headless scraping','HeadlessChrome','Headless','Headless Edg',
            'headless.py','HtmlRequestScraper','HTTP_Request','HTTP requests','HTTP_Request2','httpbin','httpbin/headers','httplib',
            'http','HTTPX','Fetch''node-fetch''Favicon Fetcher''fetchurl''FaceBot''Fuzz Faster U Fool''Fuzz Faster U Fool v2.0.0''Java'
			'java''JavaScript''Java-http-client''libwww 6.05''libwww-perl-6.77''libwww-perl''libcurl''InternetMeasurement/1.0''meta-externalagent'
			'meta-externalagent/1.1''Majestic''MJ12bot''middleware.py''Nikto''Ninja''Nuclei''Nutch''Nmap''mass-scan''Next.js middleware''OpenVAS'
			'openvas''openai','Odin''playwright','Python''Pyth''pyscan''py''PyQ''python''python-http''python-requests''python\-requests''Python Requests'
            'python-requests/2.32.3''PythonRequests''Python-urllib''Python\-urllib''python aiohttp''python-httpx''phantom','Photon''Photon/1.0''Prometheus''php''PHP''php://input'
            'python-async''PycURL''Python-urllib''phpCrawler''PHP Meterpreter''ProFaceFinder''Python Scrapy''Python/3.12 aiohttp/3.12.15''requests','SEOkicks'
			'selenium','serpstatbot''Screaming Frog SEO Spider''SF''spider', 'scraper', 'scrape','SemrushBot''SemrushBot-BA''SemrushBot-SA'
            'SemrushBot/7~bl''SemrushBot-OCOB''SemrushBot-SWA''SemrushBot-SISF''SemrushBot-SI''SemrushBot-SWA''SemrushBot-CT'
            'SemrushBot-BM''SemrushBot-FT''SSL/TLS Scan''SSL Scanner''Sec-Fetch-Site''scan''scanner''scraperbot''SQLMap''sqlmap''SCAN''serpstatbot''TinEye''TinEye-bot'
            'TestNutchBot''test-bot''TestURI''test''TestBot''test-bot''/test/''Test Spider''twitterbot''Timpibot/0.9''TikTokSpider'
			'Vulnerability-Scanner /''WPScan''WP Scan''WEB-Scan''WPScan CLI Scanner''wp-request''wordpress-sniffer''woorank''Wget''wget'
            'WPSec''Web Image Collector''WebSniffer''wordpress-sniffer''Web shells''webscraper''Windows''Windows NT 10.0; Win64; x64|Windows NT 10.0'
            'Urllib''urllib.request''Xenu''Zeus''Zgrab''YaK''ZmEu''Zend_Http_Client''Xenu Link Checker'
		    ".ai","-ai","_ai","ai.","ai-","ai_","ai=",".*?-ai$", "ai=n",
		    "AcademicBotRTU","AddSearchBot","Agent 3","Agent API","Agent GPT","Agent Middleware","AgentGPT","AgentGPT",
		    "Agentic Deep Research","Agentic RAG with LangGraph","Agentic RAG","Agentic","Agentic-RAG","AgentQL","AI agents /","AI Agent","AI Article Writer",
		    "AI Chatbot","AI Chat","AI Content Detector","AI copilot","AI Detection","AI Dungeon","AI Journalist Agent","AI Journalist",
		    "AI Legion","AI RAG","AI Scraper","AI Search Engine","AI Search Intent","AI Search","AI SEO Crawler","AI Web Scraper",
		    "AI Website Screenshot","AI Web","AI Writer","AI2 Bot","AI2Bot","AI2","AI21 Labs","AIBot","aiHitBot","AIMatrix","AISearchBot",
            "AISearch","AITraining /","AITraining","ai-crawlers-training","AI-Crawler","ai-proxy","AlexaTM","Alexa","Alice Yandex","AliGenie",
            "AliyunSecBot","AliyunSec","Alpha AI","AlphaAI","Amazon Athena","Amazon Bedrock","Amazon Comprehend","Amazon Lex","Amazon SageMaker",
            "Amazon Silk","Amazon Textract","Amazonbot","amazonBot","Amazon","amazon-kendra","AutoGen","AutoGPT","AWS bedrock","AWS Trainium",
            "Amelia","AndiBot","Anonymous AI","anonymous AI chatbot","Anthropic","anthropic-ai","AnyPicker","AnythingLLM","Anyword","Applebot-Extended","Apple-GenAI",
            "Aria AI","Aria Browse","Aria browse Aria AI","Aria browser AI","Articoolo","Ask AI","AutoGLM","AutoGPT","Automated Writer","AutoML",
            "Autonomous RAG","AwarioRssBot","AwarioSmartBot","Azure","Azure AI Search","Azure OpenAI","BabyAGI","BabyCatAGI","BardBot",
		    "Basic RAG Chain","Basic RAG","Bedrock Claude","Bedrock","bedrock-chatbot","bedrock-chat","bedrock-claude-chatbot",
		    "Big Sur AI Crawler","Big Sur AI","Big Sur","Bigsur","bigsur.ai","Botsonic","Brave Leo AI","BraveGPT","Brightbot 1.0",
		    "Brightbot operator""Brightbot","Browser MCP Agent","Browser Use","Bytebot","ByteDance crawler","ByteDance","bytedance","Bytespider",
            "CarynAI","CatBoost","CCBot","ccbot","CCBot/2.0","CC-Crawler","CC-Crawler/2.0","Celia","Ceramic TerraCotta Crawler","Chai",
            "Character","Charstar AI","Chat2DB-Agent","ChatAnthropic","Chatbot","chatbot","ChatGLM","ChatGLM-Spider","ChatGPT 3.0","ChatGPT 4o","ChatGPT 4o-mini",
            "ChatGPT 4.1","ChatGPT 4.5","ChatGPT 5","ChatGPT Agent","ChatGPT o1","ChatGPT o3-mini","ChatGPT Operator","ChatGPT search",
            "ChatGPT","ChatGPT-User","ChatGPT-User/1.0","ChatGPT-User/2.0","ChatLLM","ChatOpenAI","Chatsonic","chatUser /",
            "ChatUser","Chinchilla","Claude 3.5 Haiku","Claude 3.5 Sonnet","Claude 3.5","Claude 3.7 Sonnet","Claude 4","Claude LLM",
            "Claude Opus 4","Claude Opus 4.1","Claude Opus","Claude Sonnet 4","Claude Sonnet 4.5","ClaudeBot","ClaudeBot/1.0",
            "ClaudeBot/1.0","Claude","Claude Agent","Claude-RAG","Claude-SearchBot","Claude-User","Claude-Web","claude-web/1.0",
            "claude.ai","ClearScope","Clearview","Cognitive AI engine","Cognitive AI","Cohere RAG","Cohere","cohere-ai","cohere-ai/1.0",
            "cohere-training-data-crawler","Common Crawl","CommonCrawl","Content Harmony","Content King","Content Optimizer","Content Samurai",
            "Content Scraper GPT","ContentAtScale","ContentBot","Contentedge","ContentShake","Conversion AI","CopilotBot","Copilot",
            "CopyAI","Copymatic","Copyscape","CoreWeave","Corrective RAG","Cotoyogi","CRAB","Crawl4AI","CrawlGPT","CrawlQ AI","Crawlspace",
            "CrewAI","Crushon AI","cURL /","cURL","DALL-E 2","Dall-E 4","DALL-E Mini","DALL-E","DALL·E 3","DarkBard","DataForAI",
            "DataForSeoBot","DataFor","DataProvider","dataprovider","Datenbank Crawler","Deep AI","Deepseek Agent","Deep Research","DeepAI","DeepL",
            "DeepMind","DeepResearch","Deepseek Local RAG Agent","DeepSeek R1 Y","DeepSeek V3","DeepSeekBot ","DeepSeekV2.5-Chat","DeepSeek",
            "DeepSeek-LLM","DeepSeek-R1","DepolarizingGPT","Devin","DialoGPT","Diffbot","DigitalOceanGenAICrawler","Doubao AI","DuckAssistBot",
            "DuckDuckGo Chat","DuckDuckGo-Enhanced","Duck.ai","Echobot","Echobox","Elixir","Extended GPT Scraper","FacebookBot","FacebookBot/1.0",
		    "FacebookExternalHit","facebookexternalhit/1.1","Factset_spyderbot","Falcon","Fastai","FastGPT","Firebase","FirecrawlAgent","Firecrawl",
		    "Fireworks","FIRE-1 Agent","FIRE-1","Flux","flyriverbot/1.1","Flyriver","Frase AI","FraudGPT","FriendlyCrawler","AI Ghostwriter",
		    "Gato","Gemini Agentic RAG","Gemini User","Gemini","Gemini-Deep-Research","Gemma 3","Gemma","Gen AI","GenAI Chat","GenAI RAG","GenAI",
		    "Generative","Genspark","gentoo-chat","gen-ai","Ghostwriter","GigaChat","GLM","GodMode","Google Gemini","GoogleAgent-Mariner",
		    "Google-CloudVertexBot","Google-Extended","Goose","Go","GPT 4 Omni Mini","GPT 4 Omni","GPT Chat 3","GPT OSS","GPT Researcher",
		    "GPT Scraper","GPT /","GPT4ALL","GPT4Free","GPTBot /","GPTBot","GPTBot/1,2","GPTBot/1.2","GPTZero","GPT","GPT-1","GPT-2","GPT-3",
		    "GPT-3.5 turbo","GPT-3.5","GPT-4o Image","GPT-4o mini","GPT-4o","GPT-4V","GPT-4","GPT-4,5","gpt-4-turbo","GPT-4.1","GPT-4.1-mini",
		    "GPT-4.1-nano","GPT-5 Chat","GPT-5 Mini","GPT-5 Nano","GPT-5 Thinking mini","GPT-5o","GPT-5","GPT-5","gpt-crawler",
		    "GPT-oss /","GPT/","Grammarly","Grendizer","Grok 4 Fast","Grok AI chatbot","GrokAI","Grok","GrokBot","GT Bot","GTBot",
		    "GTPBOT","GTP","Hemingway Editor","Hetzner","Hugging Face","HuggingChat","Hugging","Hunyuan","Hunyuan-7B-Instruct 7B",
		    "Hunyuan-Large-Instruct ","hybrid LLM","Hybrid Search RAG","Hypotenuse AI","iAskBot","imgproxy","iaskspider","iaskspider/2.0",
		    "iAskBot","ICC-Crawler","ImagesiftBot","img2dataset","ImageGen","ImageGen /","ImageGPT","Inferkit","INK Editor","INKforall",
		    "IntelliSeek","IntelliSeek.ai","Instructor","instructor-php","ISSCyberRiskCrawler","Jamba 1.5 Large","Jamba 1.5 Mini",
		    "Janitor AI","JasperAI","Jenni AI","Julius AI","Kafkai","Kaggle agent","Kaggle","Kangaroo Bot","Kangaroo","Kangaroo-Bot",
		    "Keyword Density AI","Kimi K2","Kimi","Kimi-2","Kimi-k1.5","Kimi-VL","Kingsoft-LLM","Knowledge Graph","knowledge /","Knowledge",
		    "Knowledge","knowledge-base","KomoBot","Kruti","Lovable","LocalAI","Local RAG","Local RAG Agent","Local Hybrid Search RAG","LLM",
		    "LLM Scraper","LLM Proxy","LLaMA","Llama3.1-405B-Instruct","Llama3.1-70B-Instruct","Llama 4","Llama 3.2","Llama 3.1 Local RAG",
		    "LiteLLM","LiteLLM Python","LiteLLM Proxy","LinerBot","LinerBot","Lightpanda","Lensa","LeftWingGPT","Le Chat","LangExtract",
		    "langchain-perplexity","langchain-openai","langchain-google-genai","LangChain","Langchain raptor","Magistral","Magnus",
		    "magpie-crawler","Manus","MarketMuse","Meltwater","Meta Agent","Meta AI Crawler","Meta AI","Meta Llama","MetaAI",
		    "MetaGPT","MetaTagBot","MetaTagBot","Meta-AI","Meta-ExternalAgent","meta-externalagent","Meta-ExternalFetcher",
		    "meta-externalfetcher/1.1","Meta-External","Meta-Webindexer 1.1","Meta-Webindexer","meta-webindexer/1.1","Meta.AI",
		    "Middleware","midjourney","Mini AGI","MiniMax","Mintlify","MistralAI-User","MistralAI-User/1.0","Mistral","Mistral.ai",
		    "Mixtral 8x22B","Mixtral-8x22B-Instruct","MobileLLM-R1","model-training","Monica","Moonshot ","Mycroft AI","n8n-nodes-aiscraper",
		    "Narrative Device","Narrative","Narrative","NeevaBot","netEstate Imprint Crawler","netEstate","Neural Text","NeuralSEO",
		    "Nicecrawler","Nicecrawler","NinjaAIBot/1.0","NinjaAIBot/1.0","NinjaAI","NodeZero","Node.js","Nova Act","NovaAct",
		    "OAI SearchBot","OAI-SearchBot","OAI-SearchBot/1.0","OASIS","Ola","Olivia","Ollama","oLLM","Omgilibot","Omgili","Open AI",
		    "Open Deep Research","Open Deep Research","Open Interpreter","Open Lovable","Open Perflexity","OpenAGI","OpenAI Crawler","OpenAI CUA",
		    "OpenAI GPTBot","OpenAI Image Downloader","OpenAI o1","OpenAI o1-mini","OpenAI o3","OpenAI o3","OpenAI o3-mini","OpenAI o4",
		    "OpenAI o4-mini","OpenAI Operator","OpenAIContentCrawler","OpenAI","OpenBot","OpenLens AI","openpi","OpenRouter","openrouter",
		    "OpenText AI","Operator","Outwrite","OWL","Perflexity","Perplexity AI","Perplexity Search","Petal","PyTorch Lightning LLM",
		    "PyTorch Lightning","Page Analyzer AI","PanguBot","Panscient","panscient.com","PaperLiBot","Paraphraser.io","peer39_crawler",
		    "peer39_crawler/1.0","PerfectChatGPT","Perplexity Deep Research","PerplexityBot","PerplexityBot/1.0","PerplexityUser","Perplexity",
		    "perplexity**.ai","Perplexity-User","Perplexity-User/1.0","Perplexit-User","Open Perflexity","PetalBot","petalBot","PhindBot","Phind",
		    "PiplBot","PoeBot","PoeSearchBot","Poe","PrivateGPT","ProWritingAid","proximic","Puppeteer","python Ai","Qwen","qwen /","Qwen","Qwen-Agent","Qwen Chat",
		    "Qwen-Chat","Qwen2","Qwen3","Qwen 4","qwen:4b","Qwen 4 LLM","QwenLM","Qwen2.5 72B",	"Qwen 2.5‑VL","Qualified","QualifiedBot",	
		    "quillbot.com",	"QuillBot","Quark","Qopywriter.ai","AI RAG ","Llama 3.1 Local RAG","Local Hybrid Search RAG","Local RAG Agent",
		    "RAG Agent Cohere","RAG Agent with Cohere","RAG Agent","RAG Azure AI","RAG Chatbot","RAG ChatGPT","RAG Database","RAG IS ",
		    "RAG LLM","RAG pipeline","RAG Search","RAG with Database Routing","RAG with ","RAG","RAG-as-a-Service","RAG-","RAG_VertexAI",
		    "RAG_with_search","RAG_","RAPTOR LLM","Raptor","React Agent","ReAct AI Agent","ReaderLM-v2","ReadyAI","Redis AI RAG ","RightWingGPT",
		    "RobotSpider","Rytr","Sambanova","SaplingAI","Scala","Scalenut","ScrapeGraphAI","ScrapeGraph","Scrapegraph-ai","ScraperGPT","Scraper",
		    "Scrapy 2.12.0","Scrapy 2.13.1","Scrapy","Scrapy/2.0","ScriptBook","Search GPT","Search RAG","SearchGPT","Seekr","SemrushBot",
		    "SemrushBot-FT","SemrushBot-OCOB","SemrushBot-SWA","Sentibot","SEO Content Machine","SEO Robot","SEObot","ShadowGPT","ShapBot",
		    "ShapBot","Shell GPT","Sidetrade /","Sidetrade","Simplified AI","Sitefinity","skrape.ai","Skydancer","SlickWrite","SmartBot",
		    "SmartScraperGraph","SmartScrape","Sonic","Sora","spawning-ai","Spider-Agent","Spider/2.0; +https://spider.cloud","Spin Rewrite",
		    "Spinbot","Stability AI","StableDiffusionBot","Sudowrite","SummalyBot","Super Agent","Superagent","superagi","Surfer AI","SUSE AI ","Knowledge","TerraCotta","Text Blaze","TextCortex",
		    "Text-RAG","The Knowledge AI","thehive.ai","Thinkbot","Thinkbot/0.5.8","Thordata","TikTokSpider","Timpibot",
		    "together AI","TorChat","Traefik","TurnitinBot","uAgents","AI – WPBot","Scrapegraph-ai","VelenPublicWebCrawler",
		    "Venus AI","Venus Chub AI","Vidnami AI","Vision RAG","vnCallbot","vnFace","VNPT SmartBot","VNPT SmartReader",
		    "Web 3.0 Navigator","WebChatGPT","WebCrawler-AI","WebCrawler-AI","WebExplorer-","Webscrape AI","Webscrape AI","Webscrape",
		    "webscraping-ai-php","webscraping-ai-python","webscraping-ai-ruby","WebSurfer","WebText /","WebText","Webzio",
		    "Webzio-Extended","WeChat","Whisper","WizardLM","WordAI","Wordtune","WormGPT V3.0","WormGTP","wormsGTP",
		    "WPBot","wpbot","WPBot/1.1","WPBot/1.2","WPBot/1.2","Writecream","WriterZen","Writescope","Writesonic","WRTNBot",
		    "WRTNBot","WRTNBot/1.0","WRTNBot/1.0","xAI","X.AI","xBot","yarchatgpt","YandexGPT","YandexLLM","YandexAdditional",
		    "YandexAdditionalBot","YaLM","YarGPT","YarGPTZero /","YouBot","YourGPT","Zero","Zero /","Zero GTP","ZeroCHAT",
		    "Zerochat","ZeroGPT","ZeroSearch","Zhipu","Zhuque AI","Zhuque AI Detector","XXXGPT","Zhuque AI","Zimm",	
        ];
        
        // Initialize dummy content templates
        $this->dummy_content_templates = [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
            'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
            'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
            'Tempor incididunt ut labore et dolore magna aliqua ut enim.',
            'Ad minim veniam quis nostrud exercitation ullamco laboris nisi.',
            'Aliquip ex ea commodo consequat duis aute irure dolor in.',
            'Reprehenderit in voluptate velit esse cillum dolore eu fugiat.',
            'Nulla pariatur excepteur sint occaecat cupidatat non proident.'
        ];
    }
    
    /**
     * Test bot detection with various user agents
     */
    public function test_bot_detection() {
        echo "<h2>Bot Detection Test Results</h2>\n";
        
        $test_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' => 'Human Browser',
            'curl/7.68.0' => 'cURL Bot',
            'OpenAI-GPT/1.0' => 'OpenAI Bot',
            'python-requests/2.25.1' => 'Python Requests',
            'Googlebot/2.1' => 'Google Bot',
            'ChatGPT-User' => 'ChatGPT User',
            'Mozilla/5.0 (compatible; bingbot/2.0)' => 'Bing Bot',
            'Headless Chrome' => 'Headless Browser'
        ];
        
        echo "<table border='1' cellpadding='5'>\n";
        echo "<tr><th>User Agent</th><th>Type</th><th>Bot Detected</th></tr>\n";
        
        foreach ($test_agents as $agent => $description) {
            $is_bot = $this->is_bot_request($agent);
            $result = $is_bot ? '✅ YES' : '❌ NO';
            echo "<tr><td><code>" . htmlspecialchars($agent) . "</code></td><td>{$description}</td><td>{$result}</td></tr>\n";
        }
        
        echo "</table>\n";
    }
    
    /**
     * Test dummy content generation
     */
    public function test_dummy_content() {
        $original_content = "<h2>Original Article Title</h2>
        <p>This is the original content that should be protected from AI scrapers. It contains valuable information that we don't want to be used for training AI models.</p>
        <p>This is a second paragraph with more important content that should remain private and not be harvested by bots or scrapers.</p>";
        
        echo "<h2>Dummy Content Generation Test</h2>\n";
        echo "<h3>Original Content:</h3>\n";
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px 0;'>" . $original_content . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Replace Mode):</h3>\n";
        $dummy_replace = $this->generate_dummy_content($original_content, 'replace');
        echo "<div style='border: 1px solid #f0ad4e; padding: 10px; margin: 10px 0;'>" . $dummy_replace . "</div>\n";
        
        echo "<h3>Generated Dummy Content (Combine Mode):</h3>\n";
        $dummy_combine = $this->generate_dummy_content($original_content, 'combine');
        echo "<div style='border: 1px solid #d9534f; padding: 10px; margin: 10px 0;'>" . $dummy_combine . "</div>\n";
    }
    
    /**
     * Detects if the request is from a bot
     */
    private function is_bot_request($user_agent = null) {
        $user_agent = $user_agent ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
        $user_agent_lower = strtolower($user_agent);
        
        // Check for bot patterns in user agent
        foreach ($this->bot_user_agents as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Generate dummy content
     */
    private function generate_dummy_content($original_content, $mode = 'replace') {
        // Get original content stats
        $word_count = str_word_count(strip_tags($original_content));
        $paragraph_count = substr_count($original_content, '</p>') + 1;
        
        // Generate similar length dummy content
        $dummy_sentences = [];
        $sentences_needed = max(3, intval($word_count / 15));
        
        for ($i = 0; $i < $sentences_needed; $i++) {
            $template = $this->dummy_content_templates[array_rand($this->dummy_content_templates)];
            
            // Add some variation
            $variations = [
                str_replace('Lorem', 'Ipsum', $template),
                str_replace('dolor', 'amet', $template),
                str_replace('consectetur', 'adipiscing', $template),
                $template . ' Vestibulum ante ipsum primis in faucibus.',
                'Nullam quis risus eget urna mollis ornare vel eu leo. ' . $template,
            ];
            
            $dummy_sentences[] = $variations[array_rand($variations)];
        }
        
        // Group into paragraphs
        $sentences_per_paragraph = max(2, intval($sentences_needed / $paragraph_count));
        $paragraphs = array_chunk($dummy_sentences, $sentences_per_paragraph);
        
        $dummy_content = '';
        foreach ($paragraphs as $paragraph) {
            $dummy_content .= '<p>' . implode(' ', $paragraph) . '</p>';
        }
        
        // If original had title structure, mimic it
        if (strpos($original_content, '</h') !== false) {
            $dummy_title = 'Sample Article Title for Educational Purposes';
            $dummy_content = '<h2>' . $dummy_title . '</h2>' . $dummy_content;
        }
        
        return $dummy_content;
    }
}

// Run the test
echo "<html><head><title>AI Shield Test</title></head><body>";
echo "<h1>AI Shield Honeypot Test Suite</h1>";

$test = new AI_Shield_Test();
$test->test_bot_detection();
$test->test_dummy_content();

echo "<h2>Current Request Analysis</h2>";
$current_ua = $_SERVER['HTTP_USER_AGENT'] ?? 'No User Agent';
$is_bot = strpos(strtolower($current_ua), 'bot') !== false || 
          strpos(strtolower($current_ua), 'crawl') !== false ||
          strpos(strtolower($current_ua), 'spider') !== false;

echo "<p><strong>Your User Agent:</strong> <code>" . htmlspecialchars($current_ua) . "</code></p>";
echo "<p><strong>Bot Detection Result:</strong> " . ($is_bot ? "🤖 Bot Detected" : "👤 Human Detected") . "</p>";

echo "</body></html>";
?>
