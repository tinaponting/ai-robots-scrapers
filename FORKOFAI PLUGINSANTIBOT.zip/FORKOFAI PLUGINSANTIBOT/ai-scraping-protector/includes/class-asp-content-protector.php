<?php
/**
 * Handle content protection functionality.
 *
 * @package    AI_Scraping_Protector
 * @subpackage AI_Scraping_Protector/includes
 */

class AISP_Content_Protector {
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta_box_data'));
    }

    public function init() {
        add_filter('the_content', array($this, 'protect_content'));
    }

    /**
     * Adds the meta box to the post editor screen.
     */
    public function add_meta_box() {
        // Add meta box to posts
        add_meta_box(
            'aisp_protection_meta_box',
            __('AI Scraping Protection', 'ai-scraping-protector'),
            array($this, 'render_meta_box'),
            'post',
            'side', // Changed from 'normal' to 'side' for better visibility
            'high'  // Changed from 'low' to 'high' for higher priority
        );

        // Add meta box to pages
        add_meta_box(
            'aisp_protection_meta_box',
            __('AI Scraping Protection', 'ai-scraping-protector'),
            array($this, 'render_meta_box'),
            'page',
            'side',
            'high'
        );
    }

    /**
     * Renders the meta box content.
     * 
     * @param WP_Post $post The post object.
     */
    public function render_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('aisp_protection_meta_box', 'aisp_protection_meta_box_nonce');

        // Get individual protection setting
        $individual_protection = get_post_meta($post->ID, '_aisp_protected', true);
        
        // Get global protection settings
        $global_posts_protection = get_option('aisp_protector_enable_posts', false);
        $global_pages_protection = get_option('aisp_protector_enable_pages', false);

        // Determine if protection is enabled globally for this post type
        $is_globally_protected = (is_page($post) && $global_pages_protection) || 
                               (!is_page($post) && $global_posts_protection);

        // If individual setting is not set and global protection is enabled,
        // we want to show the checkbox as checked
        $is_protected = ($individual_protection === '') ? 
                       $is_globally_protected : 
                       ($individual_protection === '1');
        ?>
        <div class="asp-meta-box-wrapper">
            <div class="asp-protection-options">
                <label>
                    <input type="checkbox" 
                           name="aisp_protect_content" 
                           value="1" 
                           <?php checked($is_protected, true); ?> 
                    />
                    <strong><?php esc_html_e('Enable Protection', 'ai-scraping-protector'); ?></strong>
                </label>
                
                <p class="description">
                    <?php esc_html_e('Protect this content from AI scraping attempts.', 'ai-scraping-protector'); ?>
                </p>

                <?php if ($is_globally_protected): ?>
                <div class="asp-global-notice" style="margin-top: 10px; padding: 8px; background: #f0f6fc; border-left: 4px solid #72aee6">
                    <?php 
                    if (is_page($post)) {
                        esc_html_e('Protection is enabled globally for all pages. Unchecking this box will disable protection for this specific page only.', 'ai-scraping-protector');
                    } else {
                        esc_html_e('Protection is enabled globally for all posts. Unchecking this box will disable protection for this specific post only.', 'ai-scraping-protector');
                    }
                    ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Saves the meta box data.
     * 
     * @param int $post_id The ID of the post being saved.
     */
    public function save_meta_box_data($post_id) {
        // Security checks
        if (!isset($_POST['aisp_protection_meta_box_nonce'])) {
            return;
        }

        // Sanitize and unslash the nonce
        $nonce = sanitize_text_field(wp_unslash($_POST['aisp_protection_meta_box_nonce']));

        // Verify the nonce
        if (!wp_verify_nonce($nonce, 'aisp_protection_meta_box')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Save the protection status
        $protected = isset($_POST['aisp_protect_content']) ? '1' : '0';
        update_post_meta($post_id, '_aisp_protected', $protected);
    }

    /**
     * Protects the content if protection is enabled.
     * 
     * @param string $content The post content.
     * @return string Modified content if protection is enabled.
     */
    public function protect_content($content) {
        global $post;
        
        if (!isset($post->ID)) {
            return $content;
        }

        // Check for global protection settings
        $global_posts_protection = get_option('aisp_protector_enable_posts', false);
        $global_pages_protection = get_option('aisp_protector_enable_pages', false);
        
        // Get individual post protection setting
        $individual_protection = get_post_meta($post->ID, '_aisp_protected', true);

        // Check if protection should be applied
        $should_protect = false;

        if (is_single() && ($individual_protection === '1' || $global_posts_protection)) {
            $should_protect = true;
        } elseif (is_page() && ($individual_protection === '1' || $global_pages_protection)) {
            $should_protect = true;
        }

        if ($should_protect) {
            $content = $this->apply_protection($content);
        }

        return $content;
    }

    /**
     * Applies protection mechanisms to the content.
     * 
     * @param string $content The original content.
     * @return string Protected content.
     */
    private function apply_protection($content) {
        // Add more robust protection mechanisms
        $protected_content = sprintf(
            '<div class="asp-protected-content" data-protected="true" style="user-select: none;" oncontextmenu="return false;" ondragstart="return false;" onselectstart="return false;">%s</div>',
            $content
        );
        
        // Add protection notice with better styling
        $notice = sprintf(
            '<div class="asp-protection-notice" style="margin-bottom: 20px; padding: 12px 15px; background: #f8f9fa; border-left: 4px solid #0073aa; font-size: 14px;">
                <p style="margin: 0; color: #1e1e1e;">%s</p>
            </div>',
            esc_html__('This content is protected against AI scraping.', 'ai-scraping-protector')
        );

        return $notice . $protected_content;
    }
} 