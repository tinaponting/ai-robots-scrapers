<?php
// If uninstall is not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up plugin options
delete_option('aisp_protector_enable_posts');
delete_option('aisp_protector_enable_pages');

// Use direct SQL for better performance when deleting post meta
global $wpdb;
$wpdb->query($wpdb->prepare(
    "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
    '_aisp_protector_enable_scraping_protection'
));

// Clean up transients using WordPress functions
$transient_prefix = 'aisp_rate_limit_';

// Use WordPress transient API to clean up
$offset = 0;
$limit = 100;

do {
    $transients = $wpdb->get_col($wpdb->prepare(
        "SELECT option_name 
        FROM {$wpdb->options} 
        WHERE option_name LIKE %s 
        LIMIT %d OFFSET %d",
        $wpdb->esc_like('_transient_' . $transient_prefix) . '%',
        $limit,
        $offset
    ));
    
    if (!empty($transients)) {
        foreach ($transients as $transient) {
            $name = str_replace('_transient_', '', $transient);
            delete_transient($name);
        }
    }
    
    $offset += $limit;
} while (!empty($transients));

// Clean up any remaining plugin data
$plugin_options = array(
    'aisp_protector_settings',
    'aisp_protector_version',
    'aisp_protector_installed'
);

foreach ($plugin_options as $option) {
    delete_option($option);
}

// Clear caches
wp_cache_flush(); 