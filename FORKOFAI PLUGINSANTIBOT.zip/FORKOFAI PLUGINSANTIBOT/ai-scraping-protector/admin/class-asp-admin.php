<?php
/**
 * The admin-specific functionality of the plugin.
 */

class AISP_Admin {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function add_admin_menu() {
        add_menu_page(
            esc_html__('AI Scraping Protector', 'ai-scraping-protector'),
            esc_html__('AI Scraping Protector', 'ai-scraping-protector'),
            'manage_options',
            'ai-scraping-protector',
            array($this, 'display_settings_page'),
            'dashicons-shield',
            100
        );
    }

    public function register_settings() {
        // Register settings
        register_setting(
            'aisp_protector_options',
            'aisp_protector_enable_posts',
            array(
                'type' => 'boolean',
                'sanitize_callback' => array($this, 'sanitize_checkbox'),
                'default' => false
            )
        );

        register_setting(
            'aisp_protector_options',
            'aisp_protector_enable_pages',
            array(
                'type' => 'boolean',
                'sanitize_callback' => array($this, 'sanitize_checkbox'),
                'default' => false
            )
        );
    }

    public function sanitize_checkbox($input) {
        return (isset($input) && true === (bool) $input) ? true : false;
    }

    public function enqueue_admin_assets($hook) {
        if ('toplevel_page_ai-scraping-protector' !== $hook) {
            return;
        }

        wp_enqueue_style(
            $this->plugin_name . '-admin',
            plugin_dir_url(__FILE__) . 'css/admin-styles.css',
            array(),
            $this->version
        );
    }

    public function display_settings_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Save settings if form is submitted
        if (isset($_POST['submit']) && check_admin_referer('aisp_protector_options-options')) {
            update_option('aisp_protector_enable_posts', isset($_POST['aisp_protector_enable_posts']));
            update_option('aisp_protector_enable_pages', isset($_POST['aisp_protector_enable_pages']));
            
            add_settings_error(
                'aisp_protector_messages',
                'settings_updated',
                esc_html__('Settings saved successfully!', 'ai-scraping-protector'),
                'updated'
            );
        }

        // Show settings page
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <?php settings_errors('aisp_protector_messages'); ?>

            <form method="post" action="">
                <?php
                settings_fields('aisp_protector_options');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('Enable for Posts', 'ai-scraping-protector'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="aisp_protector_enable_posts" value="1" <?php checked(get_option('aisp_protector_enable_posts'), 1); ?>>
                                <?php esc_html_e('Protect all posts from AI scraping', 'ai-scraping-protector'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Enable for Pages', 'ai-scraping-protector'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="aisp_protector_enable_pages" value="1" <?php checked(get_option('aisp_protector_enable_pages'), 1); ?>>
                                <?php esc_html_e('Protect all pages from AI scraping', 'ai-scraping-protector'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
} 