<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Register settings for the plugin
function aisp_protector_register_settings() {
    // Register the settings with validation callbacks
    register_setting(
        'aisp_protector_options',
        'aisp_protector_enable_posts',
        array(
            'type' => 'boolean',
            'sanitize_callback' => 'aisp_protector_sanitize_checkbox',
            'default' => false
        )
    );

    register_setting(
        'aisp_protector_options',
        'aisp_protector_enable_pages',
        array(
            'type' => 'boolean',
            'sanitize_callback' => 'aisp_protector_sanitize_checkbox',
            'default' => false
        )
    );
}
add_action('admin_init', 'aisp_protector_register_settings');

// Sanitization callback for checkboxes
function aisp_protector_sanitize_checkbox($input) {
    return (isset($input) && true === (bool) $input) ? true : false;
}

// Add settings form with nonce
function aisp_protector_settings_form() {
    ?>
    <form method="post" action="options.php">
        <?php
        settings_fields('aisp_protector_options');
        do_settings_sections('aisp_protector_options');
        wp_nonce_field('aisp_protector_update_settings', 'aisp_protector_settings_nonce');
        submit_button();
        ?>
    </form>
    <?php
}

/**
 * Enqueues styles for the admin settings page.
 */
function aisp_protector_enqueue_admin_styles($hook) {
    // Only load on our plugin's page
    if ('toplevel_page_ai-scraping-protector' !== $hook) {
        return;
    }
    
    wp_enqueue_style('aisp_protector_admin_styles', plugin_dir_url(__FILE__) . 'css/admin-styles.css', array(), '1.0');
    wp_enqueue_style('aisp_protector_admin_styles_enhanced', plugin_dir_url(__FILE__) . 'css/admin-styles-enhanced.css', array(), '1.0');
}
add_action('admin_enqueue_scripts', 'aisp_protector_enqueue_admin_styles');

/**
 * Displays the options page for the AI Scraping Protector plugin.
 */
function aisp_protector_options_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Process form submission
    if (isset($_POST['submit'])) {
        // Verify nonce
        check_admin_referer('aisp_protector_settings', 'aisp_protector_nonce');
        
        // Save settings
        update_option('aisp_protector_enable_posts', 
            isset($_POST['aisp_protector_enable_posts']) ? 1 : 0
        );
        update_option('aisp_protector_enable_pages', 
            isset($_POST['aisp_protector_enable_pages']) ? 1 : 0
        );

        // Add success message
        add_settings_error(
            'aisp_protector_messages',
            'settings_updated',
            esc_html__('Settings saved successfully!', 'ai-scraping-protector'),
            'updated'
        );
    }

    // Display settings errors/messages
    settings_errors('aisp_protector_messages');
    ?>
    <div class="wrap ai-scraping-protector">
        <h1><?php esc_html_e('AI Scraping Protector Settings', 'ai-scraping-protector'); ?></h1>

        <div class="settings-container">
            <form method="post" action="">
                <?php wp_nonce_field('aisp_protector_settings', 'aisp_protector_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">
                            <label for="aisp_protector_enable_posts">
                                <?php esc_html_e('Enable for Posts:', 'ai-scraping-protector'); ?>
                                <span class="tooltip">
                                    <span class="help-icon">?</span>
                                    <span class="tooltiptext">
                                        <?php esc_html_e('Enable AI scraping protection for all posts on your site.', 'ai-scraping-protector'); ?>
                                    </span>
                                </span>
                            </label>
                        </th>
                        <td>
                            <input type="checkbox" id="aisp_protector_enable_posts" name="aisp_protector_enable_posts" value="1" <?php checked(1, get_option('aisp_protector_enable_posts'), true); ?> />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">
                            <label for="aisp_protector_enable_pages">
                                <?php esc_html_e('Enable for Pages:', 'ai-scraping-protector'); ?>
                                <span class="tooltip">
                                    <span class="help-icon">?</span>
                                    <span class="tooltiptext">
                                        <?php esc_html_e('Enable AI scraping protection for all pages on your site.', 'ai-scraping-protector'); ?>
                                    </span>
                                </span>
                            </label>
                        </th>
                        <td>
                            <input type="checkbox" id="aisp_protector_enable_pages" name="aisp_protector_enable_pages" value="1" <?php checked(1, get_option('aisp_protector_enable_pages'), true); ?> />
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings', 'primary', 'submit', false); ?>
            </form>
            
            <div class="settings-sidebar">
                <div class="sidebar-box">
                    <h3><?php esc_html_e('About AI Scraping Protector', 'ai-scraping-protector'); ?></h3>
                    <p><?php esc_html_e('Protect your content from AI scraping with advanced detection and prevention methods.', 'ai-scraping-protector'); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php
}
