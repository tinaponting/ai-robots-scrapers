<?php
/**
 * @package AI Scraping Protector
 *
 *
 * @wordpress-plugin
 * Plugin Name:       AI Scraping Protector
 * Description:       Protects WordPress content from AI scraping.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Debashish Mondal
 * Author URI:        https://debashishmondal.com
 * FORK URI:          https://github.com/tinaponting/ai-robots-scrapers
 * Text Domain:       ai-scraping-protector
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AISP_VERSION', '1.0.0');
define('AISP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AISP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AISP_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('AISP_PLUGIN_FILE', __FILE__);

// Composer autoloader
if (file_exists(AISP_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once AISP_PLUGIN_DIR . 'vendor/autoload.php';
}

// Initialize the plugin
require_once AISP_PLUGIN_DIR . 'includes/class-asp-core.php';

/**
 * Begins execution of the plugin.
 *
 * @since 1.0.0
 */
function aisp_run_protector() {
    $plugin = new AISP_Core();
    $plugin->run();
}
aisp_run_protector();
