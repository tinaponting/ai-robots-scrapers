<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Hide content based on scraping protection settings
/**
 * Hides content for posts and pages based on scraping protection settings.
 *
 * @param string $content The original content.
 * @return string The modified content.
 */
function aisp_protector_hide_content($content) {
    global $post;

    // Check if scraping protection is enabled for this post
    $is_protection_enabled = get_post_meta($post->ID, '_aisp_protector_enable_scraping_protection', true);

    if (is_single() && ($is_protection_enabled || get_option('aisp_protector_enable_posts'))) {
        return 'Content hidden from AI scraping.'; // Message for hidden content
    }
    if (is_page() && get_option('aisp_protector_enable_pages')) {
        return 'Content hidden from AI scraping.'; // Message for hidden content
    }
    return $content; // Return original content if no conditions are met
}
add_filter('the_content', 'aisp_protector_hide_content');

// Add HTTP headers to prevent indexing
/**
 * Adds HTTP headers to prevent search engines from indexing the page.
 */
function aisp_protector_add_http_headers() {
    // Check if the user is logged in or if the request is from a bot
    if (!is_user_logged_in() && !aisp_protector_bot_detection()) {
        header('X-Robots-Tag: noindex, nofollow', true); // Prevent indexing and following links
    }
}
add_action('send_headers', 'aisp_protector_add_http_headers');

// Bot detection logic
/**
 * Detects if the current user agent is a known bot.
 *
 * @return bool True if a bot is detected, false otherwise.
 */
function aisp_protector_bot_detection() {
    // Sanitize and validate user agent
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
    $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    
    // Validate IP address format
    if (!filter_var($remote_addr, FILTER_VALIDATE_IP)) {
        return false; // Invalid IP address
    }

    $bots = ['Googlebot', 'Bingbot', 'Slurp', 'DuckDuckBot'];

    foreach ($bots as $bot) {
        if (stripos($user_agent, $bot) !== false) {
            return true;
        }
    }

    if (empty($http_referer)) {
        return true;
    }

    $bot_ips = ['66.249.64.0/19', '207.46.13.0/24'];
    foreach ($bot_ips as $ip_range) {
        if (aisp_ip_in_range($remote_addr, $ip_range)) {
            return true;
        }
    }

    return false;
}

/**
 * Checks if an IP address is within a given CIDR range.
 *
 * @param string $ip The IP address to check.
 * @param string $cidr The CIDR range to check against.
 * @return bool True if the IP is in the range, false otherwise.
 */
function aisp_ip_in_range($ip, $cidr) {
    list($subnet, $bits) = explode('/', $cidr);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = -1 << (32 - $bits);
    $subnet &= $mask; // Apply the subnet mask
    return ($ip & $mask) === $subnet; // Check if the IP is in the range
}

// Scramble content for detected bots
/**
 * Scrambles the content if a bot is detected.
 *
 * @param string $content The original content.
 * @return string The modified content.
 */
function aisp_protector_scramble_content($content) {
    if (aisp_protector_bot_detection()) {
        return str_shuffle($content); // Example scrambling
    }
    return $content; // Return original content if no bot is detected
}
add_filter('the_content', 'aisp_protector_scramble_content');

// Add a meta box to the post editor
/**
 * Adds a meta box to the post editor for enabling scraping protection.
 */
function aisp_protector_add_meta_box() {
    add_meta_box(
        'aisp_protector_meta_box', // ID
        'AI Scraping Protection', // Title
        'aisp_protector_meta_box_callback', // Callback function
        'post', // Post type
        'side', // Context
        'default' // Priority
    );
}
add_action('add_meta_boxes', 'aisp_protector_add_meta_box');

// Callback function for the meta box
/**
 * Displays the content of the meta box.
 *
 * @param WP_Post $post The current post object.
 */
function aisp_protector_meta_box_callback($post) {
    // Add nonce field for security
    wp_nonce_field('aisp_protector_save_meta_box_data', 'aisp_protector_meta_box_nonce');

    // Retrieve current value
    $value = get_post_meta($post->ID, '_aisp_protector_enable_scraping_protection', true);
    ?>
    <div class="checkbox">
        <label for="aisp_protector_enable_scraping_protection">
            <input type="checkbox" id="aisp_protector_enable_scraping_protection" name="aisp_protector_enable_scraping_protection" value="1" <?php checked($value, '1'); ?> />
            <?php esc_html_e('Enable AI Scraping Protection', 'ai-scraping-protector'); ?>
        </label>
    </div>
    <?php
}

// Save the meta box data
/**
 * Saves the meta box data when the post is saved.
 *
 * @param int $post_id The ID of the post being saved.
 */
function aisp_protector_save_meta_box_data($post_id) {
    // Verify nonce and sanitize input
    if (!isset($_POST['aisp_protector_meta_box_nonce'])) {
        return;
    }

    $nonce = sanitize_text_field(wp_unslash($_POST['aisp_protector_meta_box_nonce']));

    if (!wp_verify_nonce($nonce, 'aisp_protector_save_meta_box_data')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (array_key_exists('aisp_protector_enable_scraping_protection', $_POST)) {
        update_post_meta($post_id, '_aisp_protector_enable_scraping_protection', '1');
    } else {
        delete_post_meta($post_id, '_aisp_protector_enable_scraping_protection');
    }
}
add_action('save_post', 'aisp_protector_save_meta_box_data');

// Retrieve options with error handling
/**
 * Retrieves the option value with error handling.
 *
 * @param string $option_name The name of the option to retrieve.
 * @return mixed The option value or false on failure.
 */
function aisp_protector_get_option($option_name) {
    return get_option($option_name);
}

// Add security headers
function aisp_protector_security_headers() {
    header(' X-Robots-Tag "noai, noimageai, nosummary');
    header('tdm-reservation "1"');
    header('noAIPreferenceVocabularyTerm');
    header('DisallowAITraining”');
    header('gptbot" content="noml');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';");
}
add_action('send_headers', 'aisp_protector_security_headers');

// Add rate limiting
function aisp_protector_rate_limit() {
    // Don't apply rate limiting for logged-in users
    if (is_user_logged_in()) {
        return;
    }

    // Sanitize and validate IP
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return;
    }
    
    $transient_name = 'aisp_rate_limit_' . md5($ip);
    $time_limit = 3600; // 1 hour
    $rate_limit = get_transient($transient_name);
    
    // Increase the limit to 1000 requests per hour
    $max_requests = 1000;

    if (false === $rate_limit) {
        set_transient($transient_name, 1, $time_limit);
    } else if ($rate_limit > $max_requests) {
        // Add debugging information for admins
        if (current_user_can('manage_options')) {
            /* translators: 1: Current request count, 2: Maximum allowed requests, 3: Time window in seconds */
            $message = sprintf(
                esc_html__('Rate limit exceeded. Current count: %1$d, Max allowed: %2$d, Time window: %3$d seconds', 'ai-scraping-protector'),
                absint($rate_limit),
                absint($max_requests),
                absint($time_limit)
            );
            wp_die(wp_kses_post($message));
        } else {
            /* translators: %s: Error message */
            wp_die(esc_html__('Rate limit exceeded. Please try again later.', 'ai-scraping-protector'));
        }
    } else {
        set_transient($transient_name, $rate_limit + 1, $time_limit);
    }
}

// Move rate limiting to run later in the request cycle
remove_action('init', 'aisp_protector_rate_limit');
add_action('template_redirect', 'aisp_protector_rate_limit', 1);

/**
 * Reset rate limit for testing purposes.
 * Only accessible to administrators.
 */
function aisp_protector_reset_rate_limit() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return;
    }
    
    $transient_name = 'aisp_rate_limit_' . md5($ip);
    delete_transient($transient_name);
    
    // Add admin notice for confirmation
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('Rate limit has been reset successfully.', 'ai-scraping-protector'); ?></p>
        </div>
        <?php
    });
}
add_action('admin_init', 'aisp_protector_reset_rate_limit');

/**
 * Handle rate limit errors.
 *
 * @param string $message Error message to display
 * @param bool $is_admin Whether the user is an admin
 */
function aisp_protector_handle_rate_limit_error($message, $is_admin = false) {
    if ($is_admin) {
        /* translators: %s: Error message */
        $admin_message = sprintf(
            esc_html__('AI Scraping Protector: %s', 'ai-scraping-protector'),
            esc_html($message)
        );
        wp_die(wp_kses_post($admin_message), '', array('response' => 429));
    } else {
        /* translators: %s: Error message */
        wp_die(
            esc_html__('Rate limit exceeded. Please try again later.', 'ai-scraping-protector'),
            '',
            array('response' => 429)
        );
    }
}
