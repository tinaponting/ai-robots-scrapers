;(function($){

	$(document).ready(function()
	{
		var $color_pickers = $('.color-picker');

		$color_pickers.wpColorPicker();

	});
	
})(jQuery);