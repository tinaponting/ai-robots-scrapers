# Optional: To be more explicit about optional version numbers, you can use:

if ($http_user_agent ~*
"(OAI-SearchBot(?:\/[\d\.]+)?|ChatGPT-User(?:\/[\d\.]+)?|GPTBot(?:\/[\d\.]+)?)") {
return 403;
}


ALT:
Or much more preferably, I can include them all in one block:

# case sensitive
if ($http_user_agent ~ (BadBotOne|BadBotTwo)) {
	return 403
}

# case insensitive
if ($http_user_agent ~* (BadBotOne|BadBotTwo)) {
	return 403
}