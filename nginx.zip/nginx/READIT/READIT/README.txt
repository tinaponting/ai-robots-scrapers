Blocking things with nginx configuration
I use a couple of techniques to block things with nginx configuration. All my configuration files live under the /etc/nginx path, so keep that in mind as we continue.

Each virtual host has its own configuration file in /etc/nginx/sites-available/ that gets enabled via a link from /etc/nginx/sites-enabled/. Configuration that I want to use for multiple sites is stored under /etc/nginx/global/.

Inside the virtual host server {} block, I include these global rules, like this:

server {
listen 443 ssl;
listen [::]:443 ssl;
server_name example.com;

# SSL setup configuration, etc.

# Enable botblocking and other security controls
include global/restrictions.conf;

# Not a WordPress site, so let's mess with some miscreants
include global/slooooow.conf;
}
Let’s look at some of what’s included in the global/restrictions.conf settings first, and then look at the weirder things I’m doing in slooooow.conf.

Global botblocks and restrictions
I use some location directives to deny access to specific URL paths on most webservers.

location = /nginx.conf {
deny all;
}

# Deny bots trying to access PHP in the .well-known path
location ~* /\.well-known/acme-challenge/.*\.php {
deny all;
}

# Deny access to any files with a .php extension in the uploads directory
# Works in sub-directory installs and also in multisite network
# Keep logging the requests to parse later (or to pass to firewall utilities such as fail2ban)
location ~* /(?:uploads|files)/.*\.php$ {
deny all;
}
The first directive denies access to bots trying to access the webserver configuration file. I know that no legitimate client should be trying to GET the webserver config file on my servers, so I just deny all access.

The second directive denies access to bots that try to access PHP files in the path used by LetsEncrypt/ACME servers as part of the TLS certificate renewal process. There shouldn’t be any PHP files accessible via this path anyway, but a misconfigured server might accidentally link to some or otherwise mistakenly provide access to them. Again, no legitimate client should be looking for PHP files here, so I just deny access to anything that does. This directive uses regular expressions, but it’s not very complex so hopefully you can see how it works without too much difficulty.

The third directive also denies access to PHP files, this time for the paths /uploads/ and /files/, neither of which should have PHP scripts in them, and if they do, they shouldn’t be accessible.

Blocking bots
Now let’s look at some bot blocking.

I do this in global/restrictions.conf as well, because I like to block bots and scrapers everywhere. The directives look like this:

# Deny access to bots
# Block user agents that tend to be scrapers and badly behaved bots
if ($bad_bot = 1) {
return 444 "? beep boop ?";
}

# Block bad referrers as well
if ($bad_referer = 1) {
return 444 "? beep boop ?";
}

# No scrapers
if ($scraper = 1) {
return 418 "?";
}

# Block bad apps
if ($bad_apps = 1) {
return 444 "? beep boop ?";
}
Each of these pieces of config uses a mapping that I’ve configured at the http {} level, which we’ll look at in a moment.

Each directive looks at the request to see if the mapping variable is equal to 1, and if it is, returns an HTTP error code and (optionally) an error message to the client. You may have noticed that these error codes aren’t officially part of the HTTP spec and you would be right.

I use non-official error codes because it amuses me, but it also tends to break sloppily written bot code that expects errors codes to be real ones from the spec. A lot of bot and scraper developers use generic language libraries to handle HTTP communications, and they don’t always handle unusual errors very well in their code. By being a bit weird, I hope to ruin their day, just a little bit. I’m using Unicode characters in the error string for similar reasons. Mostly, it amuses me, but it also helps break sloppy code.

As an aside, the strange errors sometimes help me diagnose genuine bugs or my own mistakes. If I get the 418 I AM A TEAPOT response from one of my systems, I have a pretty good idea of what’s going wrong.

Configuring nginx maps
To make these bot and scraper blocks work, I need to set up the maps. This has to happen outside of the virtual host server {} definitions, in the http {} block. This config is global for the webserver, so I don’t take action here, I just set a variable that the per-website restrictions can act on.

Inside the http {} block, I include a separate set of configuration files, before the part that includes all the virtual host configs:

##
# Bot blocking
##
include global/blockmaps.conf;
The blockmaps config has the map definitions, which look a bit like this:

map $http_user_agent $bad_bot {
default 0;
~*(?i)(bingbot/2.0) 0; # allow Microsoft bingbot
~*(?i)(JikeSpider) 1;
~*(?i)(proximic) 1;
~*(?i)(Sosospider) 1;
~*(?i)(Baiduspider) 1;
~*(?i)(Twitterbot) 1;
~*(?i)(SemrushBot) 1;
~*(?i)(^AIBOT) 1;
~*(?i)(^BunnySlippers) 1;
~*(?i)(^Cegbfeieh) 1;
~*(?i)(^CheeseBot) 1;
}
This map checks the $http_user_agent variable that nginx sets with whatever the client reports as its User-Agent string against each line in the map definition, and puts the result we provide for a match into the $bad_bot variable that we use later on in each virtual host server {} block.

We start by setting the default to 0 (False, not a bad bot) to allow things by default. We could deny things by default, but then we’d have to set up a list of known-good User-Agent strings for the browsers people use. For my purposes, it’s easier to pick off some known-bad clients.

The second line does a case-insensitive regex match of the User-Agent string against “bingbot/2.0” which is what Microsoft’s Bing search engine uses to identify itself. Since I want to allow that bot, I set the variable to 0.

Then we add a line for each bot User-Agent we want to block. 
We need to be a little bit careful, because if something we want to allow matches the string 
we put here it’ll get blocked. We want the expression to be as short and simple as possible so it works and it’s not too hard to debug if it doesn’t work as expected.

For some of these, you can see I start the match at the very beginning of the User-Agent string,
 such as with ^CheeseBot. The others will match the string anywhere in the User-Agent.

Blocking Scrapers
I also block bots I term scrapers, like the zillions of AI content scrapers that trawl the web these days. 
I don’t mind actual people reading my stuff. I’m less keen on VC-funded startups costing me money so they can build spicy autocomplete machines 
that lie to credulous CEOs about being sentient.

The scraper map looks very similar to the badbot map:

map $http_user_agent $scraper {
default 0;
~*(?i)(Google-Extended) 1;
~*(?i)(Applebot-Extended) 1;
~*(?i)(anthropic-ai) 1;
~*(?i)(ClaudeBot) 1;
~*(?i)(Claude-Web) 1;
~*(?i)(Omgili) 1;
~*(?i)(FacebookBot) 1;
~*(?i)(aoihttp|curl|Faraday|Go-http-client|hackney|http.rb|python-httpx|python-requests|Python-urllib) 1;
~*(?i)(node-fetch) 1;
~*(?i)(Timpibot) 1;
# If you don't provide a User-Agent, you can go away
~*(^-$) 1;
}

The default is to allow access, and the User-Agent matching the same way as the bad_bot map. You may have noticed a couple of new things going on here, though.

The line with curl, Go-http-client, and python-requests in it is there to block scripts written by lazy developers that are using a common 
HTTP library from their language’s standard library for their scraper. If they haven’t even bothered to figure out how to set a custom User-Agent for their program, 
it doesn’t get to access my stuff. Similarly, if a program doesn’t supply a User-Agent at all, it gets denied access.

These restrictions are fairly trivial to bypass, but I haven’t shared everything that I’m doing to try to minimise the load on my systems from entitled 
weirdos writing lazy scrapers. But you’d be surprised how effective even quite simple methods can be.

Slooooow
One last bit of fun. I got this idea from someone on Mastodon years ago.

Remember slooooow.conf ? It’s a really simple location match that looks like this:

location /wp-login.php {
return 301 "https://speed.hetzner.de/10GB.bin";
}
If a bot is trying to access the WordPress login URL on a website that isn’t running WordPress, 
I know that it’s up to no good. We could just block it, or we could redirect it to download 10GB of speed test file from Hetzner.

Better written bots will detect something weird is going on and bail out early, but most bots aren’t that well written. 
They’ll merrily accept the redirect and waste a bunch of time downloading 10GB of garbage instead of wasting my webserver resources. Hetzner is big enough to have a CDN that can easily deal with serving up the file.

An enterprising reader might investigate how this mechanism could be used to deploy a zip bomb or similarly more active countermeasures. 
Not that I would encourage anyone to do such a thing, but who said canary tokens can only be passive alarms?

FROM: https://www.eigenmagic.com/2025/01/14/banning-bots-with-nginx-maps/