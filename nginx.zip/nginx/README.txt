Optional: To be more explicit about optional version numbers, you can use:

if ($http_user_agent ~*
"(OAI-SearchBot(?:\/[\d\.]+)?|ChatGPT-User(?:\/[\d\.]+)?|GPTBot(?:\/[\d\.]+)?)") {
return 403;
}