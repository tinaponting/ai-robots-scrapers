<?php
/*
* Plugin Name:      AI Scrape Protect
* Plugin URI:       https://wordpress.org/plugins/ai-scrape-protect/
* Fork Plugin URI:  https://github.com/tinaponting/ai-robots-scrapers/
* Description:      Protects your website from AI scraping by adding opt-out instructions to robots.txt for common AI bots and adding meta tags to HTML head.
* Version:          9.1
* Author:           Uisce Web Development, Daan Verbaan
* Author URI:       https://uisce.eu
* License:          GPL v2 or later
* License URI:      https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain:      ai-scrape-protect
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Hook into the admin_enqueue_scripts action to add the CSS to the admin area
function ai_scrape_protect_enqueue_admin_styles() {
    // Get the plugin directory
    $plugin_url = plugin_dir_url( __FILE__ );

    // Enqueue your custom admin CSS
    wp_enqueue_style( 'ai-scrape-protect-admin-style', $plugin_url . 'css/admin-style.css' );
}
add_action( 'admin_enqueue_scripts', 'ai_scrape_protect_enqueue_admin_styles' );


class AISP_Manage_Robots_Txt {
    // Manages robots.txt to allow legitimate bots while blocking AI scrapers
    // - allowed_bots: Search engines and browsers that should access the site
    // - blocked_bots: AI scrapers and malicious crawlers that should be blocked

    private $blocked_bots = [
        ".ai",
        "-ai",
        "_ai",
        "ai.",
        "ai-",
        "ai_",
        "ai=",
        ".*?-ai$", 
        "ai=n",
		"AcademicBotRTU",
		"AddSearchBot",
		"Agent 3",
		"Amazon Athena",
		"Amazon Bedrock AgentCore Browser",
		"Amazon Bedrock",
		"Amazon Comprehend",
		"Amazon Lex",
		"Amazon SageMaker",
		"Amazon Silk",
		"Amazon Textract",
		"Amazonbot",
		"amazonBot",
		"AmazonBuyForMe",
		"anonymous AI chatbot",
		"Anonymous AI",
		"anthropic bot",
        "DarkBARD",
        "DarkBard",
        "DarkBERT",
        "DarkGPT",
        "DataForAI",
        "DataForSeoBot",
        "DataFor",
        "DataProvider",
        "dataprovider",
        "Datenbank Crawler",
		"Meta Agent",
		"Meta AI Crawler",
		"Meta AI",
		"Meta Llama",
		"MetaAI",
		"MetaGPT",
		"MetaTagBot",
		"MetaTagBot",
		"Meta-AI",
		"Meta-ExternalAgent",
		"meta-externalagent",
		"Meta-ExternalFetcher",
		"meta-externalfetcher/1.1",
		"Meta-External",
		"Meta-Webindexer 1.1",
		"Meta-Webindexer",
		"meta-webindexer/1.1",
		"Meta.AI",
		"Middleware",
		"Puppeteer",
		"python Ai",
		"Python lxml",
		"PyTorch Lightning LLM",
		"PyTorch Lightning",
		"PyTorch",
        "404checker",
        "AhrefsBot",
        "ahrefsbot",
        "AhrefsBot/7.0",
        "AhrefsSiteAudit",
        "*bot.*.ahrefs.com",
        "*bot.*.ahrefs.com",
        "*bot.*.ahrefs.net",
        "*bot.*.ahrefs.net",
        "ai.azure**.com",
        "ai.gemma**.dev",
        "ai.meta**.com",
        "alibabacloud.com",
        "allenai\.org",
        "Anthropic**.com",
        "anthropic\.com ",
        "Amazon",
        "Baiduspider",	
        "baiduspider-*-*-*-*",
        ".crawl.baidu.com",
        "BLEXBot",
        "bot.*.cn",
        "BitSightBot/1.0",
        "Bytespider",	
        "bytespider-*-*-*-*",
        ".crawl.bytedance.com",	
        "*bot.*.cn",
        "*crawl.*.ru",
        "*.chat.openai.com",
        "CensysInspect/1.1;",
        "copilot.microsoft**.com",
        "cohere\.ai",
        "DataForSeoBot",
        "DomainStatsBot",
        "DotBot",
        "dotbot",
        "Extreme Picture Finder",
        ".favicon.ico$",
        "facebookexternalhit/1.1", 
        "fwdproxy-*-*.fbsv.net",
        "gemini.google**.com",
        "GuzzleHttp",
        "HeadlessChrome",
        "Headless",
        "huggingface**.co",
        "Java-http-client",
        "libwww",
        "libwww-perl",
        "llama**.com",
        "Lmsis**.org",
        "majestic",
        "meta-externalagent/1.1",
        "mistral**.ai",
        "mistral\.ai", 
        "MJ12bot",
        "MJ12**.com",
        "Nikto",
        "Ninja",
        "Nmap",
        "Nuclei",
        "Nutch",
        "OpenAI**.com",
        "openai\.com/bot", 
        "OpenVAS",
        "omgili\.com",
        "perplexity.ai",
        "perplexity\.ai", 
	    "PerplexityBot/1.0",	
        "perplexity-*-*-*-*",
        "perplexity.ai",
        "PetalBot",	
        "petalbot-*-*-*-*",
        ".aspiegel.com",
        "Prometheus",
        "python aiohttp",
        "Python",
        "python-httpx",
        "python-http",
        "python-requests",
        "Python-urllib",
        "SemrushBot",
        "bot.*semrush.com",
        "SemrushBot-BA",
        "SemrushBot-BM",
        "SemrushBot-CT",
        "SemrushBot-FT",
        "SemrushBot-SA",
        "SemrushBot-SISF",
        "SemrushBot-SI",
        "SemrushBot-SWA",
        "SemrushBot/7~bl",
        "serpstatbot",
        "Sogou web spider",	
        "sogou spider ",
        "sogouspider-*-*-*-*",
        "crawl.sogou.com",
        "spider\.cloud", 
        "test-bot$",  
        "my-tiny-bot", 
        "thesis-research-bot$",
		"Yisouspider",	
        "shenmaspider-*-*-*-*",
        ".crawl.sm.cn",
        "Wget",
        "wget",
        "woorank",
        "WPScan",
        "Xenu",
        "YaK",	
        "Zeus",
        "Zgrab",
        "ZoominfoBot",	
        "ZmEu"
    ];

    // Bots to ALLOW (legitimate search engines and browsers)
    private $allowed_bots = [
        "AdsBot-Google",
        "APIs-Google",
        "Applebot",
        "AppleNewsBot",
        "apple-app-site-association",
        "archive.org_bot",
        "Android OS",
        "Bingbot",
        "bingbot",
        "BingPreview",
        "bing",
        "bingbot/2.0",
        "Brave",
        "BraveBot",
        "Chrome",
        "CocCoc",
        "CocCocBot",
        "coccocbot-image",
        "coccocbot-web",
        "coccocbot-web/1.0",
        "CriOS",
        "Dolphin Browse",
        "DuckDuckBot",
        "DuckDuckGo-Favicons-Bot",
        "DuplexWeb-Google",
        "Dolphin Browser",
        "Dogpile",
        "Ecosia",
        "EcosiaBot",
        "Edg",
        "Edge",
        "Exabot",
        "Feedfetcher-Google",
        "Firefox",
        "FxiOS",
        "Gigablast",
        "Gigabot",
        "Google Favicon",
        "Google Mobile Adsense",
        "google page speed",
        "Google Read Aloud",
        "Google Site Verifier",
        "Googlebot",
        "Googlebot Smartphone",
        "Googlebot-Image",
        "Lighthouse",
        "Googlebot-Mobile",
        "googlebot-news",
        "Googlebot-Video",
        "Googlebot/2.1",
        "GoogleProducer",
        "Google-InspectionTool",
        "Google-Mobile-Apps",
        "Google-Safetys",
        "Info.com",
        "ia_archiver",
        "IceCat",
        "Instagram",
        "Konqueror",
        "LinkedInApp",
        "LinkedInBot",
        "linkedinbot",
        "LookseekBot",
        "Lycos",
        "Mastodon",
        "Maxthon",
        "Mediapartners-Google",
        "Mediapartners-Google/2.1",
        "Midori",
        "Mi Browser",
        "MojeekBot",
        "Mozilla",
        "MS Search",
        "Msie",
        "msnbot",
        "msnbot-media",
        "MSNBot-NewsBlogs",
        "MetaGer",
        "MojeekBot",
        "Opera",
        "OPR",
        "PeekBot",
        "Pinterest",
        "QwantBot",
        "Qwantify",
        "Safari",
        "SamsungBrowser",
        "Seamonkey",
        "SeznamBot",
        "SeznamBot/4.0",
        "Slurp",
        "StartpageBot",
        "SwiftBot",
        "StartPage",
        "Search Encrypt",
        "Swisscows",
        "TumblrBot",
        "Vivaldi",
        "YaBrowser",
        "YacyBot",
        "YaDirectFetcher",
        "YaDirectFetchery",
        "Yahoo! Slurp",
        "yahoo-blogs",
        "yahoo-blogs/v3.9",
        "Yandex",
        "Yandex favicon",
        "YandexAccessibilityBot",
        "YandexBlogs",
        "YandexBot",
        "YandexFavicons",
        "YandexImages",
        "YandexMedia",
        "YandexMobileBot",
        "YandexNews",
        "YandexPagechecker",
        "YandexScreenshotBot",
        "YandexVideo",
        "YandexBot/3.0y",
        "YandexBlogs/0.99y",
        "YandexAccessibilityBot/3.0y",
        "YaDirectFetchery",
        "YandexSitelinks; Dyately",
        "YandexPagechecker/1.0y",
        "YaDirectFetcher/1.0y",
        "Yandex favicon",
        "YandexMobileBot",
        "YandexMobileBot/3.0y",
        "Yandex Robot",
        "YaDirectFetcher",
        "YandexImages/3.0y",
        "YandexImageResizer/2.0y",
        "YandexImages/3.0y",
        "YandexMedia/3.0y",
        "YandexMetrika/2.0y",
        "YandexNews/4.0y",
        "YandexScreenshotBot/3.0y",
        "YandexVideoParser/1.0y",
        "YandexWebmaster/2.0y",
        "Yeti",
        "Yeti/1.1",
        "Yeti-Mobile",
        "Qwant",
        "Qwantify",
        "WebwikiBot",
        "WebCrawler"
    ];
    public function __construct() {
        add_filter('robots_txt', [$this, 'modify_robots_txt'], 999, 2); 
    }
    public function modify_robots_txt($output, $public) {
        $output .= "\n# START AI Scrape Protect block\n# ---------------------------\n";
        
        // Add allowed bots first
        $output .= "# ALLOWED BOTS (Legitimate search engines and browsers)\n";
        foreach ($this->allowed_bots as $user_agent) {
            $output .= "User-agent: $user_agent\n";
            $output .= "Allow: /\n";
        }
        
        $output .= "\n# BLOCKED BOTS (AI scrapers and malicious crawlers)\n";
        // Add blocked bots
        foreach ($this->blocked_bots as $user_agent) {
            $output .= "User-agent: $user_agent\n";
        }
        $output .= "Disallow: /\n";
        
        $output .= "# ---------------------------\n# END AI Scrape Protect block\n";
        return $output;
    }
}

class AISP_Add_Meta_Tags {

    public function __construct() {
        add_action('wp_head', [$this, 'add_ai_meta_tags'], 1);
    }
    public function add_ai_meta_tags() {
        echo "\n<!-- AI Scrape Protect Meta Tags -->\n\n";
        echo "<!-- Prevents OpenAI's OAI-SearchBot/1.0 from accessing the content. -->\n";
        echo '<meta name="OAI-SearchBot/1.0" content="disallow">' . "\n";
        echo "<!-- Instructs general AI bots to avoid indexing, summarizing, or using the content. -->\n";
        echo '<meta name="robots" content="noai">' . "\n";
        echo "<!-- Prevents Bing's bot from using the content for AI purposes. -->\n";
        echo '<meta name="bingbot" content="nocache">' . "\n";
        echo "<!-- Future-proof tag for prohibiting AI training. -->\n";
        echo '<meta name="robots" content="DisallowAITraining, model-training">' . "\n";
        echo "<!-- Prevents AI use of images. -->\n";
        echo '<meta name="robots" content="noai, noimageai">' . "\n";
        echo "<!-- End AI Scrape Protect Meta Tags -->\n";
    }
}

// Add icons to the WordPress Admin Bar
class AISP_Admin_Bar_Icons {

    public function __construct() {
        // Hook into WordPress admin bar to display icons
        add_action('admin_bar_menu', [$this, 'add_admin_bar_icons'], 100);
    }

    public function add_admin_bar_icons($admin_bar) {
        // Ensure the function is loaded and available
        if ( !function_exists('is_plugin_active') ) {
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }

        // Check if the plugin is active
        $is_plugin_active = is_plugin_active('ai-scrape-protect/ai-scrape-protect.php');

        // Define the icon URLs based on the plugin state
        $icon_url = $is_plugin_active ? plugin_dir_url(__FILE__) . 'images/ai-scrape-protect-active.png' : '';

        // Debug: Output for testing
        // error_log('Plugin active: ' . ($is_plugin_active ? 'Yes' : 'No'));

        // Add an item to the admin bar with the corresponding icon
        $admin_bar->add_node([
            'id'    => 'ai-scrape-protect-icon',
            'title' => '<img src="' . esc_url($icon_url) . '" alt="' . __('AI Scrape Protect Icon', 'ai-scrape-protect') .'" title="' . __('AI Scrape Protection enabled, click for plugin info', 'ai-scrape-protect') .'" style="height: 20px; width: 20px;"/>',
            'href'  => 'https://uisce.eu/wordpress-ai-scrape-protect-plugin/', 
            'meta'  => [
                'target' => '_blank' 
            ]
        ]);
    }
}




// Initialize all classes
new AISP_Manage_Robots_Txt();
new AISP_Add_Meta_Tags();
new AISP_Admin_Bar_Icons();
