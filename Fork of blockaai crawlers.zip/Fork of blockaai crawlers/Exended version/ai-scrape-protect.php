<?php
/*
* Plugin Name:      AI Scrape Protect
* Plugin URI:       https://codesurf.eu/wordpress-ai-scrape-protect-plugin/
* Description:      Protects your website from AI scraping by adding opt-out instructions to robots.txt for common AI bots and adding meta tags to HTML head.
* Version:          9.5
* Author:           Codesurf Web Development,  Daan Verbaan
* Author URI:       https://codesurf.eu
* License:          GPL v2 or later
* License URI:      https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain:      ai-scrape-protect
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Hook into the admin_enqueue_scripts action to add the CSS to the admin area
function ai_scrape_protect_enqueue_admin_styles() {
    // Get the plugin directory
    $plugin_url = plugin_dir_url( __FILE__ );

    // Enqueue your custom admin CSS
    wp_enqueue_style( 'ai-scrape-protect-admin-style', $plugin_url . 'css/admin-style.css' );
}
add_action( 'admin_enqueue_scripts', 'ai_scrape_protect_enqueue_admin_styles' );


class AISP_Manage_Robots_Txt {

    private $user_agents = [
        ".ai",
        "-ai",
        "_ai",
        "ai.",
        "ai-",
        "ai_",
        "ai=",
		"Agentic RAG",
        "Agentic RAG with LangGraph",
        "AgentQL",
        "AI Agent",
        "AI agents /",
        "AI Article Writer",
        "AI Chat",
        "AI Chatbot",
        "AI Content Detector",
        "AI copilot",
        "AI Detection",
        "AI Dungeon",
        "AI Journalist",
        "AI Journalist Agent",
        "AI Search",
        "AI Search Engine",
        "AI Search Intent",
        "AI SEO Crawler",
        "AI Training",
        "AI Web",
        "AI Writer",
        "AI2",
        "AI2 Bot",
        "AI2Bot",
        "AI21 Labs",
        "AIBot",
        "aiHitBot",
        "AIMatrix",
        "AISearchBot",
        "AITraining",
        "AITraining /",
        "AI-Crawler",
        "ai-crawlers-training",
        "AI Web Scraper",
        "ai-proxy",
        "Alexa",
        "AlexaTM",
        "Alice Yandex",
        "AliGenie",
        "Alpha AI",
        "AlphaAI",
        "Amazon",
        "Amazon Athena",
        "Amazon Bedrock",
        "Amazon Comprehend",
        "Amazon Lex",
        "Amazon SageMaker",
        "Amazon Silk",
        "Amazon Textract",
        "amazonBot",
        "amazon-kendra",
        "AWS bedrock",
        "AWS Trainium",
        "Bedrock Claude",
        "bedrock-chat",
        "bedrock-chatbot",
        "bedrock-claude-chatbot",
        "Amelia",
        "AndersPinkBot",
        "AndiBot",
        "Anonymous AI",
        "anonymous AI chatbot",
        "Anthropic",
        "anthropic-ai",
        "AnyPicker",
        "AnythingLLM",
        "Anyword",
        "Apple",
        "Applebot-Extended",
        "Apple-GenAI",
        "Aria AI",
        "Aria Browse",
        "Aria browse Aria AI",
        "Aria browser AI",
        "Articoolo",
        "Ask AI",
        "AutoGLM",
        "AutoGPT",
        "Automated Writer",
        "AutoML",
        "Autonomous RAG",
        "AwarioRssBot",
        "AwarioSmartBot",
        "Azure",
        "Azure AI Search",
        "BabyAGI",
        "Basic RAG",
        "Basic RAG Chain",
        "BardBot",
        "Brave Leo",
        "Brave Leo AI",
        "BraveGPT",
        "Brightbot",
        "Brightbot 1.0",
        "ByteDance",
	    "bytedance",
        "ByteDance crawler",
        "Bytespider",
        "Browser MCP Agent",
        "Bedrock",		
        "CarynAI",
        "CatBoost",
        "CCBot",
        "ccbot",
        "CCBot/2.0",
        "CC-Crawler",
        "CC-Crawler/2.0",
        "Chai",
        "Charstar AI",
        "Chatbot",
        "chatbot",
        "ChatGLM",
        "ChatGPT",
        "ChatGPT 4o",
        "ChatGPT 4o-mini",
        "ChatGPT 4.1",
        "ChatGPT 4.5",
        "ChatGPT o1",
        "ChatGPT o3-mini",
        "ChatGPT Operator",
        "ChatGPT search",
        "ChatGPT-User",
        "ChatGPT-User/1.0",
        "ChatGPT-User/2.0",
        "ChatLLM",
        "ChatOpenAI",
        "ChatUser",
        "chatUser /",
        "Chinchilla",
        "Claude",
        "Claude 3.5",
        "Claude 3.5 Haiku",
        "Claude 3.5 Sonnet",
        "Claude 3.7 Sonnet",
        "Claude 4",
        "Claude Opus",
        "Claude Opus 4",
        "Claude Sonnet 4",
        "ClaudeBot",
        "ClaudeBot/1.0",
        "Claude-RAG",
        "Claude-SearchBot",
        "Claude-User",
        "Claude-Web",
        "claude-web/1.0",
        "ClearScope",
        "Cognitive AI",
        "Cognitive AI engine",
        "Cohere",
        "cohere-ai",
        "cohere-ai/1.0",
        "cohere-training-data-crawler",
        "Common Crawl",
        "CommonCrawl",
        "Content Harmony",
        "Content King",
        "Content Optimizer",
        "Content Samurai",
        "Content Scraper GPT",
        "ContentAtScale",
        "ContentBot",
        "Contentedge",
        "ContentShake",
        "Conversion AI",
        "Copilot",
        "CopilotBot",
        "CopyAI",
        "Copymatic",
        "Copyscape",
        "CoreWeave",
        "Corrective RAG",
        "Cohere RAG",
        "Cotoyogi",
        "CRAB",
        "CrawlGPT",
        "CrawlQ AI",
        "Crawlspace",
        "Crew AI",
        "CrewAI",
        "Crushon AI",		
		"DALL-E",
		"DALL-E 2",
		"DALL·E 3",
		"Dall-E 4",
		"DALL-E Mini",
		"DarkBard",
		"DataForAI",
		"DataForSeoBot",
		"DataProvider",
		"dataprovider",
		"Datenbank Crawler",
		"DeepAI",
		"DeepL",
		"DeepMind",
		"DeepSeek",
		"DeepSeek-R1",
		"DeepSeek V3",	
		"DeepSeek R1 Y",
		"DepolarizingGPT",
		"DialoGPT",
		"Diffbot",
		"Doubao AI",
		"DuckAssistBot",
		"Extended GPT Scraper",	
		"Duck.ai",	
		"DuckDuckGo Chat",		 
		"DuckDuckGo-Enhanced",	
		"Duck.ai",
		"Echobox",
		"Elixir",
		"Extended GPT Scraper",
		"FacebookBot",
		"FacebookBot/1.0",
		"FacebookExternalHit",
		"facebookexternalhit/1.1",
		"FastGPT",
		"Factset_spyderbot",
		"Falcon",
		"Firecrawl",
		"FirecrawlAgent",
		"Flux",
		"Flyriver",
		"flyriverbot/1.1",
		"Frase AI",
		"FriendlyCrawler",
		"FraudGPT",
		"FIRE-1",
		"FIRE-1 Agent",
		"AI Ghostwriter",
		"Gato",
		"Gemini",
		"Gemini Agentic RAG",
		"Gemma",
		"Gemma 3",
		"Gen AI",
		"GenAI",
		"GenAI Chat",
		"Genspark",
		"gentoo-chat",
		"GenAI RAG",
		"gen-ai",
		"Ghostwriter",
		"GigaChat",
		"GLM",
		"Google Gemini",
		"Google-CloudVertexBot",
		"Google-Extended",
		"Goose",
		"GPT",
		"GPT 4 Omni",
		"GPT 4 Omni Mini",
		"GPT Scraper",
		"GPTBot",
		"GPTBot /",
		"GPTBot/1.2",
		"GPTZero",
		"GPT-1",
		"GPT-2",
		"GPT-3",
		"GPT-3.5",
		"GPT-3.5 turbo",
		"GPT-4",
		"GPT-4o",
		"GPT-4o Image",
		"GPT-4o mini",
		"GPT-4V",
		"GPT-4,5",
		"gpt-4-turbo",
		"GPT-4.1",
		"GPT-4.1-mini",
		"GPT-4.1-nano",
		"GPT-5",
		"gpt-crawler",
		"GPT/",
		"Grammarly",
		"Grendizer",
		"Grok",
		"Grok AI chatbot",
		"GrokAI",
		"GT Bot",
		"GTBot",
		"GTP",
		"GTPBOT",
		"Hemingway Editor",
		"Hugging Face",
		"Hypotenuse AI",
		"Hybrid Search RAG",			
		"iAskBot",
		"imgproxy",	
		"iaskspider",
		"iaskspider/2.0",
		"iAskBot",
		"ICC-Crawler",
		"ImagesiftBot",
		"img2dataset",
		"ImageGen",
		"ImageGen /",
		"ImageGPT",
		"Inferkit",
		"INK Editor",
		"INKforall",
		"IntelliSeek",
		"IntelliSeek.ai",
		"ISSCyberRiskCrawler",
		"JasperAI",
		"Janitor AI",
		"Jenni AI",		
		"Kaggle agent",	
		"Kaggle",			
		"Kafkai",
		"Kangaroo",
		"Kangaroo Bot",
		"Keyword Density AI",
		"Knowledge",
		"knowledge /",
		"KomoBot",
		"LangChain",
		"Langchain raptor",
		"langchain-google-genai",
		"langchain-perplexity",
		"langchain-openai",	
		"Lensa",
		"Lightpanda",
		"Le Chat",
		"LeftWingGPT",
		"LLaMA",
		"Llama 3.2",
		"Llama 4",
		"LLM",	
		"LLM Scraper",
		"Local RAG Agent",
		"Llama 3.1 Local RAG",
		"Local Hybrid Search RAG",		
		"magpie-crawler",
	    "Manus",
		"Magistral",
		"MarketMuse",
		"MetaTagBot",
		"Meltwater",
		"Meta AI",
		"Meta-AI",
		"MetaAI",
		"Meta Llama",
		"Meta.AI",
		"Meta-AI",
		"Meta-External",
		"Meta-ExternalAgent",
		"Meta-ExternalFetcher",
		"meta-externalagent",
		"meta-externalfetcher/1.1",
		"Mistral",
		"MistralAI-User/1.0",
		"Mixtral 8x22B",
		"midjourney",
		"Monica",		
		"MiniMax",
		"model-training",
		"Narrative",
		"NeevaBot",
		"Neural Text",
		"NeuralSEO",
		"NinjaAIBot/1.0",
		"Nicecrawler",	
		"Narrative",		
		"Narrative Device",
		"NinjaAIBot/1.0",
		"Nicecrawler",
		"NinjaAI",
		"Nova Act",
		"NovaAct",
		"NodeZero",
		"Node.js",			
		"OAI SearchBot",
		"OAI-SearchBot",
		"OAI-SearchBot/1.0",
		"Omgili",
		"Omgilibot",
		"OASIS",
		"Open AI",
		"OpenAI",
		"OpenAI o1",
		"OpenAI o3",
		"OpenAI o1-mini",
		"OpenAI o3-mini",
		"OpenAI Operator",
		"OpenAIContentCrawler",
		"OpenAI Crawler",
		"Operator",
		"Open Deep Research",
		"Open Perflexity",
		"OpenBot",
		"Open Deep Research",
		"OpenText AI",
		"OpenAI o3",
		"OpenAI GPTBot",
		"OpenAI Image Downloader",
		"Outwrite",	
		"Page Analyzer AI",
		"PanguBot",
		"Panscient",
		"PaperLiBot",
		"Paraphraser.io",
		"peer39_crawler",
		"peer39_crawler/1.0",
		"Perplexity",
		"PerplexityBot",
		"PerplexityBot/1.0",
		"PerplexityUser",
		"Perplexity-User",
		"Perplexity-User/1.0",
		"Perplexit-User",
		"Perplexity Deep Research",
		"Open Perflexity", 
		"petalBot",
		"PetalBot",
		"Phind",
		"PhindBot",
		"PiplBot",
		"ProWritingAid",
		"proximic",
		"Puppeteer",
		"Poe",
		"PoeBot",
		"PoeSearchBot",	
		"qwen /",
		"Qwen",
		"Qwen Chat",
		"Qwen2",
		"Qwen3",
		"Qwen2.5 72B",	
		"Qwen 2.5‑VL",
		"Qualified",
		"QualifiedBot",	
		"QuillBot",
		"Quark",		
		"RAPTOR LLM",
		"RAG", 
		"Raptor",
		"RAG Agent Cohere",
		"ReAct AI Agent", 
		"RAG Agent",
		"RAG Search",
		"RAG_VertexAI",
		"RAG_with_search",
		"RAG ChatGPT",
		"RAG LLM",
		"RAG Azure AI",
		"RAG Chatbot",
		"RAG pipeline",
		"Agentic RAG with LangGraph",
		"Corrective RAG", 	
		"Deepseek Local RAG Agent",
		"Gemini Agentic RAG",
		"Hybrid Search RAG",
		"Llama 3.1 Local RAG",
		"Local Hybrid Search RAG",
		"Local RAG Agent",
		"RAG-as-a-Service",
		"RAG Agent with Cohere",
		"RAG with Database Routing",
		"Redis AI RAG ",
		"RAG IS ",
		"RAG with ",
		"Rytr",
		"RobotSpider",		
		"RightWingGPT",		
		"SaplingAI",
		"Scala",
		"Scalenut",
		"ScrapeGraph",
		"ScrapeGraphAI",
		"Scrapegraph-ai",
		"Scraper",
		"ScraperGPT",
		"Scrapy",
		"Scrapy 2.12.0",
		"Scrapy 2.13.1",
		"Scrapy/2.0",
		"ScriptBook",
		"Search GPT",
		"SearchGPT",
		"Seekr",
		"SemrushBot",
		"SemrushBot-FT",
		"SemrushBot-OCOB",
		"SemrushBot-SWA",
		"Sentibot",
		"SEO Content Machine",
		"SEO Robot",
		"ShadowGPT",
		"Sidetrade",
		"Sidetrade /",
		"Simplified AI",
		"Sitefinity",
		"skrape.ai",
		"Skydancer",
		"SlickWrite",
		"SmartBot",
		"SmartScrape",
		"Sonic",
		"Sora",
		"Spin Rewrite",
		"Spinbot",
		"Stability AI",
		"StableDiffusionBot",
		"Sudowrite",
		"SummalyBot",
		"Super Agent",
		"Surfer AI",
		"SmartScraperGraph",
		"Text Blaze",
		"Thinkbot",
		"TorChat",	
		"TikTokSpider",
		"Traefik",
		"TorChat",	
		"Text Blaze",
		"TextCortex",
		"thehive.ai",
		"The Knowledge AI",
		"Timpibot",
		"TurnitinBot",
		"together AI",	
		"VelenPublicWebCrawler",
		"Venus Chub AI",
		"WebCrawler-AI",
		"Webscrape AI",
		"Webscrape",
		"Vision RAG",
		"Vidnami AI",
		"WebChatGPT",
		"Webzio",
		"Webzio-Extended",
		"WebText",
		"WebText /",
		"Whisper",
		"WormGTP",
		"wormsGTP",
		"WormGPT V3.0",
		"WPBot",
		"wpbot",
		"WRTNBot",
		"WRTNBot/1.0",
		"Writescope",
		"WriterZen",
		"WordAI",
		"Writesonic",
		"Wordtune",
		"Writecream",
		"webscraping-ai-ruby",
		"webscraping-ai-php",
		"webscraping-ai-python",
		"Scrapegraph-ai",
		"Webscrape AI",
		"WeChat",
		"WebCrawler-AI",
		"WRTNBot",
		"WRTNBot/1.0",		
		"xAI",
		"X.AI",		
        "xBot",
        "Zero",
        "Zero /",
		"Zero GTP",
		"ZeroCHAT",
		"Zerochat",
		"ZeroGPT",
		"ZeroSearch",	
		"yarchatgpt",
		"YandexGPT",
		"YandexLLM",
		"YandexAdditional",
		"YandexAdditionalBot",
		"YaLM",
        "YarGPT",
        "YarGPTZero /",
        "YouBot",
        "Zhipu",
        "XXXGPT",
        "Zhuque AI",
        "Zimm",		
        "2ip bot",
        "80legs",
        "404checker",
        "AhrefsBot",
        "ahrefsbot",
        "AhrefsBot/7.0",
        "AhrefsSiteAudit",
        "*bot.*.ahrefs.com",
        "*bot.*.ahrefs.com",
        "*bot.*.ahrefs.net",
        "*bot.*.ahrefs.net",
        "ai.azure**.com",
        "ai.gemma**.dev",
        "ai.meta**.com",
        "alibabacloud.com",
        "AliyunSecBot",
        "Anthropic**.com",
        "BLEXBot",
        "bot.*.cn",
        "Diffbot",
        "DotBot",
        "*bot.*.cn",
        "*crawl.*.ru",
        "*.chat.openai.com",
        "CensysInspect;",
        "copilot.microsoft**.com",
        "Cowboy 2.13",
        "curl",
        "CyotekWebCopy",
	    "Dalvik",
        "DataForSeoBot",
        "DomainStatsBot",
        "DotBot",
        "dotbot",
        "Extreme Picture Finder",
        "Expanse",
        "gemini.google**.com",
        "GuzzleHttp/7",
        "HeadlessChrome",
        "Headless",
        "huggingface**.co",
        "Internet-measurement",
        "Java-http-client",
        "libwww",
        "libwww-perl",
        "llama**.com",
        "Lmsis**.org",
        "majestic",
        "mistral**.ai",
        "MJ12bot",
        "MJ12**.com",
        "Nicecrawler/1.1",
        "Nikto",
        "Ninja",
        "Nmap",
        "Nuclei",
        "Nutch",
        "OnCrawl",
        "OpenAI**.com",
        "OpenVAS",
        "perplexity**.ai",
        "Prometheus",
        "python aiohttp",
        "Python",
        "python-httpx",
        "python-http",
        "python-requests",
        "Python-urllib",
        "semrush ",
        "SemrushBot",
        "SemrushBot-BA",
        "SemrushBot-BM",
        "SemrushBot-CT",
        "SemrushBot-FT",
        "SemrushBot-SA",
        "SemrushBot-SISF",
        "SemrushBot-SI",
        "SemrushBot-SWA",
        "SemrushBot/7~bl",
        "serpstatbot",
        "SiteAuditBot",
        "SplitSignalBot",
        "TinEye",
        "TinEye-bot",
        "TinEye-bot-live/1.31",
        "Uptime/1.0",
        "WebImageCollector",
        "Wget",
        "wget",
        "woorank",
        "WPScan",
        "Wp_is_mobile",
        "Xenu",
        "YaK",
        "Zeus",
        "Zgrab",
        "ZoominfoBot",		
        "ZmEu"
    ];


    public function __construct() {
        add_filter('robots_txt', [$this, 'modify_robots_txt'], 999, 2); // Use higher priority
    }

    public function modify_robots_txt($output, $public) {
	
		$Yandex_allow_block  = "User-agent: YandexBot\nAllow: /\n\n";
		$output = $Yandex_allow_block . $output;
		$Vivaldi_allow_block  = "User-agent: Vivaldi\nAllow: /\n\n";
		$output = $Vivaldi_allow_block . $output;
		$Qwant_allow_block  = "User-agent: QwantBot\nAllow: /\n\n";
		$output = $Qwant_allow_block . $output;
		$Peek_allow_block  = "User-agent: PeekBot\nAllow: /\n\n";
		$output = $Peek_allow_block . $output;
		$Mojeek_allow_block  = "User-agent: MojeekBot\nAllow: /\n\n";
		$output = $Mojeek_allow_block . $output;
		$ia_archiver_allow_block  = "User-agent: ia_archiver\nAllow: /\n\n";
		$output = $ia_archiver_allow_block . $output;
	    $Slurp_allow_block  = "User-agent: Slurp\nAllow: /\n\n";
		$output = $Slurp_allow_block . $output;
		$Seznam_allow_block  = "User-agent: SeznamBot\nAllow: /\n\n";
		$output = $Seznam_allow_block . $output;
	    $Startpage_allow_block  = "User-agent: StartpageBot\nAllow: /\n\n";
		$output = $Startpage_allow_block . $output;
		$Safari_allow_block  = "User-agent: Safari\nAllow: /\n\n";
		$output = $Safari_allow_block . $output;
		$OPR_allow_block  = "User-agent: OPR\nAllow: /\n\n";
		$output = $OPR_allow_block . $output;
		$FxiOS_allow_block  = "User-agent: FxiOS\nAllow: /\n\n";
		$output = $FxiOS_allow_block . $output;
	    $Firefox_allow_block  = "User-agent: Firefox\nAllow: /\n\n";
		$output = $Firefoxe_allow_block . $output;
		$Exa_allow_block  = "User-agent: ExaBot\nAllow: /\n\n";
		$output = $Exa_allow_block . $output;
		$Ecosia_allow_block  = "User-agent: EcosiaBot\nAllow: /\n\n";
		$output = $Ecosia_allow_block . $output;
	    $Giga_allow_block  = "User-agent: Gigabot\nAllow: /\n\n";	
		$output = $Giga_allow_block . $output;
        $google_allow_block  = "User-agent: Googlebot\nAllow: /\n\n";
		$output = $Giga_allow_block . $output;
        $google_allow_block .= "User-agent: Googlebot-Image\nAllow: /\n\n";
		$output = $Googlebot-Image_allow_block . $output;
        $google_allow_block .= "User-agent: Googlebot-News\nAllow: /\n\n";
		$output = $Googlebot-News_allow_block . $output;
        $google_allow_block .= "User-agent: Google-PageSpeed\nAllow: /\n\n";
		$output = $Google-PageSpeed_allow_block . $output;
        $google_allow_block .= "User-agent: Google-Site-Verification\nAllow: /\n\n";
		$output = $Google-Site-VerificationA_allow_block . $output;
        $google_allow_block .= "User-agent: Lighthouse\nAllow: /\n\n";
		$output = $Lighthouse_allow_block . $output;
		$output = $google_allow_block . $output;		
	    $CocCoc_allow_block  = "User-agent: CocCocBot\nAllow: /\n\n";
		$output = $CocCoc_allow_block . $output;
		$Brave_allow_block  = "User-agent: BraveBot\nAllow: /\n\n";
		$output = $Brave_allow_block . $output;
        $Bing_allow_block  = "User-agent: Bingbot\nAllow: /\n\n";
		$output = $Bing_allow_block . $output;		
	
        // Check if User-agent: * is present
        if (stripos($output, 'User-agent: *') === false) {
            $output .= "\nUser-agent: *\nAllow: /\n";
        } else {
            // Check if Allow: / is missing under User-agent: *
            $lines = explode("\n", $output);
            $new_output = '';
            $in_user_agent_all = false;
    
            foreach ($lines as $line) {
                if (stripos($line, 'User-agent: *') !== false) {
                    $in_user_agent_all = true;
                    $new_output .= $line . "\n";
                    continue;
                }
    
                if ($in_user_agent_all) {
                    if (preg_match('/^\s*(User-agent: )/i', $line)) {
                        // New User-agent found, but no Allow: / in previous block
                        $new_output .= "Allow: /\n";
                        $in_user_agent_all = false;
                    } elseif (stripos($line, 'Allow: /') !== false || stripos($line, 'Disallow:') !== false) {
                        $in_user_agent_all = false;
                    }
                }
    
                $new_output .= $line . "\n";
            }
    
            // Edge case: still in block at end of file
            if ($in_user_agent_all) {
                $new_output .= "Allow: /\n";
            }
    
            // $output = $new_output;
        }
    
        // // Add start comment for the block
        $output .= "\n# START AI Scrape Protect block\n# ---------------------------\n";
    

        // Add all User-agent rules
        foreach ($this->user_agents as $user_agent) {
            $output .= "User-agent: $user_agent\n";
            $output .= "Disallow: /\n\n";
        }
    
        // Add end comment for the block
        $output .= "# ---------------------------\n# END AI Scrape Protect block\n";
    
        return $output;
    }
    
    
    
}

class AISP_Add_Meta_Tags {

    public function __construct() {
        add_action('wp_head', [$this, 'add_ai_meta_tags'], 1);
    }
    public function add_ai_meta_tags() {
        echo "\n<!-- AI Scrape Protect Meta Tags -->\n\n";
        echo "<!-- Instructs general AI bots to avoid indexing, summarizing, or using the content. -->\n";
        echo '<meta name="robots" content="noai, nosummary, noimageai">' . "\n";
        echo "<!-- Prevents Bing's bot from using the content for AI purposes. -->\n";
        echo '<meta name="bingbot" content="nocache">' . "\n";
        echo "<!-- Future-proof tag for prohibiting AI training. -->\n";
        echo '<meta name="robots" content="DisallowAITraining, model-training">' . "\n";
        echo "<!-- End AI Scrape Protect Meta Tags -->\n";
    }
}

// Add icons to the WordPress Admin Bar
class AISP_Admin_Bar_Icons {

    public function __construct() {
        // Hook into WordPress admin bar to display icons
        add_action('admin_bar_menu', [$this, 'add_admin_bar_icons'], 100);
    }

    public function add_admin_bar_icons($admin_bar) {
        // Ensure the function is loaded and available
        if ( !function_exists('is_plugin_active') ) {
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }

        // Check if the plugin is active
        $is_plugin_active = is_plugin_active('ai-scrape-protect/ai-scrape-protect.php');

        // Define the icon URLs based on the plugin state
        $icon_url = $is_plugin_active ? plugin_dir_url(__FILE__) . 'images/ai-scrape-protect-active.png' : '';

        // Debug: Output for testing
        // error_log('Plugin active: ' . ($is_plugin_active ? 'Yes' : 'No'));

        // Add an item to the admin bar with the corresponding icon
        $admin_bar->add_node([
            'id'    => 'ai-scrape-protect-icon',
            'title' => '<img src="' . esc_url($icon_url) . '" alt="' . __('AI Scrape Protect Icon', 'ai-scrape-protect') .'" title="' . __('AI Scrape Protection enabled, click for plugin info', 'ai-scrape-protect') .'" style="height: 20px; width: 20px;"/>',
            'href'  => 'https://codesurf.eu/wordpress-ai-scrape-protect-plugin/', 
            'meta'  => [
                'target' => '_blank' 
            ]
        ]);
    }
}




// Initialize all classes
new AISP_Manage_Robots_Txt();
new AISP_Add_Meta_Tags();
new AISP_Admin_Bar_Icons();
