<?php

 /**
  * The plugin bootstrap file
  *
  * @link              https://robertdevore.com
  * @since             1.0.0
  * @package           Block_AI_Crawlers
  *
  * @wordpress-plugin
  *
  * Plugin Name: Block AI Crawlers
  * Description: Adds an option to block known AI crawlers via the robots.txt file
  * Plugin URI:  https://github.com/robertdevore/block-ai-crawlers/
  * Version:     1.1.2
  * Author:      Robert DeVore
  * Author URI:  https://robertdevore.com/
  * License:     GPL-2.0+
  * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
  * Text Domain: block-ai-crawlers
  * Domain Path: /languages
  * Update URI:  https://github.com/robertdevore/block-ai-crawlers/
  */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Define constants.
define( 'BLOCK_AI_CRAWLERS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BLOCK_AI_CRAWLERS_VERSION', '1.1.2' );

// Add the Plugin Update Checker.
require 'vendor/plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://github.com/robertdevore/block-ai-crawlers/',
    __FILE__,
    'block-ai-crawlers'
);

// Set the branch that contains the stable release.
$myUpdateChecker->setBranch( 'main' );

// Check if Composer's autoloader is already registered globally.
if ( ! class_exists( 'RobertDevore\WPComCheck\WPComPluginHandler' ) ) {
    require_once __DIR__ . '/vendor/autoload.php';
}

use RobertDevore\WPComCheck\WPComPluginHandler;

new WPComPluginHandler( plugin_basename( __FILE__ ), 'https://robertdevore.com/why-this-plugin-doesnt-support-wordpress-com-hosting/' );

/**
 * Load plugin text domain for translations
 * 
 * @return void
 */
function block_ai_crawlers_load_textdomain() {
    load_plugin_textdomain( 
        'block-ai-crawlers',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages/'
    );
}
add_action( 'plugins_loaded', 'block_ai_crawlers_load_textdomain' );

/**
 * Class Block_Ai_Crawlers
 * 
 * This class provides functionality to block AI crawlers from accessing the site.
 * It integrates with WordPress settings to allow users to enable or disable
 * the blocking feature. When enabled, known AI crawlers are disallowed via robots.txt.
 *
 * Features:
 * - Adds a checkbox in the Settings > Reading section to enable AI crawler blocking.
 * - Modifies the robots.txt output dynamically to disallow known AI crawlers.
 *
 * Usage:
 * - Activate the plugin.
 * - Navigate to Settings > Reading and enable "Block AI Crawlers".
 */
class Block_Ai_Crawlers {

    private $option_name = 'block_ai_crawlers_enabled';

    private $ai_crawlers = [];

    public function __construct() {
        $this->ai_crawlers = apply_filters('block_ai_crawlers_crawler_list', [
            'GPT-Sw3',
            'errorAI',
            'Agent GPT',
            'AgentGPT',
            'Agentic AI',
            'AI Article Writer',
            'AI Content Detector',
            'AI Dungeon',
            'AI Search Engine',
            'AI SEO Crawler',
            'AI2 Bot',
            'AI2Bot',
            'AI21 Labs',
            'AIBot',
            'AIMatrixCrawler',
            'AISearchBot',
            'AITraining',
            'Alpha AI',
            'Alexa',
            'AlexaTM',
            'Amazon Bedrock',
            'Amazon Comprehend',
            'Amazon Lex',
            'Amazon SageMaker',
            'Amazon Silk',
            'Amazon Textract',
            'AmazonBot',
            'amazon-kendra',
            'Amelia',
            'AndersPinkBot',
            'anthropic-ai',
            '.ai',
            'AnyPicker',
            'Anyword',
            'Applebot-Extended',
            'Aria browse Aria AI',
            'Aria browser AI',
            'Articoolo',
            'AutoGPT',
            'Automated Writer',
            'AwarioRssBot',
            'AwarioSmartBot',
            'BardBot',
            'Bing ai',
            'BingAI',
            'bingbot-chat/2.0',
            'Brave Leo AI',
            'Bytespider',
            'Bytedance',
            'CatBoost',
            'CCBot',
            'ccbot',
            'CCBot/2.0',
            'CC-Crawler',
            'CC-Crawler/2.0',
            'ChatGPT',
            'ChatGPT-User',
            'Chinchilla',          
            'Claude 3.5 Haiku', 
            'Claude 3.5 Sonnet', 
            'ClaudeBot',
            'claudebot',            
            'claudeBot',
            'Claude bot',
            'ClaudeBot/1.0',
            'Claude 2.0',
            'Claude 2.1',
            'ClaudeBot',
            'Claude-Web/1.0',
            'Claude-Web',
            'ClearScope',
            'Ccohere-ai',
            'cohere-training-data-crawler',
            'Common Crawl',
            'commoncrawl',
            'Content Harmony',
            'Content King',
            'Content Optimizer',
            'Content Samurai',
            'ContentAtScale',
            'ContentBot',
            'Contentedge',
            'Conversion AI',
            'Copymatic',
            'Copy.ai',
            'CrawlQ AI',
            'Crawlspace',
            'Copyscape',
            'CopyAI',
            'Crew AI',
            'crewAI',
            'DALL-E',
            'DALL-E 2',
            'Dalvik/2',
            'Dalvik/2.1.0',
            'DataForSeoBot',
            'dataprovider',
            'DeepAI',
            'DeepL',
            'DeepMind',
            'DeepSeek',
            'DepolarizingGPT',
            'DialoGPT',
            'Diffbot',
            'Doubao AI',
            'DuckAssistBot',
            'FacebookBot',
            'FacebookBot/1.0',
            'facebookexternalhit',
            'facebookexternalhit/1.1',
            'LLaMA',
            'Llama 3.2',
            'Meta AI',
            'Meta Llama',
            'Firecrawl',
            'FirecrawlAgent',
            'Flyriver',
            'flyriverbot/1.1',
            'Frase AI',
            'FriendlyCrawler',
            'FriendlyCrawler/1.0',
            'riendlyCrawler/Nutch-1.20-SNAPSHOT',
            'Gemini',
            'Gemma',
            'GenAI',
            'Google Bard AI',
            'Google Gemini',
            'GoogleOther',
            'Google-CloudVertexBot',
            'Google-Extended',
            'GPT 4 Omni',
            'GPT 4 Omni Mini',
            'GPTBot',
            'GPTbot/0.1',
            'GPTBot/1.0',
            'GPTBot/1.2',
            'GPTZero',
            'GPT-1',
            'GPT-2',
            'GPT-3',
            'GPT-3.5',
            'GPT-3.5 Turbo',
            'GPT-4',
            'GPT-4o',
            'GPT-4o mini',
            'GPT-4V',
            'gpt-4-turbo',
            'GPT Scraper',
            'SearchGPT', 
            'Grammarly',
            'Grok',
            'GrokAI',
            'Grendizer/7.74.0',
            'Hemingway Editorr',
            'Hemingway Editor',
            'Hugging Face',
            'Hypotenuse AI',
            'iaskspider',
            'iaskspider/2.0',
            'ICC-Crawler',
            'ImagesiftBot',
            'img2dataset',
            'Inferkit',
            'INK Editor',
            'INKforall',
            'IntelliSeek',
            'IntelliSeek.ai',
            'ISSCyberRiskCrawler',
            'Inferkit',
            'INK Editor',
            'JasperAI',
            'Kafkai',
            'Kangaroo',
            'Kangaroo Bot',
            'Keyword Density AI',
            'KomoBot',
            'LeftWingGPT',
            'LLaMA',
            'Llama 3.2',
            'magpie-crawler',
            'MarketMuse',
            'MetaTagBot',
            'Meltwater',
            'Mistral',
            'Neural Text',
            'NeuralSEO',
            'Narrative',
            'Narrative Device',
            'Nicecrawler',
            'OAI SearchBot',
            'OAI-SearchBot/1.0',
            'Omgili',
            'Omgilibot',
            'Open AI',
            'OpenAI',
            'OpenAI o1',
            'OpenAI o1-mini',
            'OpenAI o3-mini',
            'OpenAIContentCrawler',
            'Openbot',
            'OpenText AI',
            'Outwrite',
            'PanguBot',
            'PaperLiBot',
            'PaperLiBot/2.1',
            'peer39_crawler',
            'peer39_crawler/1.0',
            'PerplexityBot',
            'PetalBot',
            'PiplBot',
            'proximic',
            'PaperLiBot',
            'PaperLiBot/2.1',
            'PiplBot',
            'PhindBot',
            'ProWritingAid',
            'Paraphraser.io',
            'Page Analyzer AI',
            'QuillBot',
            'Rytr',
            'RobotSpider',
            'Spin Rewriter',
            'Scalenut',
            'ScalenutBot',
            'Simplified AI',
            'SaplingAI',
            'Surfer AI',
            'SkyDancer Ai',
            'SEO Content Machine',
            'SlickWrite',
            'Sudowrite',
            'Spinbot',
            'SEO Robot',
            'ScriptBook',
            'SaplingAI',
            'ScalenutBot',
            'Scrapy',
            'Scrapy/2.0',
            'ScriptBook',
            'SearchGPT',
            'SemrushBot',
            'SemrushBot-FT',
            'SemrushBot-OCOB',
            'sentibot',
            'ScrapeGPT',
            'SEO Content Machine',
            'SEO Robott',
            'ShadowGPT',
            'Sidetrade',
            'Simplified AI',
            'SlickWrite',
            'Spin Rewriter',
            'Stability',
            'Stability AII',
            'StableDiffusionBot',
            'Sudowrite',
            'Surfer AI',
            'Text Blaze',
            'TextCortex',
            'thehive.ai',
            'The Knowledge AI',
            'Timpibot',
            'Timpibot/0.8',
            'TurnitinBot',
            'RightWingGPT',
            'VelenPublicWebCrawler',
            'Vidnami AI',
            'WebChatGPT',
            'Webzio',
            'Webzio-Extended',
            'Whisper',
            'WormGPT V3.0',
            'wpbot',
            'wpbot/1.1',
            'wpbot/1.2',
            'Writescope',
            'WriterZen',
            'WordAI',
            'Writesonic',
            'Wordtune',
            'Writecream',
            'Vidnami AI',
            'xAI',
            'XBot',
            'x.AI',
            'Zero GTP',
            'ZeroCHAT',
            'ZeroGPT',
            'ZimmWriter',
            'ZimmWrite',
            'yarchatgpt',
            'YarGPT',
            'YouBot',
        ] );

        add_action( 'admin_init', [ $this, 'register_setting' ] );
        add_action( 'do_robots', [ $this, 'modify_robots' ] );
    }

    /**
     * Register the setting in Reading Settings.
     *
     * This function adds a new setting field to the WordPress Reading Settings page.
     * It allows users to enable or disable the blocking of AI crawlers.
     *
     * @return void
     */
    public function register_setting() {
        register_setting( 'reading', $this->option_name );

        add_settings_field(
            $this->option_name,
            esc_html__( 'AI crawlers visibility', 'block-ai-crawlers' ),
            [ $this, 'render_setting_field' ],
            'reading'
        );
    }

    /**
     * Render the setting field.
     *
     * Outputs the HTML for the "Block AI Crawlers" checkbox in the Reading Settings page.
     * If the setting is enabled, the checkbox will be checked.
     *
     * @return void
     */
    public function render_setting_field() {
        $value = get_option( $this->option_name, 0 );
        $html  = '<fieldset>';
        $html .= '<legend class="screen-reader-text"><span>' . esc_html__( 'Block AI Crawlers', 'block-ai-crawlers' ) . '</span></legend>';
        $html .= '<label for="' . esc_attr( $this->option_name ) . '"><input name="' . esc_attr( $this->option_name ) . '" type="checkbox" id="' . esc_attr( $this->option_name ) . '" value="1" ' . checked( 1, $value, false ) . ' /> ' . esc_html__( 'Block AI Crawlers from crawling your site', 'block-ai-crawlers' ) . '</label>';
        $html .= '<p class="description">' . esc_html__( 'Prevent known AI crawlers from crawling your site.', 'block-ai-crawlers' ) . '</p>';
        $html .= '</fieldset>';
        echo $html;
    }

    /**
     * Modify robots.txt rules if the setting is enabled.
     *
     * Dynamically appends `Disallow` rules to the `robots.txt` file for each AI crawler
     * in the predefined list if the blocking option is enabled.
     *
     * @since  1.0.0
     * @return void
     */
    public function modify_robots() {
        if ( get_option( $this->option_name ) ) {
            foreach ( $this->ai_crawlers as $crawler ) {
                echo "User-agent: {$crawler}\n";
                echo "Disallow: /\n";
            }
        }
    }
}

new Block_Ai_Crawlers();
