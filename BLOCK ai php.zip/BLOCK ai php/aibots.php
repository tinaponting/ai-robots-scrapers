<?php
if(stripos($_SERVER['HTTP_USER_AGENT'],'.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'_ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai.')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai-')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai_')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai=')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'.*?-ai$ ')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai=n')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AddSearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AddSearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ademicBotRTU')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agent 3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agent API')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agent GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AgentGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AgentGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AgentGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agentic Deep Research')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agentic RAG with LangGraph')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agentic RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agentic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agentic-RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AgentQL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI agents /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Article Writer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Content Detector')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI copilot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Detection')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Dungeon')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Journalist Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Journalist')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Legion')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Search Engine')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Search Intent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI SEO Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Training')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Web Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Website Screenshot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Web')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Writer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI2 Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI2Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI21 Labs')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AIBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'aiHitBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AIMatrix')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AISearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AISearch')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AITraining /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AITraining')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai-crawlers-training')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI-Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ai-proxy')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AlexaTM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Alexa')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Alice Yandex')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AliGenie')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AliyunSecBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AliyunSec')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Alpha AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AlphaAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Athena')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Bedrock')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Comprehend')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Lex')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon SageMaker')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Silk')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon Textract')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazonbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'amazonBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amazon')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'amazon-kendra')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Amelia')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AndiBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'anonymous AI chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Anonymous AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Anthropic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'anthropic-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AnyPicker')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AnythingLLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Anyword')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Applebot-Extended')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Apple-GenAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Aria AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Aria browse Aria AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Aria browser AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Aria Browse')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Articoolo')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Ask AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AutoGen')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AutoGLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AutoGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Automated Writer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AutoML')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Autonomous RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Auto-GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AwarioRssBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AwarioSmartBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AWS bedrock')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AWS Trainium')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Azure AI Search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Azure')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Azure OpenAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'BabyAGI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'BabyCatAGI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'BardBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Basic RAG Chain')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Basic RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Bedrock Claude')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Bedrock')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'bedrock-chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'bedrock-chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'bedrock-claude-chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Big Sur AI Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Big Sur AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Big Sur')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Bigsur')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'bigsur.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Botsonic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Brave Leo AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'BraveGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Brightbot 1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Brightbot operator')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Brightbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Browser MCP Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Browser Use')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Bytebot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ByteDance crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ByteDance')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'byteDance')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Bytespider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CarynAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CatBoost')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CCBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ccbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CCBot/2.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CC-Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CC-Crawler/2.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Celia')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Ceramic TerraCotta Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Chai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Character')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Charstar AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Chat2DB-Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatAnthropic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 3.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 4o')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 4o-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 4.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 4.5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT 5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT o1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT o3-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT Operator')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT-User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT-User/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGPT-User/2.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatLLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatGLM-Spider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatOpenAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Chatsonic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'chatUser /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ChatUser')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Chinchilla')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude 3.5 Haiku')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude 3.5 Sonnet')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude 3.5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude 3.7 Sonnet')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Opus 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Opus 4.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Opus')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Sonnet 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude Sonnet 4.5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ClaudeBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ClaudeBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude-RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude-SearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude-User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Claude-Web')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'claude-web/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'claude.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ClearScope')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Clearview')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Cognitive AI engine')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Cognitive AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Cohere RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Cohere')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'cohere-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'cohere-ai/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'cohere-training-data-crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Common Crawl')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CommonCrawl')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Content Harmony')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Content King')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Content Optimizer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Content Samurai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Content Scraper GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ContentAtScale')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ContentBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Contentedge')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ContentShake')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Conversion AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CopilotBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Copilot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CopyAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Copymatic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Copyscape')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CoreWeave')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Corrective RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Cotoyogi')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CRAB')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Crawl4AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CrawlGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CrawlQ AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Crawlspace')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Crew AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'CrewAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Crushon AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'cURL /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'cURL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DALL-E 2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Dall-E 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DALL-E Mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DALL-E')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DALL·E 3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DarkBard')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DataForAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DataForSeoBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DataFor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DataProvider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'dataprovider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Datenbank Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Deep AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Deep Research')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepMind')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Deepseek Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepResearch')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeek R1 Y')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeek V3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeekBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeekV2.5-Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeek')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeek-LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DeepSeek-R1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DepolarizingGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Devin')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DialoGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Diffbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DigitalOceanGenAICrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Doubao AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DuckAssistBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DuckDuckGo Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'DuckDuckGo-Enhanced')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Duck.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Echobot	')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Echobox')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Elixir')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Extended GPT Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FacebookBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FacebookBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FacebookExternalHit')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'facebookexternalhit/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Factset')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Factset_spyderbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Falcon')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Fastai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FastGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Firebase')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FirecrawlAgent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Firecrawl')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Fireworks')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FIRE-1 Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FIRE-1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Flux')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'flyriverbot/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Flyriver')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Frase AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FraudGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'FriendlyCrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI Ghostwriter')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gato')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemini Agentic RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemini User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemini-Deep-Research')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemma 3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gemma')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Gen AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GenAI Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GenAI RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GenAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Generative')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Genspark')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'gentoo-chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'gen-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Ghostwriter')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GigaChat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GodMode')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Google Gemini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GoogleAgent-Mariner')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Google-CloudVertexBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Google-Extended')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Goose')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Go')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Go')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT 4 Omni Mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT 4 Omni')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT Chat 3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT OSS')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT Researcher')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT4ALL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT4Free')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPTBot /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPTBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPTBot/1,2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPTBot/1.2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPTZero')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-3.5 turbo')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-3.5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4o Image')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4o mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4o')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4V')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4,5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'gpt-4-turbo')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4.1-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-4.1-nano')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5 Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5 Mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5 Nano')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5 Thinking mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5o')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'gpt-crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT-oss /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GPT/')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Grammarly')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Grendizer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Grok 4 Fast')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Grok AI chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GrokAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GrokBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Grok')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GT Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GTBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GTPBOT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'GTP')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hemingway Editor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hetzner')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hugging Face')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'HuggingChat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hugging')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hunyuan')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hunyuan-7B-Instruct 7B')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hunyuan-Large-Instruct')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'hybrid LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hybrid Search RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Hypotenuse AI')!== false){	
if(stripos($_SERVER['HTTP_USER_AGENT'],'iAskBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'iaskspider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'iaskspider/2.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ICC-Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ImageGen')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ImageGen /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ImagesiftBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'img2dataset')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'imgproxy')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ImageGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Inferkit')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'INK Editor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'INKforall')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'IntelliSeek')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'IntelliSeek.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Instructor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'instructor-php')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ISSCyberRiskCrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Jamba 1.5 Large')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Jamba 1.5 Mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Janitor AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'JasperAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Jenni AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Julius AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kafkai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kaggle agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kaggle')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kangaroo Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kangaroo')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kangaroo-Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Keyword Density AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kimi K2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kimi')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kimi-2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kimi-k1.5')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kimi-VL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kingsoft-LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Knowledge Graph')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'knowledge /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Knowledge')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'knowledge-base')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'KomoBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Kruti')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Langchain raptor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LangChain')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'langchain-google-genai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'langchain-openai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'langchain-perplexity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LangExtract')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Le Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LeftWingGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Lensa')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Lightpanda')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LINER Bot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LinerBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LinerBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LiteLLM Proxy')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LiteLLM Python')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LiteLLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama 3.1 Local RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama 3.1 Local RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama 3.2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama3.1-70B-Instruct')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Llama3.1-405B-Instruct')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LLaMA')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LLM Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LLM Proxy')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Local Hybrid Search RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Local RAG Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Local RAG Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Local RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'LocalAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Lovable')!== false){	
if(stripos($_SERVER['HTTP_USER_AGENT'],'Magistral ')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Magnus')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'magpie-crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Manus')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MarketMuse')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meltwater')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta AI Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta Llama')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MetaAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MetaGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MetaTagBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-ExternalAgent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'meta-externalagent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'meta-externalagent/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-ExternalFetcher')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'meta-externalfetcher/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-External')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-Webindexer 1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta-Webindexer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'meta-webindexer/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Meta.AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Middleware')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'midjourney')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mini AGI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MiniMax')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mintlify')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MistralAI-User/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MistralAI-User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mistral')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mistral.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mixtral 8x22B')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mixtral-8x22B-Instruct')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'MobileLLM-R1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'model-training')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Monica')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Moonshot ')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Mycroft AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'n8n-nodes-aiscraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Narrative')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NeevaBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'netEstate Imprint Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'netEstate')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Neural Text')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NeuralSEO')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Nicecrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NinjaAIBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NinjaAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NodeZero')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Node.js')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Nova Act')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'NovaAct')!== false){	
if(stripos($_SERVER['HTTP_USER_AGENT'],'OAI SearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OAI-SearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OAI-SearchBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OASIS')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Ola')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Olivia')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Ollama')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'oLLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Omgilibot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Omgili')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open Deep Research')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open Interpreter')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open Lovable')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open Perflexity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAGI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI Crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI CUA')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI GPTBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI Image Downloader')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI o1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI o1-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI o3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI o3-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI o4-mini')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI Operator')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAIContentCrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Openbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenLens AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'openpi')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenRouter')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'openrouter')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OpenText AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Operator')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Outwrite')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'OWL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Page Analyzer AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PanguBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Panscient')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'panscient.com')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PaperLiBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Paraphraser.io')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'peer39_crawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'peer39_crawler/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PerfectChatGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perflexity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity Deep Research')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity Search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PerplexityBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PerplexityBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PerplexityUser')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity-User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexity-User/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Perplexit-User')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Open Perflexity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PetalBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'petalBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Petal')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PhindBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Phind')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PiplBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PoeBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PoeSearchBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Poe')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PrivateGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ProWritingAid')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'proximic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Puppeteer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'python Ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PyTorch Lightning LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'PyTorch Lightning')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qualified')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'QualifiedBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'quillbot.com')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'QuillBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Quark')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'qwen /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen-Chat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen3')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen 4')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'qwen:4b')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen 4 LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'QwenLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen2.5 72B')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen 2.5‑VL')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen-Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qopywriter.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Qwen-Agent')!== false){	
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Agent Cohere')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Azure AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Chatbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG ChatGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Database Routing')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Database')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG IS')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Pipeline')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG Search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG with')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG-as-a-Service')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG-')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG_VertexAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG_with_search')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAG_')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RAPTOR LLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Raptor')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'React Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ReAct AI Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ReaderLM-v2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ReadyAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Redis AI RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RightWingGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'RobotSpider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Rytr')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sambanova')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SaplingAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scala')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scalenut')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ScrapeGraphAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ScrapeGraph')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scrapegraph-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ScraperGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scraper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scrapy 2.12.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scrapy 2.13.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scrapy')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Scrapy/2.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ScriptBook')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Search GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Search RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SearchGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Seekr')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SemrushBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SemrushBot-FT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SemrushBot-OCOB')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SemrushBot-SWA')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sentibot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SEO Content Machine')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SEO Robot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SEObot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ShadowGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ShapBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Shell GPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sidetrade /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sidetrade')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Simplified AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sitefinity')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'skrape.ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Skydancer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SlickWrite')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SmartBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SmartScraperGraph')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SmartScrape')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sonic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sora')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Spawning-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'spawning-ai')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Spider-Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Spider/2.0; +https://spider.')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Spin Rewrite')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Spinbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Stability AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'StableDiffusionBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Sudowrite')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SummalyBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Super Agent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Superagent')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'superagi')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Surfer AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'SUSE AI ')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Knowledge')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'TerraCotta')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Text Blaze')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'TextCortex')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Text-RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'The Knowledge AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'thehive.a1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Thinkbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Thinkbot/0.5.8')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Thordata')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'TikTokSpider')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Timpibot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Together AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'TorChat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Traefik')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'TurnitinBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'uAgents')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'AI – WPBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'VelenPublicWebCrawler')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Venus Chub AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Vidnami AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Vision RAG')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'vnCallbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'vnFace')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'VNPT SmartBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'VNPT SmartReader')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Web 3.0 Navigator')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebChatGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebCrawler-AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebExplorer-8B')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Webscrape AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Webscrape')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'webscraping-ai-php')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'webscraping-ai-python')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'webscraping-ai-ruby')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebSurfer')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebText /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WebText')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Webzio')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Webzio-Extended')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WeChat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Whisper')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WizardLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WordAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Wordtune')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WormGPT V3.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WormGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WPBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WPBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'wpbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'wpbot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WPBot/1.1')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WPBot/1.2')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Writecream')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WriterZen')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Writescope')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Writesonic')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WRTNBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'WRTNBot/1.0')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'xAI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'xBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'x.AI ')!== false){				
if(stripos($_SERVER['HTTP_USER_AGENT'],'YaML')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YandexGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YandexLLM')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YandexAdditional')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YandexAdditionalBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'yarchatgpt')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YarGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YouBot')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'YourGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zero /')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zero')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zero GTP')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ZeroCHAT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zerochat')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ZeroGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ZeroSearch')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zhuque AI')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zhuque AI Detector')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zhipu')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'XXXGPT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'Zimm')!== false){	
if(stripos($_SERVER['HTTP_USER_AGENT'],'ADD YOUR BOT')!== false){
if(stripos($_SERVER['HTTP_USER_AGENT'],'ADD YOUR BOT')!== false){
exit(0);
}
?>