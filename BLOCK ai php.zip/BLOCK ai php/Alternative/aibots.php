<?php
$block = array('AutoGPT','autogpt.net')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Agent','agent/ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Agent GPT','agentgpt.reworkd.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('anthropic-ai','https://www.anthropic.com/')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Aria AI','opera.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Aria browser AI','opera.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Alexa','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Bedrock','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon SageMaker','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AWS Trainium ','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Kendra','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Bedrock','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AlexaTM','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Textract','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Comprehend','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Amazon Silk','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AISearchBot','amazon.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AlphaAI','https://aiforalpha.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Applebot-Extended','apple.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AnyPicker','https://app.anypicker.com/')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AIBot','https://allenai.org/')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AI2 Bot','https://allenai.org/')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AndersPinkBot','anderspink.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('AITraining','AITrainingbots')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();	
$block = array('Brave Leo AI','brave.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('bingbot-chat/2.0','bing.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Bytedance','bytedance.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Bytespider','bytedance.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ByteDance crawler','bytedance.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('BardBot','bing.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Bing ai','bing.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Brightbot 1.0','brightbot.app')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('CatBoost','catboost.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('chat','chat/AI')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ChatGPT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ChatGPT-User','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ChatGPT-User/1.0','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('cohere-ai','cohere.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('cohere-training-data-crawler','cohere.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Cotoyogi','ds.rois.ac.jp/en_center8/en_crawler')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ClaudeBot','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Claude claude-web/1.0','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ClaudeBot/1.0','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Claude 3.7 Sonnet','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Claude 3.5 Haiku','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Claude Opus','anthropic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('CrawlGPT','.openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('crewAI','crewai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Chinchilla','DeepMind')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('CCBot',' commoncrawl.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('CCBot/2.0',' commoncrawl.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('CC-Crawler/2.0','infomine.ucr.edu')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DALL-E','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DALL-E 2','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DALL-E 3','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DALL-E Mini','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Doubao AI','team.doubao.com/en')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DeepAI','deepai.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('DeepL','deepai.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('DeepMind','DeepMind')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('DeepSeek-R1','www.deepseek.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('DeepSeek','www.deepseek.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('dataprovider','dataprovider.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Diffbot','diffbot.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DialoGPT','huggingface.co')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DepolarizingGPT','depolarizinggpt.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DialoGPT','huggingface.co')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('DuckAssistBot','https://duckduckgo.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FriendlyCrawler','.bc.googleusercontent.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FriendlyCrawler/1.0	','.bc.googleusercontent.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FriendlyCrawler/Nutch-1.20-SNAPSHOT','.bc.googleusercontent.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FacebookBot','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FacebookBot/1.0','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('facebookexternalhit','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('flyriverbot/1.1','flyriver.com/crawler')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Meta AI','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array(' Meta-ExternalAgent','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array(' Meta-ExternalFetcher','Facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Meta-ExternalFetcher','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('meta-externalfetcher/1.1','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Llama 3.2','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Meta AI','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Firecrawl','firecrawl.dev')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('FraudGPT','secureops.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('LLaMA','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Meta Llama','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Mistral','facebook.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Gato','Generative AI ')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GenAI','Generative AI')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPTbot/0.1','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('gpt-crawler','builder.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPTBot/1.0','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPTBot/1.2','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GTPBOT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OAI-SearchBot','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPTbot/0.1','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('GPTBot/1.0','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('GPTBot/1.2','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('GPT-1','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('GPT-2','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-3','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-3.5','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-3.5 turbo','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-4','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-4V','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('gpt-4-turbo','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-4o','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-4o mini','openai.comt')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT 4 Omni','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT 5','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT-4.5','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('gpt-4-turbo','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPTZero','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('SearchGPT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Content Scraper GPT','gptstore.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Extended GPT Scraper','apify.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ZeroGPT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ZeroCHAT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Gemini','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Google Gemini','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GoogleOther','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Google-CloudVertexBot','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('WebChatGPT','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Google-Extended','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Google-CloudVertexBot','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('Google Bard AI','google.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('Grok','x.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()	
$block = array('GrokAI','x.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()	
$block = array('Goose','block.github.io/goose')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit()
$block = array('Hugging Face','huggingface.co')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ISSCyberRiskCrawler','censys.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ICC-Crawler','ucri.nict.go.jp/en/icccrawler')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('IntelliSeek','intelliseek.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('IntelliSeek.ai','intelliseek.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ImagesiftBot','+imagesift.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('img2dataset','github.com/rom1504/img2dataset')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('iaskspider','iask.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('iaskspider/2.0','iask.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('iAskBot','iask.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Kangaroo','kangaroollm.com.au')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Kangaroo Bot','kangaroollm.com.au')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('knowledge','Generative AI')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('LeftWingGPT','depolarizinggpt.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Meltwater','www.meltwater.com/en')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Nicecrawler','nicecrawler.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('magpie-crawler','brandwatch.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('MSBot','microsoft..com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();	
$block = array('Omgilibot','webz.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Omgili','webz.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit(); 
$block = array('Open AI','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Openbot','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OpenAI Crawler','microsoft.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();

$block = array('OpenAIContentCrawler','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();	
$block = array('OAI-SearchBot','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OAI-SearchBot/1.0','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OpenAI o1','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OpenAI o1-mini','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('OpenAI o3-mini','openai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PaperLiBot','finity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PaperLiBot/2.1','finity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PanguBot','huwai.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('proximic','proximic.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PetalBot','aspiegel.com/petalbot')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PiplBot','pipl.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('peer39_crawler','peer39.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('peer39_crawler/1.0','peer39.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PerplexityBot','perplexity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Perplexity-User/1.0','perplexity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Perplexit-User','perplexity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('PerplexityUser','perplexity.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('RightWingGPT','depolarizinggpt.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Sidetrade','sidetrade.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ScrapeGPT','gptstore.ai/gpts/re5RLeMZTc-scrapegpt')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('GPT Scraper','apify.com/drobnikj/gpt-scraper')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Seekr','seekr.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();	
$block = array('StableDiffusionBot','iffusion.gg')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ShadowGPT','shadowgpt.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Stability AI','stability.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('scrapy','scrapy.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Scrapy/2.0','scrapy.org')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('SemrushBot-OCOB','semrush.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('The Knowledge AI','tryfastgpt.ai/')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Timpibot','timpi.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('thehive.ai','https://thehive.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Timpibot/0.9','timpi.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('TurnitinBot','turnitin.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('VelenPublicWebCrawler','velen.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('WebChatGPT','tools.zmo.ai/webchatgpt')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('WormGPT','flowgpt.com/p/wormgpt-v30')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('WormGPT V3.0','flowgpt.com/p/wormgpt-v30')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('wpbot','wordpress.org/plugins/chatbot')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('wpbot/1.1','wordpress.org/plugins/chatbot')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('wpbot/1.2','wordpress.org/plugins/chatbot')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Webzio','https://webz.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('Webzio-Extended','https://webz.io')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
exit();
$block = array('xAI','x.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
exit();
$block = array('XBot','x.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
exit();
$block = array('x.AI','x.ai')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('YouBot','you.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('YarGPT','http://yarchatgpt.ru')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('yarchatgpt','http://yarchatgpt.ru')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('ZeroGPT','www.zerogpt.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();	
$block = array('ZeroCHAT','https://www.zerogpt.com')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('some ai','adress')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('some ai','adress')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
$block = array('some ai','adress')
$useragent=strtolower($_SERVER['HTTP_USER_AGENT']);
foreach($block as $v){
if(strstr($useragent,$v)){
header("Location: http://www.thesite.com/blocked.php");
exit();
}
}
?>