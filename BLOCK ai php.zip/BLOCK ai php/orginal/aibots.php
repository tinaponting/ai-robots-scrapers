<?php
if (stripos($_SERVER['HTTP_USER_AGENT'], 'evilbot') !== false) {
if (stripos($_SERVER['HTTP_USER_AGENT'], 'evilbot') !== false) {
exit(0);
}
?>