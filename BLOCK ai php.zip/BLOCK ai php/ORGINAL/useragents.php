<?php
if(strpos($_SERVER["HTTP_USER_AGENT"], "exemple") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Example") !== false)
if(strpos($_SERVER["HTTP_USER_AGENT"], "example") !== false || strpos($_SERVER["HTTP_USER_AGENT"], "Example") !== false)´	

exit;
}		