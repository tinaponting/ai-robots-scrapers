<?php
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),".ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),".AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AutoGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Agent GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"anthropic-ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Applebot-Extended")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AIBOT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI2 Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AlphaAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iaskspider/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AISearchBot")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Applebot-Extended")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Bedrock")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"amazon-kendra")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Silk")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon SageMaker")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AlexaTM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AWS Trainium")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Textract")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Comprehend")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nova Act")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Alexa")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AnyPicker")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AlphaAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria browser AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria browse Aria AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AndersPinkBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AITraining")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Brave Leo AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"BardBot")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"bingbot-chat/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bing ai")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bytedance")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bytespider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ByteDance crawler")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Brightbot 1.0")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CatBoost")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"cohere-ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"cohere-training-data-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Cotoyogi")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"chatUser")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude-SearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ClaudeBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"claude-web/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ClaudeBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.7 Sonnet")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.5 Haiku")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude Opus")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CC-Crawler/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CrawlGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"crewAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CCBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ccbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CCBot/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Chinchilla")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E 2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL·E 3")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E Mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepL")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepMind")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepSeek")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepSeek-R1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Diffbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DialoGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DepolarizingGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"dataprovider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Doubao AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DuckAssistBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FriendlyCrawler")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FriendlyCrawler/1.0")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FriendlyCrawler/Nutch-1.20-SNAPSHOT")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"flyriverbot/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"meta-externalfetcher/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta AI")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama 3.2")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-ExternalAgent")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Firecrawl")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Flyriver")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FraudGPT")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LLaMA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Mistral")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Gato")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GenAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"gpt-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GTPBOT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTbot/0.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTBot/1.2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3.5")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3.5 Turbo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni Mini"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4.5")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-5")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"gpt-4-turbo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4o")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4o mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4V")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTZero")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WebChatGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SearchGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni Mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Scraper GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Extended GPT Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroCHAT"))	 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google Gemini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google-CloudVertexBot"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google Bard AI"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google Gemini"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Gemini"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Grok"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GrokAI")) 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Goose")) 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Hugging Face")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ICC-Crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iaskspider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iaskspider/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iAskBot")){		
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"img2dataset")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ImagesiftBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"IntelliSeek")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"IntelliSeek.ai")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ISSCyberRiskCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Kangaroo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Kangaroo Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"knowledge")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LeftWingGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meltwater")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nicecrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"magpie-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MSBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Omgilibot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Omgili")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Open AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Openbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o1-mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o3-mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OAI-SearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OAI-SearchBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI Crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAIContentCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI CUA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Operator")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"proximic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PaperLiBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PaperLiBot/2.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PanguBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PiplBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"peer39_crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"peer39_crawler/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PerplexityBot"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexity-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexit-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PerplexityUser")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"RightWingGPT")){		
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PetalBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"scrapy")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scrapy/2.0")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot-OCOB")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Seekr")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"StableDiffusionBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sidetrade")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ShadowGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"scrapy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Stability AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ScrapeGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"thehive.ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"The Knowledge AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Timpibot/0.9")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Timpibot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"TurnitinBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WormGPT")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WormGPT V3.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"wpbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"wpbot/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"wpbot/1.2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Webzio")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WebChatGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Webzio-Extended")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"VelenPublicWebCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"xAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"XBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"x.AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"My own Bot here")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YouBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YarGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"yarchatgpt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroCHAT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"My own Bot here")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"My own Bot here")){
exit(0);
}?>