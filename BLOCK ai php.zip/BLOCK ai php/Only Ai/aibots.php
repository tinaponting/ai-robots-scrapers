<?php
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),".ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),".ai=n")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AcademicBotRTU")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Agent GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Agentic Deep Research")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Agentic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Agentic-RAG")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI agents /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Article Writer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Chatbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Content Detector")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI copilot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Dungeon")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Search Engine")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Search Intent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Search")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI SEO Crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Writer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI2 Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI2Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI21 Labs")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AIBOT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"aiHitBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AIMatrix")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AISearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AI Training")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AITraining /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AITraining")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ai-proxy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AlexaTM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Alexa")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Alpha AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AlphaAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Athena")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Bedrock")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Comprehend")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Lex")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon SageMaker")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Silk")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon Textract")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AmazonBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"amazonBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amazon-Kendra")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"amazon-kendra")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Amelia")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AndersPinkBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AndiBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Anthropic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"anthropic-ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AnyPicker")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Anyword")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Applebot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Applebot-Extended")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria browse Aria AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria browser AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Aria Browse")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Articoolo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Ask AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AutoGLM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AutoGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Automated Writer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AutoML")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AwarioRssBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AwarioSmartBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AWS bedrock")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"AWS Trainium")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Azure")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bedrock Claude ")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"bedrock-chatbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"bedrock-chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"bedrock-claude-chatbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nova Act")){		
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"BabyAGI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"BardBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Brave Leo AI")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bytedance")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"byteDance")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Bytespider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ByteDance crawler")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Brightbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Brightbot 1.0")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CatBoost")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CCBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ccbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CCBot/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CC-Crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CC-Crawler/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"chatbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGLM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT search")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatGPT-User/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ChatLLM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"chatUser /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Chinchilla")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.5 Haiku")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.5 Sonnet")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.5")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 3.7 Sonnet")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude Opus 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude Opus")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude Sonnet 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ClaudeBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ClaudeBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude-SearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Claude-Web")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"claude-web/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ClearScope")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Cohere")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"cohere-ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"cohere-ai/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"cohere-training-data-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Common Crawl")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CommonCrawl")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Harmony")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content King")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Optimizer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Samurai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Scraper GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ContentAtScale")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ContentBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Contentedge")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Conversion AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Copilot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CopyAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Copymatic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Copyscape")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Cotoyogi")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CrawlGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"CrawlQ AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Crawlspace")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Crew AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"crewAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E 2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL·E 3")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DALL-E Mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Dall-E 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DataForSeoBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DataProvider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"dataprovider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepL")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepMind")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepSeek")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DeepSeek-R1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Diffbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DialoGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DepolarizingGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Doubao AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"DuckAssistBot")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Extended GPT Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Factset")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Factset_spyderbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Falcon")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Firecrawl")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FirecrawlAgent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Flyriver")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"flyriverbot/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Frase AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FriendlyCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FacebookBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"facebookexternalhit/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Flux")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"FraudGPT")){ 	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Extended GPT Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Gato")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Gemini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Gemma")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GenAI Chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GenAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Genspark")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GLM")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google Bard AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google Gemini"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google-CloudVertexBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Google-Extended")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Content Scraper GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Goose")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni Mini"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT 4 Omni"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTBot /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTBot/1.2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPTZero")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3.5 Turbo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-3.5")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4o mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4o")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4V")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4,5")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"gpt-4-turbo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4.1-mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-4.1-nano")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT-5")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"gpt-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Grammarly")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Grendizer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Grok AI chatbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GrokAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Grok")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GT Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GTBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GTPBOT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GTP")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"GPT/")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Hugging Face")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Hemingway Editor")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Hypotenuse AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iAskBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iaskspider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"iaskspider/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ImageGen")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ImageGen /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"imgproxy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Inferkit")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"INK Editor")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"INKforall")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ICC-Crawler")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"img2dataset")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ImagesiftBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ImageGen /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"IntelliSeek")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"IntelliSeek.ai")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ISSCyberRiskCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"JasperAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Kafkai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Keyword Density AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"KomoBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Kangaroo")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Kangaroo Bot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Knowledge")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"knowledge /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Le Chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Lensa")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Lightpanda")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LangChain")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LLMs")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LeftWingGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Le Chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"magpie-crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Manus")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MarketMuse")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meltwater")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama 3.2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta Llama")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MetaAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MetaTagBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-ExternalAgent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-ExternalAgent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"meta-externalagent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-ExternalFetcher")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"meta-externalfetcher/1.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Meta-External")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Llama 3.2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Llama 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Llama 4")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"LLaMA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"midjourney")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MistralAI-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MistralAI-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Mistral")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Mistral")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Monica")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"MSBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Narrative")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"NeevaBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Neural Text")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"NeuralSEO")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nicecrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"NinjaAIBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nova Act")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"NovaAct")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Nicecrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Outwrite")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Omgilibot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Omgili")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"omgili")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Open AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Openbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI CUA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenText AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o1-mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI o3-mini")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OAI-SearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OAI-SearchBot/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI Crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAIContentCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI CUA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"OpenAI Operator")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Operator")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Page Analyzer AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PanguBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Panscient")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PaperLiBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PaperLiBot/2.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Paraphraser.io")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"peer39_crawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"peer39_crawler/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexity Deep Research")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PerplexityBot"))
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PerplexityUser")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexity")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexity-User/1.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Perplexit-User")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PetalBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"petalBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PhindBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Phind")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PiplBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PiplBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"PoeSearchBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Poe")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ProWritingAid")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"proximic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Puppeteer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"qwen /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Qwen Chat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Qwen2")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Qwen3")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"qwen /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Qualified")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"QualifiedBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"QuillBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"RightWingGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"RobotSpider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Rytr")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SaplingAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SBIntuitionsBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scalenut")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ScrapeGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ScraperGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scraper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scrapy 2.12.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scrapy 2.13.1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"scrapy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Scrapy/2.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ScriptBook")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Search GPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SearchGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Seekr")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot-FT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot-OCOB")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot-OCOB")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SemrushBot-SWA")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sentibot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SEO Content Machine")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SEO Robot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ShadowGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ShadowGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sidetrade /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sidetrade")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Simplified AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sitefinity")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Skydancer")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Slack-ImgProxy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Slack-ImgProxy")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"SlickWrite")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sonic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sora")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Spin Rewriter")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Spinbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Stability AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Stability AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Stability")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"StableDiffusionBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"StableDiffusionBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Sudowrite")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Super Agent")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Surfer AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Text Blaze")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"TextCortex")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"The Knowledge AI1")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"TikTokSpider")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Traefik")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"TorChat")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"thehive.ai")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Timpibot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"TurnitinBot")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"VelenPublicWebCrawler")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Vidnami AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WebText /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Whisper")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WordAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Wordtune")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WormsGTP")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Writecream")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WriterZen")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Writescope")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Writesonic")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WormGPT")){ 
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WormGPT V3.0")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"wpbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"wpbot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WebText /")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"WebChatGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Webzio")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Webzio-Extended")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"xAI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"XBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"x.AI")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YandexGPTt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YandexLLMt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YandexAdditionalt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YandexAdditionalBott")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"yarchatgpt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YaLM")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YarGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"yarchatgpt")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"YouBot")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Zero /")){	
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroCHAT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"ZeroGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Zhipu")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"XXXGPT")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"Zimm")){
if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']),"My own Bot here")){
exit(0);
}?>